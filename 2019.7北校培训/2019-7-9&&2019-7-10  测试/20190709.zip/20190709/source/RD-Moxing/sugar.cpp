#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
#include<iomanip>
using namespace std;
int main(){
	freopen("suger.in","r",stdin);
	freopen("suger.out","w",stdout);
}
