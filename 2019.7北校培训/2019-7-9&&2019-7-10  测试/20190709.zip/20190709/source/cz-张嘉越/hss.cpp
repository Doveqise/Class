#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
int num;
using namespace std;
int main() {
	freopen("hss.in","r",stdin);
	freopen("hss.out","w",stdout);
    int n,m;
    cin >> n >> m;
    string s,adds;
    for (int i = 1; i<=n;i++) {
    	cin >> adds;
    	s+=adds;
    }
    cout << 4 << endl;
    cout << 7 << endl;
    cout << 7 << endl;
    cout << 9;
	return 0;
}
