#!/usr/bin/python3
# -*- coding: UTF-8 -*-

fin = open('com.txt', 'r')
id = int(fin.readline())
suf = fin.readline()

from numpy.random import randint
from os import system

l = 0
r = 0

if id <= 4:
    l = randint(1, 101)
    r = randint(100000 - 1000, 100000 + 1)
elif id <= 8:
    l = randint(1, 101)
    r = randint(1000000 - 1000, 1000000 + 1)
else:
    r = randint(1000000000 * 0.9, 1000000000 + 1)
    l = r - 1000000 + 1

nme = suf + str(id) + '.in'
fout = open(nme, 'w')
fout.write(str(l) + ' ' + str(r) + '\n')
fout.close

