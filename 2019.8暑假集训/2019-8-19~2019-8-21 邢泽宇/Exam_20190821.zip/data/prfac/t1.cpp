#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define debug cerr
using namespace std;
const int lim = 31650, maxn = 1e6 + 1e2;

int prime[lim], cnt;
bool vis[lim + 10];

inline void sieve() {
	vis[0] = vis[1] = 1;
	for(int i = 2; i <= lim; i++) {
		if(!vis[i]) prime[++cnt] = i;
		for(int j = 1; j <= cnt && (long long) i * prime[j] <= lim; j++) {
			vis[i * prime[j]] = 1;
			if(!(i % prime[j])) break;
		}
	}
}

int f[maxn], g[maxn];
inline int upper_div(int x, int t) {
	return (x + t - 1) / t;
}
inline int mark(int l, int r) {
	for(int i = l; i <= r; i++) g[i - l] = i;
	for(int i = 1; i <= cnt; i++) {
		long long pw = prime[i];
		while(pw <= r) {
			long long cur = upper_div(l, pw);
			while(pw * cur <= r) ++f[pw * cur - l], g[pw * cur - l] /= prime[i], cur++; // !
			pw *= prime[i];
		}
	}
	for(int i = l; i <= r; i++) f[i - l] += (g[i - l] != 1); // !
	int ret = 0;
	for(int i = l; i <= r; i++) ret += !vis[f[i - l]];
	return ret;
}

int main() {
	static int l, r;
	scanf("%d%d", &l, &r), sieve();
	printf("%d\n", mark(l, r));
	return 0;
}
