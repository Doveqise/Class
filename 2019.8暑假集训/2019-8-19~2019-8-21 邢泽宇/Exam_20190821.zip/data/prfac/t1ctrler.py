#!/usr/bin/python3
# -*- coding: UTF-8 -*-

__problem_name__ = 'prfac'

from os import system

for i in range(1, 21):
    fout = open('com.txt', 'w')
    fout.write(str(i) + '\n')
    fout.write(__problem_name__)
    fout.close()
    system("python3 ./t1mker.py")
    com = './t1 < ' + __problem_name__+ str(i) + '.in > ' + __problem_name__ + str(i) + '.out'
    system(com)

