#!/usr/bin/python3
# -*- coding: UTF-8 -*-

__problem_name__ = 'sum'

from os import system

for i in range(1, 21):
    fout = open('com.txt', 'w')
    com = 'mv ' + str(i) + '.in ' + __problem_name__ + str(i) + '.in'
    system(com)
    com = 'mv ' + str(i) + '.out ' + __problem_name__ + str(i) + '.out'
    system(com)
