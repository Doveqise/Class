#!/usr/bin/python3
# -*- coding: UTF-8 -*-

fin = open('com.txt', 'r')
id = int(fin.readline())
suf = fin.readline()

from numpy.random import randint
from os import system

n = 0
m = 0
k = 0

if id <= 4:
    n = 100
    m = 5
    k = 3
elif id <= 12:
    n = 300000
    m = 1000
    k = 2
else:
    n = 300000
    m = 300000
    k = randint(1, 11)

nme = suf + str(id) + '.in'
fout = open(nme, 'w')
fout.write(str(n) + ' ' + str(m) + ' ' + str(k) + '\n')
for i in range(2, n + 1):
    fout.write(str(randint(1, i)) + ' ' + str(i) + '\n')
for i in range(0, m):
    fout.write(str(randint(1, n + 1)) + ' ' + str(randint(1, n + 1)) + '\n')
fout.close

