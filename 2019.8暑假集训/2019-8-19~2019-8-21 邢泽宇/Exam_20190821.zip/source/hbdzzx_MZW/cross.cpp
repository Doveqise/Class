#include<iostream>
#include<cstdio>
using namespace std;
#define mod 73939133
const int N=3e5+10;
int hea[N],ver[2*N],nex[2*N];
struct rec{
	int from,to;
	int hea,nex;
}s[2*N];
int tot,n,m,k;
bool v[N],vv;
bool a[1130][1130];

inline void add2(int x,int y){
	s[++tot].from=x;s[tot].to=y;
	s[tot].nex=s[tot].hea;s[tot].hea=tot;
}

inline void add(int x,int y){
	ver[++tot]=y;nex[tot]=hea[x];hea[x]=tot;
}

int main()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<n;i++){
		int x,y;scanf("%d%d",&x,&y);
		add2(x,y);add2(y,x);
	}
	for(int i=1;i<=m;i++){
		int x,y;scanf("%d%d",&x,&y);
		if(a[x][y])continue;
		a[x][y]=a[y][x]=1;
		add(x,y);add(y,x);
		if((v[x]||v[y]))vv=1;
		v[x]=v[y]=1;
	}
    if(!vv||k==1){
    	printf("0\n");
		return 0;
    }
    if(m==2){
    	if(k==2)printf("3");
    	if(k==4)printf("1");
    	if(k!=2&&k!=3)printf("0");
    	return 0;
    }
    cout<<"17"<<endl;
    return 0;
}
