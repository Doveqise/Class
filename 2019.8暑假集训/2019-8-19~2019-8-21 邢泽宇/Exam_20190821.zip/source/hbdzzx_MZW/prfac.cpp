#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
#define itn int
const int N=1e6+10;
int l,r,len;
int ans[2][N];
int a[N];
int prime[N],v[N],m;

inline void chu(int n){
	for(int i=2;i<=n;i++){
		if(v[i]==0){
			v[i]=i;
			prime[++m]=i;
		}
		for(int j=1;j<=m;j++){
			if(v[i]<prime[j]||i*prime[j]>n)break;
			v[i*prime[j]]=prime[j];
		}
	}
}

inline int fen(int n){
	int ans=0;
	for(int i=2;i<=sqrt(n);i++){
		while(n%i==0){
			ans++;n/=i;
		}
	}
	if(n>1)ans++;
	return ans;
}

int main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%d%d",&l,&r);
	if(l>r)swap(l,r);
	if(l==1)l++;
	chu(sqrt(r));
    for(int i=l;i<=r;i++)ans[0][i-l]=i;
	for(int i=1;i<=m;i++){
		int p=(l-1)/prime[i]+1;
		for(int j=p*prime[i];j<=r;j+=prime[i]){
			while(ans[0][j-l]%prime[i]==0){
				ans[1][j-l]++;
				ans[0][j-l]/=prime[i];
			}
		}
	}
	for(int i=l;i<=r;i++)if(ans[0][i-l]>1)ans[1][i-l]++;
	int answ=0;
	for(int i=l;i<=r;i++){
		int p=ans[1][i-l];
		if(v[p]==p){
			answ++;
		}
	}
	printf("%d",answ);
	return 0;
}
