#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
#define itn int
#define ll long long
const int mod=1e9+9;
int n,m,k;

inline ll fai(ll n){
	ll ans=n;
	for(int i=2;i<=sqrt(n);i++){
		if(n%i==0){
			ans=ans/i*(i-1);
			while(n%i==0)n/=i;
		}
	}
	if(n>1)ans=ans/n*(n-1);
	return ans%mod;
}

inline ll power(ll x,ll y){
	ll ans=1;
	while(y){
		if(y&1){
			ans=(ll)(ans*x)%mod;
		}
		x=(ll)(x*x)%mod;
		y>>=1;
	}
	return ans%mod;
}

int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&k);
	ll ans=0;
	for(int i=2;i<=n;i++){
		ll p=power(i,k);
		ll q=fai(p);
		ans+=q;
		ans%=mod;
	}
	cout<<(ans+1)%mod<<endl;
	return 0;
}
