#include<bits/stdc++.h>
using namespace std;
#define R register
#define il inline 
#define ll long long 
int tes[10]={2,3,5,7,11,13,17};
const int maxn=1000050;
//const int MOD=1000000000;
int k,num[100010],l,r,yinshu[maxn];
ll ans=0;
il int divide(int x) {
	int res,i,a;a=x;
	if(0==x)return 0;
	if(1==x)k=1;
	else{
		i=2;k=0;
		while(x!=1){if(0==x%i){num[k]=i;k++;x=x/i;}else i++;}
	}
	return k;
}
il int quickpow(R int x,R int n,int mod){
	int res=1;int base=x;
	while(n){
		if(n&1){res*=base%mod;}base*=base%mod;n=n>>1;
	}return res%mod;
}
inline bool is_prime(int p){
	int nxt;if(p==1)return 0;int t=p-1,k=0;
	while(!(t&1))++k,t>>=1;
	for(R int i=0;i<4;i++){
		if(p==tes[i])return 1;
		ll a=quickpow(tes[i],t,p),nxt=a;
		for(R int j=1;j<=k;j++){
			nxt=(a*a%p);if(nxt==1&&a!=1&&a!=p-1)return 0;a=nxt;
		}
		if(a!=1)return 0;
	} 
	return true;
 } 
signed main(){
	freopen("prfac.in","r",stdin);
	freopen("prfsc.out","w",stdout);
	scanf("%d %d",&l,&r);
	int cnt=0;
	for(R int i=l;i<=r;i++)yinshu[++cnt]=divide(i);
	for(R int i=1;i<=cnt;i++)if(is_prime(yinshu[i])==true)
	ans++;printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
