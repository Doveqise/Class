#include<cstdio>
#include<iostream>
#include<cmath>
#define ll unsigned long long
#define R register ll
using namespace std;
namespace Luitaryi {
const int M=1e9+9;
int n,k; ll ans;
inline ll qpow(ll a,ll p) { R ret=1;
	for(;p;p>>=1,(a*=a)%=M) if(p&1) ret*=a; return ret;
}
inline ll phi(ll x) { R lim=sqrt(x),ret=x;
	for(register int i=2;i<=lim;++i) {
		if(x%i==0) ret=ret/i*(i-1);
		while(x%i==0) x/=i;
	} if(x>1) ret=ret/x*(x-1); return ret;
}
inline void main() { 
	freopen("sum.in","r",stdin); freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(register int i=1;i<=n;++i) ans+=phi(qpow(i,k)); 
	printf("%llu\n",ans);
}
} signed main() {Luitaryi::main(); return 0;}
