#pragma GCC optimize("Ofast")
#include<cstdio>
#include<cmath>
#include<iostream>
#define ll long long
#define RR register ll
#define R register int
using namespace std;
namespace Luitaryi {
const int N=100010,M=30000010;
int l,r,cnt,ans;
int p[M/2],f[M]; bool v[M],is[M];
inline void PRE1(int n) { v[0]=v[1]=1;
	for(R i=2;i<=n;++i) {
		if(!v[i]) p[++cnt]=i,f[i]=1;
		for(R j=1;j<=cnt&&i*p[j]<=n;++j) {
			f[i*p[j]]=f[i]+1; 
			v[i*p[j]]=true;
			if(i%p[j]==0) break;
		}
	}
}
inline void main() { freopen("prfac.in","r",stdin); freopen("prfac.out","w",stdout);
	scanf("%d%d",&l,&r); 
	if(r<=3e+7) { PRE1(r);
		for(R i=l;i<=r;++i) ans+=!v[f[i]]; 
		return (void) printf("%d\n",ans);
	} else {
		PRE1(3e+7);
		for(R i=l;i<=r;++i) { R tmp=i,lim=sqrt(i),tot=0,llim=3e+7;
			for(R j=1;j<=cnt&&p[j]<=tmp&&p[j]<=lim&&tmp>llim;++j) {
				while(tmp%p[j]==0) ++tot,tmp/=p[j];
			} if(tmp>llim) ++tot; else tot+=f[tmp]; if(!v[tot]) ++ans;
		} printf("%d\n",ans);
	}
}
} signed main() {Luitaryi::main(); return 0;}

