#include<cstdio>
#include<iostream>
#include<algorithm>
#define R register int
using namespace std;
namespace Luitaryi {
template<class I> inline I g(I& x) { x=0; register I f=1;
	register char ch; while(!isdigit(ch=getchar())) f=ch=='-'?-1:f;
	do x=x*10+(ch^48); while(isdigit(ch=getchar())); return x*=f;
} const int N=300010,M=300010,P=73939133;
int n,m,k; 
int cnt,num,ans,sum[N<<2];
int vr[N<<1],nxt[N<<1],fir[N],d[N],dfn[N],sz[N],son[N],pre[N],top[N],c[N],fac[N],Inv[N];
#define ls (tr<<1)
#define rs (tr<<1|1)
inline void addw(int u,int v) {
	vr[++cnt]=v,nxt[cnt]=fir[u],fir[u]=cnt;
	vr[++cnt]=u,nxt[cnt]=fir[v],fir[v]=cnt;
}
inline void dfs(int u) { sz[u]=1; R mx=0;
	for(R i=fir[u];i;i=nxt[i]) { R v=vr[i];
		if(!d[v]) {
			pre[v]=u; d[v]=d[u]+1; dfs(v); sz[u]+=sz[v]; 
			if(sz[v]>mx) son[u]=v,mx=sz[v];
		}
	}
}
inline void dfs_(int u,int tp) {
	top[u]=tp,dfn[u]=++num;
	if(son[u]) dfs_(son[u],tp);
	for(R i=fir[u];i;i=nxt[i]) { R v=vr[i];
		if(v!=pre[u]&&v!=son[u]) dfs_(v,v);
	}
}
inline int query(int tr,int l,int r,int LL,int RR) { 
	if(LL<=l&&r<=RR) return sum[tr]; R md=(l+r)>>1,ret=0;
	if(LL<=md) ret+=query(ls,l,md,LL,RR); 
	if(RR>md) ret+=query(rs,md+1,r,LL,RR); return ret;
}
inline void update(int tr,int l,int r,int p,int inc) {
	if(l==r) {sum[tr]+=inc; return ;} R md=(l+r)>>1;
	if(p<=md) update(ls,l,md,p,inc);
	else update(rs,md+1,r,p,inc);
	sum[tr]=sum[ls]+sum[rs];
}
inline void change(int u,int v) {
	while(top[u]!=top[v]) {
		if(d[top[u]]<d[top[v]]) swap(u,v);
		update(1,1,n,dfn[top[u]],1);
		update(1,1,n,dfn[u]+1,-1);
		u=pre[top[u]];
	} if(dfn[u]>dfn[v]) swap(u,v);
	update(1,1,n,dfn[u],1); update(1,1,n,dfn[v]+1,-1);
}
inline int queryT(int u) { R ret=0;
	while(top[u]!=1) {
		ret+=query(1,1,n,dfn[top[u]],dfn[u]);
		u=pre[top[u]];
	} ret+=query(1,1,n,1,dfn[u]); return ret;
}
inline int lca(int u,int v) {
	while(top[u]!=top[v]) {
		if(d[top[u]]<d[top[v]]) swap(u,v);
		u=pre[top[u]];
	} if(d[u]>d[v]) swap(u,v); return u;
}
struct node { int u,v,p; node() {}
	node(int _u,int _v,int _p) {u=_u,v=_v,p=_p;}
	inline bool operator < (const node& that) const {return d[p]<d[that.p];} 
}mem[N];
inline int C(int n,int m) {return 1ll*fac[n]*Inv[m]%P*Inv[n-m]%P;}
inline void main() { freopen("cross.in","r",stdin); freopen("cross.out","w",stdout);
	fac[0]=fac[1]=Inv[0]=Inv[1]=1; for(R i=2;i<N;++i) fac[i]=1ll*fac[i-1]*i%P;
	for(R i=2;i<N;++i) Inv[i]=(P-1ll*P/i*Inv[P%i]%P)%P; 
	for(R i=2;i<N;++i) Inv[i]=1ll*Inv[i]*Inv[i-1]%P;
	g(n),g(m),g(k); for(R i=1,u,v;i<n;++i) g(u),g(v),addw(u,v);
	d[1]=1; dfs(1); dfs_(1,1); for(R i=1,u,v;i<=m;++i) g(u),g(v),mem[i]=node(u,v,lca(u,v));
	sort(mem+1,mem+m+1); for(R i=1;i<=m;++i) (ans+=C(queryT(mem[i].p),k-1))%=P,change(mem[i].u,mem[i].v);
	printf("%d\n",ans);
}
} signed main() {Luitaryi::main(); return 0;}
