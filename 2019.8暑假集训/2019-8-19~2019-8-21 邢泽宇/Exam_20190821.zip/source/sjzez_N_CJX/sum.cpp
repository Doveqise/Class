#include<cstdio>
#define N 10000005
#define ll long long
const int mod=1e9+9;
using namespace std;
int mindiv[N],prime[N],phi[N];
int n,k;
inline void euler(){
	mindiv[1]=1;phi[1]=1;
	for(int i=2;i<=n;i++){
		if(!mindiv[i]){
			mindiv[i]=i;prime[++prime[0]]=i;phi[i]=i-1;
		}
		for(int j=1;j<=prime[0]&&i*prime[j]<=n&&prime[j]<=mindiv[i];j++){
			mindiv[i*prime[j]]=prime[j];
			if(i%prime[j])phi[prime[j]*i]=phi[i]*phi[prime[j]];
			else phi[prime[j]*i]=phi[i]*prime[j];
		}
	}
}
ll ans;
ll qpow(ll base,ll m){
	ll ret=1;
	while(m){
		if(m&1)ret=ret*base%mod;
		base=base*base%mod;
		m>>=1;
	}
	return ret;
}
int main(){
    freopen("sum.in","r",stdin);freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&k);
	euler();
	for(int i=1;i<=n;i++){
		ans+=(phi[i]*qpow(i,k-1))%mod;
		ans%=mod;
	}
	printf("%lld",ans);
}
