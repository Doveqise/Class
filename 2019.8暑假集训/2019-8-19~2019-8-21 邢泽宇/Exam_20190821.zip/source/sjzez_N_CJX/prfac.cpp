#include<cstdio>
#include<windows.h>
#define ll long long
#define N 1000005
using namespace std;
ll mindiv[N],prime[N],phi[N];
bool isprime[N];
inline void euler(){
	mindiv[1]=1;phi[1]=1;
	for(int i=2;i<=100000;i++){
		if(!mindiv[i]){
			mindiv[i]=i;prime[++prime[0]]=i;phi[i]=i-1;isprime[i]=1;
		}
		for(int j=1;j<=prime[0]&&i*prime[j]<=100000&&prime[j]<=mindiv[i];j++){
			mindiv[i*prime[j]]=prime[j];
			if(i%prime[j])phi[prime[j]*i]=phi[i]*phi[prime[j]];
			else phi[prime[j]*i]=phi[i]*prime[j];
		}
	}
}
ll l,r,ans;
inline void div(ll x){
//	printf("%d\n",x);
	ll ret=0,xx=x;
	while(x!=1){
		for(int i=1;prime[i]<=x&&i<=prime[0];i++){
	//		printf("%d %d\n",x,prime[i]);
			while(x%prime[i]==0){
				ret++;
				x/=prime[i];
			}
		}
		if(x<=100000&&isprime[x])ret++,x/=x;
		else break;
	}

	if(isprime[ret])ans++;
}
int main(){
	freopen("prfac.in","r",stdin);freopen("prfac.out","w",stdout);
	scanf("%d%d",&l,&r);
	euler();
//	printf("%d\n",prime[0]);
//system("pause");	
	for(int i=l;i<=r;i++)div(i);
	printf("%d",ans);
//	while(1);
	return 0;
}
