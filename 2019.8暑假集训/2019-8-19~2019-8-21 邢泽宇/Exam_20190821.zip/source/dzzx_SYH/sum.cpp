#include<iostream>
#include<cstdio>
#include<cmath>
#define ll long long
using namespace std;
const int mod=1e9+9;
int n,k;
ll ans;
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		ll l=1,p=0;
		for(int j=1;j<=k;j++) l=l*i;
		p=l;
		for(int j=2;j<=sqrt(p);j++){
			if(p%j==0){
				l=(l-l/j)%mod;
				while(p%j==0) p/=j;
			}
		}
		if(p>1) l=(l-l/p)%mod;
		ans=(ans+l)%mod;
	}
	printf("%lld",ans%mod);
	return 0;
}
