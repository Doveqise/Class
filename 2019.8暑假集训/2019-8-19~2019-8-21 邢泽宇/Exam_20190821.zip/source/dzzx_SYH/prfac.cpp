#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<vector>
using namespace std;
int l,r,ans,prime[1000010],vis[1000010],tot;
bool v[1000010];
int main(){
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%d%d",&l,&r);
	for(int i=2;i<=r;i++){
		if(!vis[i]) vis[i]=i,v[i]=1,prime[++tot]=i;
		for(int j=1;j<=tot;j++){
			if(vis[i]<prime[j] || i*prime[j]>r) break;
			vis[i*prime[j]]=prime[j];
		}
	}
	for(int i=l;i<=r;i++){
		int num=0,p=i;
		for(int j=2;j<=sqrt(p);j++){
			if(p%j==0){
				while(p%j==0) p/=j,num++;
			}
		}
		if(p>1) num++;
		if(v[num]) ans++;
	}
	printf("%d\n",ans);
	return 0;
}
