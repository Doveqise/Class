#include<iostream>
#include<cstdio>
using namespace std;
int n,m,k,Head[1010],ver[2010],nex[2010],dep[1010],f[1010][20],tot,num[1010],ans;
void add(int x,int y){
	ver[++tot]=y;nex[tot]=Head[x];Head[x]=tot;
}
void dfs(int x,int fa){
	for(int i=Head[x];i;i=nex[i]){
		int y=ver[i];
		if(y==fa) continue;
		dep[y]=dep[x]+1;
		f[y][0]=x;
		dfs(y,x);
	}
}
int LCA(int x,int y){
	if(dep[x]<dep[y]) swap(x,y);
	for(int i=20;i>=0;i--)
		if(dep[f[x][i]]>=dep[y]) x=f[x][i];
	if(x==y) return x;
	for(int i=20;i>=0;i--)
		if(f[x][i]!=f[y][i]) x=f[x][i],y=f[y][i];
	return f[x][0];
}
void DFS(int x,int fa){
	for(int i=Head[x];i;i=nex[i]){
		int y=ver[i];if(y==fa) continue;
		DFS(y,x);
		num[x]+=num[y];
	}
	ans+=num[x]*(num[x]-1)/2;
}
int main(){
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<n;i++){
		int u,v;scanf("%d%d",&u,&v);add(u,v);add(v,u);
	}
	dep[1]=1;dfs(1,0);
	for(int i=1;i<=20;i++)
		for(int j=1;j<=n;j++)
			f[j][i]=f[f[j][i-1]][i-1];
	for(int i=1;i<=m;i++){
		int u,v;scanf("%d%d",&u,&v);
		int lca=LCA(u,v);
		num[u]++;num[v]++;num[lca]--;num[f[lca][0]]--;
	}
	DFS(1,0);
	printf("%d",ans);
	return 0;
}


