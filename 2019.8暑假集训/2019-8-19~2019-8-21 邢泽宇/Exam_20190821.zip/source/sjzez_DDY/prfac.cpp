#include<bits/stdc++.h>
using namespace std;
#define re register
typedef long long ll;
const ll maxn=1e6+10;
ll n,m,ans;
ll check[maxn],cnt[maxn];
bool vis[maxn];
vector<ll>prime;
inline ll read()
{
	char c=getchar();ll res=0,f=1;
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9')res=res*10+c-'0',c=getchar();
	return res*f;
}
void pre()
{
	vis[1]=1;
	for(re int i=2;i<=m/2;i++)
	{
		if(!vis[i])prime.push_back(i);
		for(re unsigned int j=0;j<prime.size()&&i*prime[j]<=m/2;j++)
		{
			vis[i*prime[j]]=1;
			if(!(i%prime[j]))break;
		}
	}
}
inline void work(int x)
{
	ll res=0;
	for(re unsigned int i=0;i<prime.size();i++)
		if(!(x%prime[i]))
			while(!(x%prime[i]))res++,x/=prime[i];
	if(vis[res])check[x-n]=2;
	else check[x-n]=1;
	if(!res)check[x-n]=2;
	cnt[x-n]=res;
}
int main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	n=read(),m=read();
	pre();
	/*for(unsigned int j=0;j<prime.size();j++)printf("%d ",prime[j]);
	puts("");*/
	for(re int i=n;i<=m;i++)
	{
		if(!check[i-n])work(i);
		for(re unsigned int j=0;j<prime.size()&&i*prime[j]<=m;j++)
		{
			check[i*prime[j]-n]=vis[cnt[i-n]+1]?2:1;
			cnt[i*prime[j]-n]=cnt[i-n]+1;
			if(!(i%prime[j]))break;
		}
	}
	//for(int i=n;i<=m;i++)printf("%d ",check[i-n]);
	for(re int i=n;i<=m;i++)if(check[i-n]==1)ans++;
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
