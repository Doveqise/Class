#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
const int mod=73939133;
int n,m,K,cnt,tim,ans,t;
int head[maxn],dep[maxn],val[maxn];
int fa[maxn][20];
bool vis[maxn];
struct edge
{
	int to,nxt;
}e[maxn<<1];
struct Road
{
	int u,v;
}rd[maxn];
inline int read()
{
	char c=getchar();int res=0,f=1;
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9')res=res*10+c-'0',c=getchar();
	return res*f;
}
inline void add(int u,int v)
{
	e[++cnt].nxt=head[u];
	head[u]=cnt;
	e[cnt].to=v;
}
inline int C(int x,int y)
{
	int res=1,tmp=1;
	for(int i=x-y+1;i<=x;i++)res*=i;
	for(int i=1;i<=y;i++)tmp*=i;
	return (res/tmp)%mod;
}
void bfs()
{
	queue<int>q;dep[1]=1;q.push(1);
	while(!q.empty())
	{
		int x=q.front();q.pop();
		for(int i=head[x];i;i=e[i].nxt)
		{
			int y=e[i].to;
			if(dep[y])continue;
			dep[y]=dep[x]+1;fa[y][0]=x;
			for(int j=1;j<=t;j++)fa[y][j]=fa[fa[y][j-1]][j-1];
			q.push(y);
		}
	}
}
inline int lca(int x,int y)
{
	if(dep[x]>=dep[y])swap(x,y);
	for(int i=t;i>=0;i--)if(dep[fa[y][i]]>=dep[x])y=fa[y][i];
	if(x==y)return x;
	for(int i=t;i>=0;i--)if(fa[x][i]!=fa[y][i])x=fa[x][i],y=fa[y][i];
	return fa[x][0];
}
void Add(int x,int goal)
{
	for(int i=x;i!=goal;i=fa[i][0])val[i]++;
}
bool pd(int x,int goal)
{
	for(int i=x;i!=goal;i=fa[i][0])if(val[i]>1)return 0;
	return 1;
}
inline bool check()
{
	for(int i=1;i<=m;i++)
	{
		if(!vis[i])continue;
		int x=rd[i].u,y=rd[i].v,z=lca(x,y);
		Add(x,z);Add(y,z);val[z]--;
	}
	for(int i=1;i<=m;i++)
	{
		if(!vis[i])continue;
		int x=rd[i].u,y=rd[i].v,z=lca(x,y);
		if(pd(x,z)||pd(y,z))return 0;
	}
	return 1;
}
void dfs(int dep)
{
	if(!dep)
	{
		memset(val,0,sizeof(val));
		if(check())ans=(ans-1+mod)%mod;
		return;
	}	
	for(int i=1;i<=m;i++)
	{
		if(vis[i])continue;
		vis[i]=1;
		dfs(dep-1);
		vis[i]=0;
	}
}
int main()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	n=read(),m=read(),K=read();t=(int)log2(n)+1;
	for(int i=1;i<n;i++)
	{
		int u=read(),v=read();
		add(u,v);add(v,u);
	}	
	bfs();
	for(int i=1;i<=m;i++)rd[i].u=read(),rd[i].v=read();
	ans=C(m,K)%mod;
	dfs(K);
	printf("%d",ans);
	return 0; 
}
