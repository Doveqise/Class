#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=10000010;
const ll mod=1e9+9;
ll n,K,ans;
ll phi[maxn],v[maxn];
vector<ll>prime;
inline ll power(ll x,ll k)
{
	ll res=1;
	while(k)
	{
		if(k&1)res=res*x;
		x=x*x;k>>=1;
	}
	return res;
}  
void pre()
{
	int m=power(n,K);
	for(int i=2;i<=m;i++)
	{
		if(!v[i])v[i]=i,prime.push_back(i),phi[i]=i-1;
		for(unsigned int j=0;j<prime.size();j++)
		{
			if(prime[j]>v[i]||i*prime[j]>m)break;
			v[i*prime[j]]=prime[j];
			phi[i*prime[j]]=phi[i]*(i%prime[j]?prime[j]-1:prime[j]);
		}
	}
}
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%lld%lld",&n,&K);
	pre();
	for(int i=1;i<=n;i++)
	{
		ans=(ans+phi[power(i,K)]%mod)%mod;
	}
	printf("%lld",ans+1);
	return 0;
}
