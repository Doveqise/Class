#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
namespace IO{
	
	#define rg register
	template<typename T>
	inline void read(T &x){
		x=0;
		static char ch;ch=getchar();
		static int f;f=0;
		while(ch<'0'||ch>'9') f|=(ch=='-'),ch=getchar();
		while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
		x=f?-x:x;
	}
	bool check(int x){
		for(int i=sqrt(x);i>=2;--i){
			if(!(x%i)) return false;
		}
		return true;
	}
	int phi[2000010],git[2000010],cnt,n,vis[2000010],l,ans;
	void main(){
		freopen("prfac.in","r",stdin);
		freopen("prfac.out","w",stdout);
		read(l),read(n);
		for(int i=2;i<=n;++i){
			if(!phi[i]){
				git[++cnt]=i;
				phi[i]=i;
				vis[i]=1;
			}
			for(int j=1;j<=cnt&&git[j]*i<=n;++j){
				phi[git[j]*i]=phi[i];
				vis[git[j]*i]=vis[i]+1;
				if(git[j]==phi[i]) break;
			}
		}
		phi[0]=-1;
		for(int i=l;i<=n;++i){
			if(phi[vis[i]]==vis[i]){
				++ans;
			}
		}
		cout<<ans<<endl;
		fclose(stdin);
		fclose(stdout);
	}
}
int main(){IO::main();return 0;}

