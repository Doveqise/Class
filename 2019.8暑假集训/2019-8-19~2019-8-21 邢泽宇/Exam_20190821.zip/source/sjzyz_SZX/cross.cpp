#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
namespace IO{
	#define rg register
	template<typename T>
	inline void read(T &x){
		x=0;
		static char ch;ch=getchar();
		static int f;f=0;
		while(ch<'0'||ch>'9') f|=(ch=='-'),ch=getchar();
		while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
		x=f?-x:x;
	}
	const int N=300010;
	int head[N],ver[N],nxt[N],tot,n,m,k,ans;
	inline void add(int x,int y){
		ver[++tot]=y;
		nxt[tot]=head[x];
		head[x]=tot;
	}
	int top[N],id[N],cnt,fa[N],sz[N],dep[N],son[N];
	int xl[N],yl[N];
	void dfs1(int x){
		sz[x]=1;
		for(int i=head[x];i;i=nxt[i]){
			int y=ver[i];
			if(y==fa[x]) continue;
			dep[y]=dep[x]+1;
			fa[y]=x;
			dfs1(y);
			sz[x]+=sz[y];
			if(sz[son[x]]<sz[y]) son[x]=y;
		}
	}
	void dfs2(int x,int f){
		id[x]=++cnt;top[x]=f;
		if(son[x]) dfs2(son[x],f);
		for(int i=head[x];i;i=nxt[i]){
			int y=ver[i];
			if(y==fa[x]||y==son[x]) continue;
			dfs2(y,y);
		}
	}
	int sum[N<<2],lazy[N<<2];
	#define ls p<<1
	#define rs p<<1|1
	int max(int a,int b){
		return a>b?a:b;
	}
	void add(int l,int r,int L,int R,int d,int p){
		//sum[p]+=d*(R-L+1);
		sum[p]+=d;
		if(l==L&&r==R){
			lazy[p]+=d;
			return;
		}
		int mid=(l+r)>>1;
		if(L>mid) return add(mid+1,r,L,R,d,rs);
		if(R<=mid) return add(l,mid,L,R,d,ls);
		add(l,mid,L,mid,d,ls);add(mid+1,r,mid+1,R,d,rs);
	}
	int ask_max(int l,int r,int L,int R,int p){
		if(l==L&&r==R) return sum[p];
		int mid=(l+r)>>1;
		if(L>mid) return ask_max(mid+1,r,L,R,rs)+lazy[p];
		if(R<=mid) return ask_max(l,mid,L,R,ls)+lazy[p];
		return max(ask_max(l,mid,L,mid,ls),ask_max(mid+1,r,mid+1,R,rs))+lazy[p];
	}
	inline void swap(int &x,int &y){
		x^=y^=x^=y;
	}
	inline void modify(int x,int y,int d){
		while(top[x]!=top[y]){
			//cout<<"!"<<endl;
			//cout<<x<<" "<<y<<" "<<fa[x]<<" "<<fa[y]<<" "<<top[x]<<" "<<top[y]<<endl;
			//cout<<x<<" "<<y<<" "<<id[x]<<" "<<id[y]<<" "<<top[x]<<endl;
			if(dep[top[x]]<dep[top[y]]) swap(x,y);
			add(1,n,id[top[x]],id[x],d,1);
			x=fa[top[x]];
		}
		if(id[x]>id[y]) swap(x,y);
		add(1,n,id[x],id[y],d,1);
	}
	inline int query(int x,int y){
		int ans=0;
		while(top[x]!=top[y]){
			if(dep[top[x]]<dep[top[y]]) swap(x,y);
			ans=max(ans,ask_max(1,n,id[top[x]],id[x],1));
			x=fa[top[x]];
		}
		if(id[x]>id[y]) swap(x,y);
		return max(ans,ask_max(1,n,id[x],id[y],1));
	}
	int have[N];
//	int hh;
	inline void dfs(int st,int now){
		if(st==k){
//			++hh;
//			if(hh<=2){
//				for(int i=1;i<=st;++i){
//					cout<<have[i]<<" ";
//				}
//				cout<<endl;
//			}
			for(int i=1;i<=st;++i){
				modify(xl[have[i]],yl[have[i]],1);
			}
			if(query(xl[have[1]],yl[have[1]])==k) ++ans;
			for(int i=1;i<=st;++i){
				modify(xl[have[i]],yl[have[i]],-1);
			}
			return;
		}
		if(now==m) return;
		for(int i=now+1;i<=m;++i){
			have[st+1]=i;
			dfs(st+1,i);
		}
	}
	void main(){
		freopen("cross.in","r",stdin);
		freopen("cross.out","w",stdout);
		read(n),read(m),read(k);
		for(int x,y,i=1;i<n;++i){
			read(x),read(y);
			add(x,y);add(y,x);
		}
		if(k==1){
			cout<<m<<endl;
			return;
		}
		dfs1(1);dfs2(1,1);
		for(int i=1;i<=m;++i) read(xl[i]),read(yl[i]);
		//for(int i=1;i<=n;++i) cout<<id[i]<<" ";
		if(k==2){
			for(int i=1;i<=m;++i){
				for(int j=i+1;j<=m;++j){
					//cout<<i<<" "<<j<<" "<<" hehe "<<xl[i]<<" "<<yl[i]<<endl;
					modify(xl[i],yl[i],1);
					if(query(xl[j],yl[j])) ++ans;
					modify(xl[i],yl[i],-1);
				}
			}
			cout<<ans<<endl;
			fclose(stdin);
			fclose(stdout);
			return;
		}else{
			dfs(0,0);
			fclose(stdin);
			fclose(stdout);
			cout<<ans<<endl;
			return;
		}
	}
}
int main(){IO::main();return 0;}
/*
3 4 3
1 2
1 3
2 3
1 2
1 3
1 1

*/
