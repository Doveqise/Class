#include<cstdio>
int mindiv[10000050],prime[2000050],tot=0;
long long phi[10000050],powans[2000050];
const int mod=1e9+9;
long long quickpow(long long a,int b)
{
	register long long ans=1;
	while(b)
	{
		if(b&1)
		{
			(ans*=a)%=mod;
		}
		b>>=1;
		(a*=a)%=mod;
	}
	return ans%mod;
}
long long euler(long long a,register int pow)
{
	register long long i,j,sum=1;
	for(i=2;i<=a;i++)
	{
		if(!mindiv[i])
		{
			mindiv[i]=i;
			prime[++tot]=i;
			powans[tot]=quickpow(i,pow-1);
			phi[i]=((i-1)*powans[tot])%mod;
		}
		(sum+=phi[i])%=mod;
		for(j=1;prime[j]*i<=a;j++)
		{
			mindiv[prime[j]*i]=prime[j];
			if(mindiv[i]==prime[j])
			{
				phi[prime[j]*i]=(phi[i]*powans[j]*prime[j])%mod;
				break;
			}
			else
			{
				phi[prime[j]*i]=(phi[i]*phi[prime[j]])%mod;
			}
		}
	}
	return sum%mod;
}
int main()
{
	long a;
	int b;
	long long ans;
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%lld%d",&a,&b);
	ans=euler(a,b);
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
