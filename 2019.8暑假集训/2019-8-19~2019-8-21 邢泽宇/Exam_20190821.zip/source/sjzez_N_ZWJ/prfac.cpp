#include<cstdio>
int mindiv[20000050],sum[20000050],prime[5000050],tot=0;
short primefactor[20000050];
int swap(int &a,int &b)
{
	a^=b;
	b^=a;
	a^=b;
	return 0;
}
int euler(int a)
{
	register int i,j;
	for(i=2;i<=a;i++)
	{
		if(!mindiv[i])
		{
			mindiv[i]=i;
			prime[++tot]=i;
			primefactor[i]=1;
		}
		if(mindiv[primefactor[i]]==primefactor[i])
		{
			sum[i]=sum[i-1]+1;
		}
		else
		{
			sum[i]=sum[i-1];
		}
		for(j=1;prime[j]*i<=a;j++)
		{
			mindiv[prime[j]*i]=prime[j];
			primefactor[prime[j]*i]=primefactor[i]+1;
			if(mindiv[i]==prime[j])
			{
				break;
			}
		}
	}
	return 0;
}
int main()
{
	int l,r;
	register int i,j;
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%d%d",&l,&r);
	if(l>r)
	{
		swap(l,r);
	}
	euler(r);
	printf("%d\n",sum[r]-sum[l-1]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
