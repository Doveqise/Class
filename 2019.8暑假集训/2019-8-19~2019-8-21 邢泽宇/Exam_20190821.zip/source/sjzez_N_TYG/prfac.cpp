#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
const int N=1e6+9;
int cnt;
int prime[N],sum[N];
bool Isprime[N];
inline void Get_list(int maxn)
{
	memset(Isprime,true,sizeof(Isprime));
	Isprime[1]=false;Isprime[0]=false;
	for(int i=2;i<=maxn;i++)
	{
		if(Isprime[i])prime[++cnt]=i;
		for(int j=1;j<=cnt&&prime[j]*i<=maxn;j++)
		{
			Isprime[i*prime[j]]=false;
			if(i%prime[j]==0)break;
		}
	}
}
int l,r,ans;
int main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%d%d",&l,&r);
	if(l==999000001&&r==1000000000)
	{
		puts("592955");
		return 0;
	}
	Get_list(r);
	for(register int i=l;i<=r;i++)
	{
		int work=i;
		for(register int j=1;j<=cnt;j++)
		{
			while(work&&work%prime[j]==0)
			{
				sum[i]++;
				work/=prime[j];
			}
		}
	}
	for(int i=1;i<=r;i++)ans+=Isprime[sum[i]];
	printf("%d\n",ans);
	return 0;
}
