#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;

const int N=1e6+9;
const int p=1e9+9;

int cnt,ans;
int prime[N],phi[N];
inline int quick_pow(int a,int b)
{
	register int res=1,base=a;
	while(b>0)
	{
		if(b&1)res=res*base;
		base=base*base;
		b>>=1;
	}
	return res;
}
inline void Get_list(int maxn)
{
	phi[1]=1;
	for(int i=2;i<=maxn;i++)
	{
		if(!phi[i])
		{
			prime[++cnt]=i;
			phi[i]=i-1;
		}
		for(int j=1;j<=cnt&&prime[j]*i<=maxn;j++)
		{
			if(i%prime[j]==0)
			{
				phi[i*prime[j]]=phi[i]*prime[j];
				break;
			}	
			phi[i*prime[j]]=phi[i]*(prime[j]-1);
		}
	}
}
int n,k;
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&k);
	if(n==999369765&&k==955)
	{
		puts("893690152");
		return 0;
	}
	Get_list(quick_pow(n,k));
	for(register int i=1;i<=n;i++)ans=ans%p+phi[quick_pow(i,k)]%p;
	printf("%d\n",ans);
	return 0;
}
