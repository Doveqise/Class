#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#define debug cerr
using namespace std;
const int maxn = 3e5 + 1e2, lim = 3e5;
const int mod = 73939133;

int fac[maxn], inv[maxn];

inline int add(const int x, const int y) {
    const int ret = x + y;
    return ret >= mod ? ret - mod : ret;
}
inline int sub(const int x, const int y) {
    const int ret = x - y;
    return ret < 0 ? ret + mod : ret;
}
inline int mul(const int x, const int y) {
    return (long long) x * y % mod;
}
inline int fastpow(int base, int tim) {
    int ret = 1;
    while(tim) {
        if(tim & 1) ret = mul(ret, base);
        tim >>= 1, base = mul(base, base);
    }
    return ret;
}

inline void pre() {
    *fac = 1; for(int i = 1; i <= lim; i++) fac[i] = mul(fac[i - 1], i);
    inv[lim] = fastpow(fac[lim], mod - 2); for(int i = lim; i; i--) inv[i - 1] = mul(inv[i], i);
    // for(int i = 1; i <= 10; i++) debug << inv[i] << " "; debug << endl;
}
inline int c(int n, int m) {
    if(n < m) return 0;
    return mul(fac[n], mul(inv[m], inv[n - m]));
}


vector<int> v[maxn];
int fa[maxn], dep[maxn], top[maxn], siz[maxn], son[maxn];

inline void pre1(int pos) {
    siz[pos] = 1, son[pos] = 0;
    for(auto &t: v[pos]) if(t != fa[pos]) {
        fa[t] = pos, dep[t] = dep[pos] + 1;
        pre1(t), siz[pos] += siz[t];
        if(siz[t] > siz[son[pos]]) son[pos] = t;
    }
}
inline void pre2(int pos) {
    top[pos] = pos == son[fa[pos]] ? top[fa[pos]] : pos;
    for(auto &t: v[pos]) if(t != fa[pos]) pre2(t);
}
inline int lca(int x, int y) {
    while(top[x] != top[y]) {
        if(dep[top[x]] < dep[top[y]]) swap(x, y);
        x = fa[top[x]];
    }
    return dep[x] < dep[y] ? x : y;
}

int sp[maxn], se[maxn]; // se is the sum of the edge linking to cur;
int k, ans;

inline void dfs(int pos) {
    for(auto &t: v[pos]) if(t != fa[pos]) dfs(t), sp[pos] += sp[t], se[pos] += se[t];
    ans = add(ans, c(sp[pos], k)), ans = sub(ans, c(se[pos], k));
}

int main() {
    static int n, m;
    pre();
    freopen("cross.in", "r", stdin);
    freopen("cross.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &k), ans = 0;
    for(int i = 1; i <= n; i++) v[i].clear(), sp[i] = se[i] = 0;
    for(int i = 1, a, b; i < n; i++) scanf("%d%d", &a, &b), v[a].push_back(b), v[b].push_back(a);
    pre1(1), pre2(1);
    for(int i = 1, a, b, lc; i <= m; i++) {
        scanf("%d%d", &a, &b), lc = lca(a, b);
        if(a == b) ++sp[a], --sp[fa[a]];
        else if(lc == a || lc == b) {
            if(lc == b) swap(a, b);
            sp[b]++, sp[fa[a]]--;
            se[b]++, se[a]--;
        } else {
            sp[a]++, sp[b]++, sp[lc] -= 1, sp[fa[lc]] -= 1;
            se[a]++, se[b]++, se[lc] -= 2;
        }
    }
    dfs(1), printf("%d\n", ans);
    fclose(stdout);
    return 0;
}
