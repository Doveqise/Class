#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
namespace Moxing{
	const int mod=73939133;
	int n,m,k;
	struct main{
		main(){
			freopen("cross.in","r",stdin);
			freopen("cross.out","w",stdout);
			scanf("%d%d%d",&n,&m,&k);
			int x,y;
			for(int i=1;i<=n-1;i++){
				scanf("%d%d",&x,&y);
			}
			for(int i=1;i<=m;i++){
				scanf("%d%d",&x,&y);
			}
			
			exit(0);
		}
	}UniversalLove;
}
int main(){
	Moxing::main();
}
