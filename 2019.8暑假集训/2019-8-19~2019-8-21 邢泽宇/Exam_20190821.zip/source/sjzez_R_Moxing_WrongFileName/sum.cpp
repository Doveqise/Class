#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
namespace Moxing {
	const int mod=1e9+9;
	const int M=1e7+5;
	int n,k,ans;
	long long power(long long a,long long b) {
		long long ans=1;
		while(b) {
			if(b&1) {
				ans=(ans*a)%mod;
			}
			b>>=1;
			a=(a*a)%mod;
		}
		return ans;
	}
	long long getphi(long long x) {
		//if(x==1||x==2) return 1;
		long long res=x;
		for(int i=2;i<=sqrt(x);i++){
			if(x%i==0){
				res/=i,res*=(i-1);
				while(!(x%i)) x/=i;
			}
		}
		if(x^1) res/=x,res*=(x-1);
		return res;//ans%mod;
	}
struct main {
	main() {
		freopen("sum.in","r",stdin);
		freopen("sum.out","w",stdout);
		scanf("%d%d",&n,&k);
		if(!k) {
			cout<<n<<endl;
			exit(0);
		}
		for(int i=1;i<=n;i++){
			long long m=power(i,k);
			ans=(ans+getphi(m))%mod;
		}
		printf("%lld\n",ans);
		exit(0);
	}
} UniversalLove;
}
int main() {
	Moxing::main();
}
