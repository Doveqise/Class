#include<bits/stdc++.h>
using namespace std;
int Prime(int n)
{
	bool fl=0;
	if(n==1||n==0)return 0;
	for(int i=2;i<=sqrt(n);i++)
	{
		if(n%i==0){fl=1;break;}
	}
	if(fl==1)return 0;
	else return 1;
	float n_sqrt;
	if(n==1)return 0;
	if(n==2||n==3)return 1;
	if(n%6!=1&&n%6!=5)return 0;
	n_sqrt=floor(sqrt((float)n));
	for(int i=5;i<=n_sqrt;i+=6)
	{
		if(n%(i)==0|n%(i+2)==0)return 0;
	}
	return 1;
}
long long l,r,ans,n;
int prime[1000010];
int vis[1000010];
int phi[1000010];

int mark[1000010],tot;
void getphi(int N)
{
	phi[1]=1;
	for(int i=2;i<=N;i++)
	{
		if(!mark[i])
		{
			prime[++tot]=i;
			phi[i]=i-1;
		}
		for(int j=1;j<=tot;j++)
		{
			if(i*prime[j]>N)break;
			mark[i*prime[j]]=1;
			if(i%prime[j]==0)
			{
				phi[i*prime[j]]=phi[i]*prime[j];break;
			}
			else phi[i*prime[j]]=phi[i]*phi[prime[j]];
		}
	}
}
int main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	
	cin>>l>>r;
	if(r<=1000000)
	{
		getphi(r);
		while(l<=r)
		{
			n=l;
			int i,count=0;
			for(int i=2;i<=sqrt(n);i++)
			{
				while(n%i==0)
				{
					count++;
				n/=i;
				}
				if(n<1)break;
			}
			if(n>1)count++;
			if(phi[count]==count-1){ans++;}
			l++;
		}
	}
	if(r>1000000)
	{
		while(l<=r)
		{
			n=l;
			int i,count=0;
			for(int i=2;i<=sqrt(n);i++)
			{
				while(n%i==0)
				{
					count++;
				n/=i;
				}
				if(n<1)break;
			}
			if(n>1)count++;
			if(Prime(count))ans++;
			l++;
		}
	}
	cout<<ans;
	return 0;
}
