#include<bits/stdc++.h>
using namespace std;
const int mod=73939133;
long long C(long k,long m)
{
	long long shang=1;long long xia=1;
	for(int i=1;i<=m;i++)
	{
		shang*=i;
		shang%=mod;
	}
	for(int i=1;i<=k;i++)
	{
		xia*=i;
		xia%=mod;
	}
	for(int i=1;i<=m-k;i++)
	{
		xia*=i;
		xia%=mod;
	}
//	cout<<shang<<" "<<xia<<endl;
	return ((shang/xia)%mod);
}
long long n,m,k,sum,u,v,ch;
int main()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n-1;i++)
	{
		cin>>u>>v;
	}
	for(int i=1;i<m;i++)
	{
		cin>>u>>v;
		if(u==v)
		{
			ch++;
		}
	}
//	cout<<C(k,m)<<endl;
	sum=C(k,m)-ch-n+1;
	cout<<sum;
	return 0;
}
 
