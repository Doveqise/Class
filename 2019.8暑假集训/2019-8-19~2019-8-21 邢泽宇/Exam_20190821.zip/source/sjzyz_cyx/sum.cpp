#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int mod=1000000009;
ll n,k,sum;
ll euler(ll n)
{
	ll ans=n,a=n;
	for(int i=2;i*i<=n;i++)
	{
		if(a%i==0)
		{
			ans=(ans/i*(i-1))%mod;
			while(a%i==0) a/=i;
		}
	}
	if(a>1)ans=(ans/a*(a-1))%mod;
	return ans%mod;
}
ll ksm(ll a,ll b)
{
	ll res=1,base=a;
	while(b!=0)
	{
		if(b&1)
		{
			res=(res*base)%mod;
		}
		base=(base*base)%mod;
		b>>=1;
	}
	return res%mod;
}
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		//cout<<ksm(i,k)<<" "<<euler(ksm(i,k))<<endl;
		sum+=euler(ksm(i,k));
	}
	cout<<sum;
	return 0;
}
