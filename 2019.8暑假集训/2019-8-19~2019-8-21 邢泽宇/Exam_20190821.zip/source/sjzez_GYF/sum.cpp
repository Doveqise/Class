#include <bits/stdc++.h>
using namespace std;
namespace gengyf{
	inline int read(){
		int x=0,f=1;char s=getchar();
		while(s<'0'||s>'9'){if(s=='-')f=-1;s=getchar();}
		while(s>='0'&&s<='9'){x=x*10+s-'0';s=getchar();}
		return x*f;
	}
	const int N=1e6;
	const int mod=1e9+9;
	int vis[N],prime[N],phi[N];
	int n,k,ans;
	void euler(int n){
		memset(vis,0,sizeof(vis));
		int m=0;
		for(int i=2;i<=n;i++){
			if(vis[i]==0){
				vis[i]=i;prime[++m]=i;phi[i]=i-1;
			}
			for(int j=1;j<=m;j++){
				if(prime[j]>vis[i]||prime[j]>n/i)break;
				vis[i*prime[j]]=prime[j];
				phi[i*prime[j]]=phi[i]*(i%prime[j]?prime[j]-1:prime[j]);
			}
		}
	}
	int qpow(int x,int k){
		int tmp=1;
		while(k){
			if(k&1)tmp=tmp*x%mod;
			x=x*x%mod;
			k>>=1;
		}
		return tmp;
	}
	int main(){
		freopen("sum.in","r",stdin);
		freopen("sum.out","w",stdout);
		phi[1]=1;
		n=read();k=read();
		euler(qpow(n,k));
		for(int i=1;i<=n;i++){
			ans+=phi[qpow(i,k)];
			ans%=mod;
		}
		printf("%d",ans);
		fclose(stdin);fclose(stdout);
		return 0;
	}
}
int main(){
	gengyf::main();
	return 0;
}
