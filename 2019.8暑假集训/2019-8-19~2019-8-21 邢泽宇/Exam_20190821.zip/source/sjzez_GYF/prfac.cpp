#include <bits/stdc++.h>
using namespace std;
namespace gengyf{
	inline int read(){
		int x=0,f=1;char s=getchar();
		while(s<'0'||s>'9'){if(s=='-')f=-1;s=getchar();}
		while(s>='0'&&s<='9'){x=x*10+s-'0';s=getchar();}
		return x*f;
	}
	const int N=1e6;
	int sum[N],a[N],m,prime[N],vis[N],v[N];
	int p[N],c[N],cs[N],l,r;
	void Prime(){
		memset(vis,0,sizeof(vis));
		m=0;
		for(int i=2;i<=N;i++){
			if(vis[i]==0){
				vis[i]=i;prime[++m]=i;a[i]=1;v[i]=1;
			}
			for(int j=1;j<=m;j++){
				if(prime[j]>vis[i]||prime[j]>N/i)break;
				vis[i*prime[j]]=prime[j];
			}
		}
	}
	void divide(int n){
		int cnt=0;int mark=n;
		for(int i=1;prime[i]<=sqrt(n);i++){
			if(n%prime[i]==0){
				p[++cnt]=prime[i];c[cnt]=0;
				while(n%prime[i]==0){
					n/=prime[i];c[cnt]++;
				}
			}
		}
		if(n>1){
			p[++cnt]=n;c[cnt]=1;
		}
		for(int i=1;i<=cnt;i++){
			cs[mark]+=c[i];
		}
		if(v[cs[mark]]==1)a[mark]=0;
		else a[mark]=1;
	}
	int main(){
		freopen("prfac.in","r",stdin);
		freopen("prfac.out","w",stdout);
		Prime();
		for(int i=1;i<=N;i++){
			divide(i);
		}
		a[1]=1;
		for(int i=1;i<=N;i++){
			sum[i]=sum[i-1]+a[i];
		}
		l=read();r=read();
		printf("%d",r-sum[r]+l-sum[l]);
		fclose(stdin);fclose(stdout);
		return 0;
	}
}
int main(){
	gengyf::main();
	return 0;
}
