#include <cstdio>
#include <cstring>
#include <cctype>
#include <iostream>
#include <algorithm>

using namespace std;

namespace Primary
{

const int maxn = 5e6 + 10;
const int p = 1e9 + 9;
int prime[maxn], cnt = 0, n, k, phi[maxn];
bool vis[maxn];

void Euler(int n)
{
	vis[1] = true;
	phi[1] = 1;
	for (int i = 2; i <= n; ++i)
	{
		if (!vis[i])
		{
			prime[++cnt] = i;
			phi[i] = i - 1;
		}
		for (int j = 1; j <= cnt; ++j)
		{
			if (i * prime[j] > n) break;
			vis[i * prime[j]] = true;
			if (i % prime[j] == 0) 
			{
				phi[i * prime[j]] = phi[i] * prime[j];
				break;
			}
			phi[i * prime[j]] = phi[i] * (prime[j] - 1); 
		}
	}
}

inline int power(int a, int b, int p)
{
	int res = 1;
	while (b)
	{
		if (b & 1) res = 1ll * res * a % p;
		a = 1ll * a * a % p;
		b >>= 1;
	}
	return res;
}

void main()
{
	scanf("%d%d", &n, &k);
	Euler(power(n, k, p));
	int ans = 0;
	for (int i = 1; i <= n; ++i)
	{
		ans = ((long long)ans + phi[power(i, k, p)] % p) % p;
	}
	printf("%d", ans);
}

}

int main()
{
	freopen("sum.in", "r", stdin);
	freopen("sum.out", "w", stdout);
	Primary::main();
	return 0;
}
