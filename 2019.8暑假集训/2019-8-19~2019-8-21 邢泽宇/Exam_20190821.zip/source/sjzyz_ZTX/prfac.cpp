#include <cstdio>
#include <cstring>
#include <cctype>
#include <iostream>
#include <algorithm>

using namespace std;

namespace Primary
{

int L, R;
int prime[4000], cnt = 0, dp[32000];
bool vis[32000];

void Euler(int n)
{
	vis[0] = vis[1] = true;
	for (int i = 2; i <= n; ++i)
	{
		if (!vis[i])
			prime[++cnt] = i;
		for (int j = 1; j <= cnt; ++j)
		{
			if (i * prime[j] > n) break;
			vis[i * prime[j]] = true;
			if (i % prime[j] == 0) break;
		}
	}
}

int dfs(long long x, int p, int pos, int limit)
{
	if (x > limit) return 0;
	int res = (vis[p] ? 0 : 1);
	for (int i = pos; i <= cnt; ++i)
	{
		res += dfs(x * prime[i], p + 1, i, limit);
	}
	return res;
}

void main()
{
	scanf("%d%d", &L, &R);
	Euler(min(31627, R));
	printf("%d", dfs(1, 0, 1, R) - dfs(1, 0, 1, L - 1)); 
}

}

int main()
{
	freopen("prfac.in", "r", stdin);
	freopen("prfac.out", "w", stdout);
	Primary::main();
	return 0;
}
