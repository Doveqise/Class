#include <cstdio>
#include <cstring>
#include <cctype>
#include <iostream>
#include <algorithm>

using namespace std;

namespace Primary
{

const int p = 73939133;
const int maxn = 3e5 + 10;
int n, m, k, head[maxn], to[maxn << 1], next[maxn << 1], tot = 1;
int s[maxn], t[maxn], fa[maxn][20], depth[maxn], anc[maxn];

inline void add_edge(int u, int v)
{
	to[++tot] = v;
	next[tot] = head[u];
	head[u] = tot;
}

void dfs_init(int u, int pre)
{
	fa[u][0] = pre;
	depth[u] = depth[pre] + 1;
	for (int i = 1; (1 << i) <= depth[u]; ++i)
		fa[u][i] = fa[fa[u][i - 1]][i - 1];
	for (int c = head[u]; c; c = next[c])
	{
		if (to[c] != pre) dfs_init(to[c], u);
	}	
}

int lca(int x, int y)
{
	if (depth[x] < depth[y]) swap(x, y);
	for (int i = 18; i >= 0; --i)
	{
		if (depth[fa[x][i]] >= depth[y]) x = fa[x][i];
	}
	if (x == y) return y;
	for (int i = 18; i >= 0; --i)
	{
		if (fa[x][i] != fa[y][i])
		{
			x = fa[x][i];
			y = fa[y][i];
		}
	}
	return fa[x][0];
}	

void main()
{
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1, u, v; i < n; ++i)
	{
		scanf("%d%d", &u, &v);
		add_edge(u, v), add_edge(v, u);
	}
	int ans = 0;
	dfs_init(1, 0);
	for (int i = 1; i <= m; ++i)
	{
		scanf("%d%d", s + i, t + i);
		anc[i] = lca(s[i], t[i]);
		for (int j = 1; j < i; ++j)
		{
			bool flag = false;
			if (depth[anc[i]] <= depth[anc[j]]) 
			{
				swap(i, j);
				flag = true;
			}
			if (lca(anc[i], s[j]) == anc[j])
			{
				if (depth[anc[i]] <= depth[t[j]]) 
				{
					++ans;
					if (ans >= p) ans -= p;
				}
			}
			else if (lca(anc[i], t[j]) == anc[j])
			{
				if (depth[anc[i]] <= depth[s[j]]) 
				{
					++ans;
					if (ans >= p) ans -= p;
				}
			}
			if (flag) swap(i, j);
		}
	}
	printf("%d", ans);
}

}

int main()
{
	freopen("cross.in", "r", stdin);
	freopen("cross.out", "w", stdout);
	Primary::main();
	return 0;
}
