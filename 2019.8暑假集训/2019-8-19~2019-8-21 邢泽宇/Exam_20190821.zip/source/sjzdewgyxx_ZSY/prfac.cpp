#include<bits/stdc++.h>
using namespace std;
#define int long long
int p[200010];bool vis[200010];
inline bool ok(int x)
{
	for(int i=2;i*i<=x;++i)
	{
		if(x%i==0) return 0;
	}
	return 1;
}
inline bool check(int x)
{
	int q=0;
	for(int i=2;i*i<=x;++i)
	{
		while(x%i==0)
		{
			x/=i; q++;
		}
	}
	return ok(q);
}
signed main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	int l,r,ans=0;
	scanf("%d%d",&l,&r);
	for(int i=l;i<=r;++i)
	{
		if(check(i)) ans++;
	}
	cout<<ans<<endl;
	fclose(stdin);fclose(stdout);
	return 0;
}
