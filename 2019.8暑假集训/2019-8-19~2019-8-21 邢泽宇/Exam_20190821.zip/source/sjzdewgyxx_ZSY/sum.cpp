#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod=1e9+7;
inline int ksm(int x,int y)
{
	int res=1;
	for(;y;y>>=1)
	{
		if(y&1) res*=x;
		x*=x;
	}
	return res;
}
inline int phi(int x)
{
	int ans=x;
	for(int i=2;i*i<=x;++i)
	{
		if(x%i==0)
		{
			ans=ans/i*(i-1);
			while(x%i==0) x/=i;
		}
	}
	if(x!=1) ans=ans/x*(x-1);
	return ans;
}
signed main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	int n,k,ans=1;
	cin>>n>>k;
	for(int i=2;i<=n;++i)
	{
		ans+=phi(ksm(i,k));
		ans%=mod;
	}
	cout<<ans<<endl;
	return 0;
}
