#include<bits/stdc++.h>
using namespace std;
int u[1001],v[1001];
int main()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	int x,y;
	for(int i=1;i<n;++i) scanf("%d%d",&x,&y);
	for(int i=1;i<=m;++i) scanf("%d%d",&u[i],&v[i]);
	int ans=0;
	for(int i=1;i<=m;++i)
	{
		for(int j=1;j<i;++j)
		{
			if(u[i]==v[j]||u[i]==v[i]) ans++;
			else if(u[j]==v[i]||u[j]==v[j]) ans++;
			ans%=73939133;
		}
	}
	cout<<ans%73939133<<endl;
	return 0;
}
