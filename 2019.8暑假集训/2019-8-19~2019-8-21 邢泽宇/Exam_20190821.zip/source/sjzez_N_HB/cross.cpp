#include<iostream>
#include<cstdio>

using namespace std;


int main(){
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);	
	cout<<1;	
	
	return 0;
}
