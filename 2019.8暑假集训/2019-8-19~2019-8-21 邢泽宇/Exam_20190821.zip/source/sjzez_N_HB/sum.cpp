#include<iostream>
#include<cstdio>

using namespace std;
typedef long long ll;
const int mod=1e9+9;
int n, k, ans;

ll qm(int a, int b){
	ll tmp = 1;
	while(b){
		if(b & 1) tmp *= a;
		b >>= 1;
		a *= a;
	}
	return tmp;
}

ll phi(ll x){
	ll res = x;
	for(int  i = 2; i <= x / i; i ++){
		if(x % i == 0){
			res = res / i * (i - 1);
			while(x % i == 0) x /= i;
		}
	}
	if(x > 1) res = res / x * (x - 1);
	return res;
}

int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d", &n, &k);
	for(int i = 1;i <=n ;i ++){
		ans += phi(qm(i,k));
		ans %= mod;
	}
	printf("%d", ans%mod);
	return 0;
}
