#include<iostream>
#include<cstdio>

using namespace std;
const int N=1e7+10;
int ans, l, r;
int primes[N], cnt;
bool st[N];
bool isprime[N];

void getprime(int x){
	for(int i = 2; i <= x; i ++){
		 if (!st[i]) primes[cnt ++] = i;
		 for (int j = 0; primes[j] <= x / i; j ++ ){
		 	 st[primes[j] * i] = true;
		 	 if (i % primes[j] == 0) break;
		 }
	}
}

int divide(int x){
	int tmp = 0;
	for(int i = 2; i <= x/i ;i ++){
		if(x % i == 0){
			while(x%i == 0){
				x /= i;
				tmp++;
			}
		}
	}
	if(x > 1) tmp++;
	return tmp;
}

int main(){
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%d%d", &l, &r);
	int a=5000010;
	getprime(a);
	for(int i = 0; i < cnt; i++){
		isprime[primes[i]]=1;
	}
	for(int i = l; i <= r; i ++){
		if(isprime[divide(i)]) ans++;
	}
	printf("%d", ans);
	return 0;
}
