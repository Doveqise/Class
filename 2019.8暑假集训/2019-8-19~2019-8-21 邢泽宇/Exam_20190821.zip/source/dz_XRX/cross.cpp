#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

const int mod=73939133,N=300010,M=600010;
int head[N],nxt[M],ver[M],tot,n,m,k;
struct node{
	int x,y,lc;
}p[M];
inline void add(int x,int y){
	ver[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
int par[N],dep[N],f[N][30],sum[N];
inline void dfs(int x,int fa)
{
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==fa)continue;
		dep[y]=dep[x]+1;
		f[y][0]=par[y]=x;
		dfs(y,x);
	}
}  
inline int lca(int x,int y)
{
    if(dep[x]>dep[y])swap(x,y);
	for(int i=20;i>=0;i--){
	 if(dep[f[y][i]]>=dep[x])y=f[y][i];
	}
	if(x==y)return x;
	for(int i=20;i>=0;i--){
	 if(f[x][i]!=f[y][i]){
	 x=f[x][i],y=f[y][i];
	}
	}
	return f[x][0];	
}
int ans=0;
bool ff=0;
inline void dfs2(int x,int fa)
{
	if(ff)return; 
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==fa)continue;
		dfs2(y,x);
		sum[x]+=sum[y];
	}
	if(sum[x]>1)ff=1;
}
inline void work()
{
	for(int i=1;i<=m;i++){
		for(int j=i+1;j<=m;j++){
		memset(sum,0,sizeof(sum));
		sum[p[i].x]++;sum[p[i].y]++;sum[p[i].lc]--;sum[par[p[i].lc]]--;
		sum[p[j].x]++;sum[p[j].y]++;sum[p[j].lc]--;sum[par[p[j].lc]]--;
		dfs2(1,0);
		if(ff)ans++,ans%=mod,ff=0;
	}
	}
	printf("%d",ans);
} 
int main()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<n;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	dep[1]=1;
	dfs(1,0);
	for(int j=1;j<=20;j++){
		for(int i=1;i<=n;i++){
		f[i][j]=f[f[i][j-1]][j-1];
	}
	}
	for(int i=1;i<=m;i++){
		scanf("%d%d",&p[i].x,&p[i].y);
		p[i].lc=lca(p[i].x,p[i].y);
	}
	work();
	return 0;
}
