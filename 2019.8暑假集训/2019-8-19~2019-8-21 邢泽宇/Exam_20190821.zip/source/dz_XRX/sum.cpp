#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int n,k;
typedef long long ll;
const int mod=1e9+9;
inline ll phi(ll n){
	ll ans=n;
	ll t=sqrt(n);
	for(ll i=2;i<=t;i++){
		if(n%i==0){
			ans=ans/i*(i-1);
			while(n%i==0)n/=i;
		}
	}
	if(n>1)ans=ans/n*(n-1);
	return ans;
}
inline ll fastpow(ll x,int y)
{
	ll ans=1;
	if(x==1)return ans;
	for(;y;y>>=1){
		if(y&1)ans=ans*x;
		x*=x;
	}
	return ans;
}
inline ll fastpow2(ll x,ll y){
		ll ans=1;
	if(x==1)return ans;
	for(;y;y>>=1){
		if(y&1)ans=ans*x%mod;
		x=x*x%mod;
	}
	return ans%mod;
}
ll sum;
inline void work1()
{
	for(int i=1;i<=n;i++){
		sum=(sum+phi(fastpow(i,k)))%mod;
	}
	printf("%lld",sum%mod);
}
inline void work2()
{
	for(int i=1;i<=n;i++){
		sum=(sum+phi(fastpow2(i,k)))%mod;
	}
	printf("\n%lld",sum%mod);
}
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&k);
	if(n<=15){
		work1();
		return 0;
	}
    work2();
	return 0;
}
