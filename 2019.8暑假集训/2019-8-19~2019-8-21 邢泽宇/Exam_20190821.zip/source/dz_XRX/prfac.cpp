#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<vector>
using namespace std;
int l,r;
int ans;
int pri[51]={0,2,3,5,7,11,13,17,19,23,29};
inline int divide(int n)
{
	int m=0;
	int t=sqrt(n);
	for(int i=2;i<=t;i++){
		if(n%i==0){
			while(n%i==0)n/=i,m++;
		}
	}
	if(n>1)m++;
	return m;
}
inline bool check(int x)
{
	if(x<2)return false;
	int t=sqrt(x);
	for(int i=2;i<=t;i++){
		if(x%i==0)return false;
	}
	return true;
}
inline void work()
{
	for(int i=l;i<=r;i++){
	 if(check(divide(i)))ans++;
	}
	printf("%d",ans);
}
int main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%d%d",&l,&r);
	if(l<=100000&&r<=100000){
	work();
	return 0;
	}
	return 0;
}
