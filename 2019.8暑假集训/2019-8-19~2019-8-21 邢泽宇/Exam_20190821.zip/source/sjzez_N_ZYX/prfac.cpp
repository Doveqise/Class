// z7z_Eta
#include<cstdio>
#include<cctype>
#include<cstring>
#include<algorithm>
#include<cmath>
#define re register
#define ll long long
#define il inline
#define rep(i,s,t) for(re int i=(s);i<=(t);i++)
#define each(i,u) for(int i=head[u];i;i=bow[i].nxt)
#define pt(ch) putchar(ch)
#define pti(x) printf("%d",x)
#define ptll(x) printf("%lld",x)
#define file(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout)
using namespace std;
il int ci(){
	re char ch; int f=1;
	while(!isdigit(ch=getchar()))f= ch=='-'?-1:1;
	re int x=ch^'0';
	while(isdigit(ch=getchar()))x= (x*10)+(ch^'0');
	return f*x;
}
enum{N=1000024};
int init_n,prime_size;
int prime[N],mindiv[N];
int cnt[N];
void euler(int n){
	prime[0]= -1;
	int tot= 0;
	rep(i,2,n){
		if( !mindiv[i] ){
			prime[ mindiv[i]=++tot ]= i;
			cnt[i]= 1;
		}
		rep(j,1,mindiv[i]){
			int x= i*prime[j];
			if( x>n ) break;
			mindiv[x]= j;
			cnt[x]= cnt[i]+1;
		}
	}
	prime_size= tot;
//	rep(i,1,tot) printf("%d ",prime[i]);pt('\n');
}
il bool isprime(int x){
	return prime[mindiv[x]]==x;
}
int cnt2[N],num[N];
void es(int l,int r){
	rep(i,l,r) num[i-l]= i;
	rep(i,1,prime_size){
		for(re int j=((l+prime[i]-1)/prime[i])*prime[i];j<=r;j+=prime[i]){
			while( num[j-l]%prime[i]==0 ){
				num[j-l]/=prime[i];
				cnt2[j-l]++;
			}
		}
	}
	rep(i,l,r) if( num[i-l]!=1 ) cnt2[i-l]++;
//	rep(i,l,r) printf("%d : %d\n",i,cnt2[i-l]);
}
int main(){
	file("prfac");
	int l=ci(), r=ci();
	init_n= sqrt(r+0.5);
	euler(init_n);
	es(l,r);
	int ans= 0;
	rep(i,l,r) if( isprime(cnt2[i-l]) ) ans++;//, printf("%d ",i); pt('\n');
	pti(ans);
	return 0;
}
/*
999000001 1000000000
*/
