// z7z_Eta
#include<cstdio>
#include<cctype>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<unordered_map>
#define re register
#define ll long long
#define il inline
#define rep(i,s,t) for(re int i=(s);i<=(t);i++)
#define rev_rep(i,s,t) for(re int i=(s);i>=(t);i--)
#define each(i,u) for(int i=head[u];i;i=bow[i].nxt)
#define pt(ch) putchar(ch)
#define pti(x) printf("%d",x)
#define ptll(x) printf("%lld",x)
#define file(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout)
using namespace std;
il int ci(){
	re char ch; int f=1;
	while(!isdigit(ch=getchar()))f= ch=='-'?-1:1;
	re int x=ch^'0';
	while(isdigit(ch=getchar()))x= (x*10)+(ch^'0');
	return f*x;
}
enum{N=6000024};
const int mod= 1e9+9;
void exgcd(ll a,ll b,ll&x,ll&y){
	if( !b ){ x=1,y=0; return; }
	exgcd(b,a%b,y,x); y-= x*(a/b);
}
il ll inv(ll a){
	ll x,y;
	exgcd(a,mod,x,y);
	return (x+mod)%mod;
}
il ll qpow(ll a,int b){
	ll ans= 1;
	while( b ){
		if( b&1 ) ans= ans*a%mod;
		a= a*a%mod;
		b>>=1;
	}
	return ans;
}

int init_n,prime_size;
int prime[N],mindiv[N];
ll phi[N];
void euler(int n,int k){
//	printf("init_ %d\n",n);
	init_n= n;
	prime[0]= -1;
	int tot= 0;
	phi[1]= 1;
	rep(i,2,n){
		if( !mindiv[i] ){
			prime[ mindiv[i]=++tot ]= i;
			phi[i]= i-1;
		}
		rep(j,1,mindiv[i]){
			int x= i*prime[j];
			if( x>n ) break;
			mindiv[x]= j;
			phi[x]= phi[i] * ( i%prime[j]? (prime[j]-1):prime[j] );
		}
	}
//	rep(i,1,n) printf("%lld ",phi[i]);pt('\n');
	rep(i,1,n) phi[i]= (phi[i-1] + phi[i]*qpow(i,k))%mod;
//	rep(i,1,n) printf("%lld ",phi[i]);pt('\n');
	prime_size= tot;
}

enum{K=1024};
ll y0[K],y1[K];
int k0,k1;
void init(int k){
	k0= k+1, k1= k+2;
	rep(i,1,k0) y0[i]= (y0[i-1]+qpow(i,k-1))%mod;
	rep(i,1,k0){
		ll now= 1;
		rep(j,1,k0) if( i!=j ) now = now*(i-j)%mod;
		y0[i]= y0[i]*inv((now+mod)%mod)%mod;
	}
	rep(i,1,k1) y1[i]= (y1[i-1]+qpow(i,k))%mod;
	rep(i,1,k1){
		ll now= 1;
		rep(j,1,k1) if( i!=j ) now = now*(i-j)%mod;
		y1[i]= y1[i]*inv((now+mod)%mod)%mod;
	}
}
ll pre[K],suf[K];
il ll pk0(ll x){
	pre[0]= suf[k0+1]= 1;
	rep(i,1,k0) pre[i]= pre[i-1]*(x-i)%mod;
	rev_rep(i,k0,1) suf[i]= suf[i+1]*(x-i)%mod;
	ll ans= 0;
	rep(i,1,k0) ans= (ans+(pre[i-1]*suf[i+1]%mod*y0[i]))%mod;
	return ans;
}
il ll pk1(ll x){
	pre[0]= suf[k1+1]= 1;
	rep(i,1,k1) pre[i]= pre[i-1]*(x-i)%mod;
	rev_rep(i,k1,1) suf[i]= suf[i+1]*(x-i)%mod;
	ll ans= 0;
	rep(i,1,k1) ans= (ans+(pre[i-1]*suf[i+1]%mod*y1[i]))%mod;
	return ans;
}

unordered_map<int,ll> Phi;
ll Sum(int n){
	if( n<=init_n ) return phi[n];
	if( Phi.count(n) ) return Phi[n];
	ll ans= pk1(n);
//	printf("pk1 : %lld\n",pk1(n));
//	printf("pk0 : %lld\n",pk0(n));
	int l,r;
	for(l=2;l<=n;l=r+1){
		r= n/(n/l);
		ans= (ans-(pk0(r)-pk0(l-1))*Sum(n/l)%mod)%mod;
	}
//	printf("%d : %lld\n",n,(ans%mod+mod)%mod);
	return Phi[n]= (ans%mod+mod)%mod ;
}
int main(){
	file("sum");
	int n=ci(), k=ci();
	euler(pow(n,0.75),k-1);
	init(k);
//	printf("%lld %lld\n",pk0(3),(pk1(3)+mod)%mod);
	ptll(Sum(n));
	return 0;
}
/*
500 300
1000000000 5
999369765 955
*/
