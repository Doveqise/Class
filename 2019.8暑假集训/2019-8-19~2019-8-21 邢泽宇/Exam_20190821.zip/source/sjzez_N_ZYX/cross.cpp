// z7z_Eta
#include<cstdio>
#include<cctype>
#include<cstring>
#include<algorithm>
#include<cmath>
#define re register
#define ll long long
#define il inline
#define rep(i,s,t) for(re int i=(s);i<=(t);i++)
#define each(i,u) for(int i=head[u];i;i=bow[i].nxt)
#define pt(ch) putchar(ch)
#define pti(x) printf("%d",x)
#define ptll(x) printf("%lld",x)
#define file(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout)
using namespace std;
il int ci(){
	re char ch; int f=1;
	while(!isdigit(ch=getchar()))f= ch=='-'?-1:1;
	re int x=ch^'0';
	while(isdigit(ch=getchar()))x= (x*10)+(ch^'0');
	return f*x;
}
enum{N=1024};
const int mod= 73939133;
class Edge{
public:
	int nxt,to;
	il void operator()(int a,int b){
		nxt= a, to= b;
	}
}bow[N*2];
int head[N],cnt[N];
int t;
bool dfs(int u,int ue){
	cnt[u]++;
	if( u==t ) return 1;
	each(i,u) if( i^ue^1 ){
		int v= bow[i].to;
		if( dfs(v,i) ) return 1;
	}
	cnt[u]--;
	return 0;
}
int x[N],y[N];
int main(){
	file("cross");
	int n=ci(), m=ci(), k=ci();
	rep(i,2,n){
		int x=ci(), y=ci();
		bow[i<<1](head[x],y);
		bow[i<<1|1](head[y],x);
		head[y]= (head[x]=i<<1)|1;
	}
	rep(i,0,m-1){
		x[i]=ci(), y[i]=ci();
	}
	int full= (1<<m)-1;
	int ans= 0;
	rep(S,1,full){
		int cnt1= 0;
		rep(i,0,m-1) if( S&(1<<i) ) cnt1++;
		if( cnt1==k ){
			memset(cnt,0,sizeof(cnt));
			rep(i,0,m-1) if( S&(1<<i) ){
				t= y[i];
				dfs(x[i],0);
			}
			rep(i,1,n) if( cnt[i]==k ){
				ans++; break;
			}
		}
	}
	pti(ans);
	return 0;
}
/*
3 6 2
1 2
1 3
1 1
2 2
3 3
1 2
1 3
2 3
*/
