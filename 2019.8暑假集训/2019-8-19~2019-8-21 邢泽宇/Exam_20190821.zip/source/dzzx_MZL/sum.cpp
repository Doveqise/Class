#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
#define ll long long
ll n,k;
const int mod=1e9+9;
ll power(ll a,ll p)
{
	ll s=1;
	for(;p;p>>=1){
		if(p&1) s=s*a%mod;
		a=a*a%mod;
	}
	return s;
}
ll phi(ll n)
{
	ll ans=n;
	for(int i=2;i<=sqrt(n);++i)
	if(n%i==0){
		ans=ans/i*(i-1);
		while(n%i==0) n/=i;
	} 
	if(n>1) ans=ans/n*(n-1);
	return ans;
}
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	cin>>n>>k;
	ll ans=0;
	for(ll i=1;i<=n;++i){
		ans+=phi(power(i,k));
		ans%=mod;
	}
	cout<<ans;
}
