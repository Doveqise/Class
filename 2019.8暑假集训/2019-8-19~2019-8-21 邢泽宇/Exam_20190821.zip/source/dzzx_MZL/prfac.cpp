#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;
int v[1000010],prim[500000],num[1000010],d[1000010];
bool vv[1000010];
int l,r,m;
void primes(int n)
{
	for(int i=2;i<=n;++i)
	{
		if(v[i]==0)
		{
			v[i]=i;prim[++m]=i;d[i]=m;
		}
		for(int j=1;j<=m;++j)
		{
			if(prim[j]>v[i]||prim[j]>n/i) break;
			v[i*prim[j]]=prim[j];
		}
	}
}
int main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	cin>>l>>r;
	primes(r);
	for(int i=2;i<=r;++i){
		if(v[i]==i){
			for(int j=d[i];j<=m;++j){
				int k=i*prim[j];
				if(k>r) break;
				num[k]=2;
				vv[k]=1;
			}
		}
		else{
			if(v[num[i]+1]==num[i]+1){
				for(int j=1;j<=m;++j){
				int k=i*prim[j];
				if(k>r) break;
				num[k]=num[i]+1;
				vv[k]=1;
				}
			}
			else{
				for(int j=1;j<=m;++j){
				int k=i*prim[j];
				if(k>r) break;
				num[k]=num[i]+1;
				}
			}
		}
	}
	int ans=0;
	for(int i=l;i<=r;++i) if(vv[i]) ans++;
	cout<<ans;
	return 0; 
}
