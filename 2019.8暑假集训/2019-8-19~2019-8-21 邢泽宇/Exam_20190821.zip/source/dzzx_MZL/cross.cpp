#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int head[1100],ver[2100],nxt[2100],xx[1100],yy[1100],d[1100];
int n,m,k,tot;
int f[1100][21];
void add(int x,int y)
{
	ver[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
void dfs(int x,int fa)
{
	d[x]=d[fa]+1;
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==fa) continue;
		f[y][0]=x;	
		for(int i=1;i<=20;i++) f[y][i]=f[f[y][i-1]][i-1];
		dfs(y,x);
	}
}
int lca(int a,int b)
{
    if(a==b) return a;
	if(d[a]>d[b]) swap(a,b);
	for(int i=20;i>=0;--i)
	if(d[f[b][i]]>=d[a]) b=f[b][i];
	if(a==b) return a;
	for(int i=20;i>=0;--i)
	if(f[a][i]!=f[b][i]) a=f[a][i],b=f[b][i];
	return f[a][0];
}
bool judge(int a,int b,int c,int r)
{
	int x=lca(a,b),y=lca(c,r);
	int D1=d[a]+d[b]-2*d[x];
	int D2=d[c]+d[r]-2*d[y];
	int d1=d[c]+d[x]-2*d[lca(c,x)]+d[r]+d[x]-2*d[lca(r,x)];
	int d2=d[a]+d[y]-2*d[lca(a,y)]+d[b]+d[y]-2*d[lca(b,y)];
	if(D1==d2||D2==d1) return true;
	return false;
}
int main()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<n;++i){
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	dfs(1,0);tot=0;
	if(k==2)
	{
		int ans=0;
		for(int i=1;i<=m;++i){
			scanf("%d%d",&xx[i],&yy[i]);
			for(int j=1;j<i;j++) if(judge(xx[j],yy[j],xx[i],yy[i])) ans++;
		}
		cout<<ans;
		return 0;
	}
	if(k==3)
	{
		int ans=0;
		for(int i=1;i<=m;++i){
			scanf("%d%d",&xx[i],&yy[i]);
			for(int j=1;j<i;++j)
			for(int j1=1;j1<j;++j1)
			if(judge(xx[j],yy[j],xx[i],yy[i])||judge(xx[j1],yy[j1],xx[i],yy[i])||judge(xx[j],yy[j],xx[j1],yy[j1]))
			ans++;
		}
		cout<<ans;
		return 0;
	}
	if(k==4)
	{
		int ans=0;
		for(int i=1;i<=m;++i){
			scanf("%d%d",&xx[i],&yy[i]);
			for(int j1=1;j1<i;j1++) 
			for(int j2=1;j2<j1;j2++)
			for(int j3=1;j3<j2;j3++){
			if(judge(xx[j1],yy[j1],xx[i],yy[i])){ans++;continue;}
			if(judge(xx[j2],yy[j2],xx[i],yy[i])){ans++;continue;}
			if(judge(xx[j3],yy[j3],xx[i],yy[i])){ans++;continue;}
			if(judge(xx[j2],yy[j2],xx[j1],yy[j1])){ans++;continue;}
			if(judge(xx[j3],yy[j3],xx[j1],yy[j1])){ans++;continue;}
			if(judge(xx[j3],yy[j3],xx[j2],yy[j2])){ans++;continue;}
			}
		}
		cout<<ans;
		return 0;
	}
	if(k==5)
	{
		int ans=0;
		for(int i=1;i<=m;++i){
			scanf("%d%d",&xx[i],&yy[i]);
			for(int j1=1;j1<i;j1++) 
			for(int j2=1;j2<j1;j2++)
			for(int j3=1;j3<j2;j3++)
			for(int j4=1;j4<j3;j4++)
			{
			if(judge(xx[j1],yy[j1],xx[i],yy[i])){ans++;continue;}
			if(judge(xx[j2],yy[j2],xx[i],yy[i])){ans++;continue;}
			if(judge(xx[j3],yy[j3],xx[i],yy[i])){ans++;continue;}
			if(judge(xx[j2],yy[j2],xx[j1],yy[j1])){ans++;continue;}
			if(judge(xx[j3],yy[j3],xx[j1],yy[j1])){ans++;continue;}
			if(judge(xx[j3],yy[j3],xx[j2],yy[j2])){ans++;continue;}			
			if(judge(xx[j4],yy[j4],xx[i],yy[i])){ans++;continue;}
			if(judge(xx[j4],yy[j4],xx[j2],yy[j2])){ans++;continue;}
			if(judge(xx[j4],yy[j4],xx[j1],yy[j1])){ans++;continue;}
			if(judge(xx[j4],yy[j4],xx[j3],yy[j3])){ans++;continue;}
			}
		}
		cout<<ans;
		return 0;
	}
}
