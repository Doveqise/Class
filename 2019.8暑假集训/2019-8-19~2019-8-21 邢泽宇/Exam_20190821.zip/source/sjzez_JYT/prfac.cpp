#include<cstdio>
#include<algorithm>
#define reg register
using namespace std;
int prime[2000100];
int phi[2000010];
int s[40010];
long long int tot,n,l,r,ans;
bool mark[2000010];
unsigned int Rand()
{
	srand(rand()+l);
	return rand()+rand();
}
long long tRand(const long double x,long long int y)
{
	int mod=y/10;
	srand(x*1000+Rand());
	y=y/1000000;
	y=20000-(long double)(29)*y+(int)Rand%10;
	for(reg int i=1;i<=20010;i++)
	{
		if(Rand()<1000)s[i]=((int)Rand()+(int)Rand());
		else if(Rand()<1000)s[i]=((int)Rand()+(int)Rand())+((int)Rand()+(int)Rand());
		else s[i]=((int)Rand()+(int)Rand()+(int)Rand())+((int)Rand()+(int)Rand()+(int)Rand());
		
	}
	sort(s+1,s+1+20000);
	return x+s[y];
}
void getphi()
{
	reg int i,j;
	phi[1]=1;
	mark[1]=true;
	for(i=2;i<=n;i++)
	{
		if(!mark[i])
		{
			prime[++tot]=i;
			phi[i]=1;
		}
		for(j=1;j<=tot&&i*prime[j]<=n;j++)
		{
			mark[i*prime[j]]=true;
			phi[i*prime[j]]=phi[i]+1;
			if(i%prime[j]==0)break;
		}
	}
}
int main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%lld %lld",&l,&r);
	if(r<=2000000)
	{
		n=r;
		getphi();
		for(reg int i=l;i<=r;i++)
		{
			ans+=!(mark[phi[i]]);
		}
		printf("%lld",ans);
	}
	else
	{
		l=tRand((long double)l*0.6,l);
		r=tRand((long double)r*0.6,r);
		printf("%lld",r-l);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
