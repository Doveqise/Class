#include<cstdio>
#define reg register
#define mod 1000000009
long long int phi[10000010];
long long int phik_[1000010];
int prime[1000100];
long long int tot,ans,n,k;
bool mark[10000010];
inline long long int quickpow(long long int x,long long int k)
{
	long long ans=1,y=x;
	while(k)
	{
		if(k&1)ans=ans*y%mod;
		y=y*y%mod;
		k/=2;
	}
	return ans;
} 
void getphi()
{
	int i,j;
	phi[1]=1;
	for(i=2;i<=n;i++)
	{
		if(!mark[i])
		{
			prime[++tot]=i;
			phik_[tot]=quickpow((long long )i,k-1);
			phi[i]=(i-1)*phik_[tot]%mod;
		}
		for(j=1;j<=tot&&i*prime[j]<=n;j++)
		{
			mark[i*prime[j]]=true;
			if(i%prime[j]==0)
			{
				phi[i*prime[j]]=phi[i]*prime[j]%mod*phik_[j];
				break;
			}
			else phi[i*prime[j]]=phi[i]*(prime[j]-1)%mod*phik_[j]%mod;
		}
	}
}
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	getphi();
	for(reg int i=1;i<=n;i++)
	{
		ans=(ans+phi[i])%mod;
	}
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
