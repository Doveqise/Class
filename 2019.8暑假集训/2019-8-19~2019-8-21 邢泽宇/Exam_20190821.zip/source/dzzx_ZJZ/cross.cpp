#include<iostream>
#include<cstdio>
#define  R register
#include<cstring>
typedef long long LL;
using namespace std;
int n,m,k;
const int mod=73939133;
int tot=1,head[300100],ver[600100],nex[600100];
int a[300100],b[300100];
inline void add(int x,int y)
{
	ver[++tot]=y;nex[tot]=head[x];head[x]=tot;
}
LL ans=1;
bool v[300100];
int fa[300100],top[300100],son[300100],size[300100],dep[300100];

void dfs(int x,int f)
{
	size[x]=1;
	fa[x]=f;
	dep[x]=dep[f]+1;
	for(R int i=head[x];i;i=nex[i])
	{
		if(ver[i]==f) continue;
		dfs(ver[i],x);
		size[x]+=size[ver[i]];
		if(size[ver[i]]>size[son[x]]) son[x]=ver[i];
	}
}
void dfs2(int x,int f)
{
	if(son[x])
	{
		top[son[x]]=top[x];
		dfs2(son[x],x);
	}
	for(R int i=head[x];i;i=nex[i])
	{
		if(top[ver[i]]) continue;
		top[ver[i]]=ver[i];
		dfs2(ver[i],x);
	}
}
int LCA(int x,int y)
{
	while(top[x]!=top[y])
	{
		if(dep[top[x]]>dep[top[y]])
		{
			x=fa[top[x]];
		}
		else
		{
			y=fa[top[y]];
		}
	}
	if(dep[x]>dep[y]) return y;
	else return x;
}
bool chick(int x,int y,int lc)
{
	while(x!=lc) 
	{
		if(v[x]) return 1;
		x=fa[x];
	}
	while(y!=lc)
	{
		if(v[y]) return 1;
		y=fa[y];
	}
	if(v[lc] )return 1;
	return 0;
}
void did(int x,int now)
{
	if(now==k)
	{
		ans--;
		return;
	}
	if(x>m) return;
	if(!chick(a[x],b[x],LCA(a[x],b[x])))
	{
		int l=LCA(a[x],b[x]);
		int p=a[x],q=b[x];
		while(p!=fa[l]) v[p]=1,p=fa[p];
		while(q!=fa[l]) v[q]=1,q=fa[q];
		did(x+1,now+1);
		p=a[x],q=b[x];
		while(p!=fa[l]) v[p]=0,p=fa[p];
		while(q!=fa[l]) v[q]=0,q=fa[q];		
	}
	did(x+1,now);
}
inline LL q_mul(LL p,int q)
{
	LL an=1;
	for(;q;q>>=1,p=(p*p)%mod)if(q&1) an=(an*p)%mod;
	return an%mod;
}
int main ()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(R int i=1,x,y;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	dfs(1,0);
	top[1]=1;
	dfs2(1,0);
	for(R int i=1;i<=m;i++)
	{
		scanf("%d%d",&a[i],&b[i]);
	}
	for(R int i=m;i>=m-k+1;i--)	(ans*=i)%=mod;
	int la=1;for(R int i=1;i<=k;i++) (la*=i)%=mod;
	ans=(ans*q_mul(la,mod-2))%mod;
	did(1,0);
	printf("%lld",ans);
	return 0;
}
