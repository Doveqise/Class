#include<iostream>
#include<cstdio>
#include<cstring>
typedef long long LL;
using namespace std;
#define  R register
const int mod=1e9+9;
int n,k;
LL ans;
int tot,prim[600100],phi[10000002];
inline LL q_mul(LL a,int b)
{
	LL an=1;
	for(;b;b>>=1,a=(a*a)%mod)if(b&1) an=(an*a)%mod;
	return an%mod;
}
int ph(int x)
{
	int y=x;
	for(R int i=2;i*i<=x;i++)
	{
		if(x%i==0)
		{
			y/=i;y*=(i-1);
			while(x%i==0) x/=i;
		}
	}
	if(x>1) y/=x,y*=x-1;
	return y%mod;
}
int main ()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&k);
	if(n<=10000000)
	{
		ans++;
		for(R int i=2;i<=n;i++)
		{
			if(!phi[i]) prim[++tot]=i,phi[i]=i-1;
			ans=(ans+(LL)phi[i]*(q_mul(i,k-1))%mod)%mod;
			for(R int j=1;j<=tot;j++)
			{
				if(prim[j]*i>n) break;
				if(i%prim[j]!=0)	phi[prim[j]*i]=phi[i]*(prim[j]-1);
				else phi[prim[j]*i]=phi[i]*(prim[j]);
			}
		}
		printf("%lld\n",ans%mod);
	}
	else
	{
		ans=0;
		ans++;
		for(R int i=2;i<=n;i++)
		{
			ans=(ans+(LL)ph(i)*q_mul(i,k-1)%mod)%mod;
		}
		printf("%lld",ans%mod);
	}
	return 0;
}

