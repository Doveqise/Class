#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define  R register
using namespace std;
int l,r,ans;
bool v[100010000];
int tot,prim[8000100],f[100010000];
int main ()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%d%d",&l,&r);
	v[1]=1;
	for(R int i=2;i<=r;i++)
	{
		if(!f[i]) prim[++tot]=i,f[i]=1;
		if(i>=l) if(!v[f[i]]) ans++;
		for(R int j=1;j<=tot;j++)
		{
			if(prim[j]*i>r) break;
			if(v[prim[j]*i]) break;
			v[prim[j]*i]=1;
			f[prim[j]*i]=f[prim[j]]+f[i];
		}
	}
	printf("%d",ans);
	return 0;
}
