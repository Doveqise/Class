#include<bits/stdc++.h>
#define reg register
using namespace std;
const int maxx=300100;
const int mod=73939133;
int n,m,k,t,tot,ans,ver[maxx<<1],head[maxx<<1],next[maxx<<1],a[maxx][2],dep[maxx],f[maxx][20];
queue<int> q;
inline int read(){
	int s=0,w=1;
	char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)) s=s*10+ch-'0',ch=getchar();
	return s*w;
}
inline void add(int x,int y){
	ver[++tot]=y,next[tot]=head[x],head[x]=tot;
}
inline void bfs(){
	q.push(1),dep[1]=1;
	while(q.size()){
		int x=q.front();q.pop();
		for(reg int i=head[x];i;i=next[i]){
			int y=ver[i];
			if(dep[y]) continue;
			dep[y]=dep[x]+1;
			f[y][0]=x;
			for(reg int j=1;j<=t;j++) f[y][j]=f[f[y][j-1]][j-1];
			q.push(y);
		}
	}
}
inline int lca(int x,int y){
	if(dep[x]>dep[y]) swap(x,y);
	for(reg int i=t;i>=0;i--)
	if(dep[f[y][i]]>=dep[x]) y=f[y][i];
	if(x==y) return x;
	for(reg int i=t;i>=0;i--)
	if(f[x][i]!=f[y][i]) x=f[x][i],y=f[y][i];
	return f[x][0];
}
inline int C(int m,int n){
	int f1=1,f2=1,f3=1;
	for(reg int i=1;i<=n;i++) f1*=i,f1%=mod;
	for(reg int i=1;i<=m;i++) f2*=i,f2%=mod;
	for(reg int i=1;i<=n-m;i++) f3*=i,f3%=mod;
	return (f1/(f2*f3))%mod;
}
int main()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	n=read(),m=read(),k=read();
	if(k==1||k>m){
		printf("0\n");
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	t=(int)(log(n)/log(2))+1;
	for(reg int i=1;i<n;i++){
		int x=read(),y=read();
		add(x,y),add(y,x); 
	}
	bfs();
	for(reg int i=1;i<=m;i++) a[i][0]=read(),a[i][1]=read();
	for(reg int i=1;i<=m;i++)
	for(reg int j=i+1;j<=m;j++){
		int r1=lca(a[i][0],a[i][1]);
		int r2=lca(a[j][0],a[j][1]);
		if(dep[r1]<dep[r2]){
			swap(r1,r2);
			swap(a[i][0],a[j][0]);
			swap(a[i][1],a[j][1]);
		}
		if(lca(r1,a[j][0])==r1||lca(r1,a[j][1])==r1) ans++,ans%=mod;
	}
	if(k==2){
		printf("%d\n",ans);
		fclose(stdin);
		fclose(stdout); 
		return 0;
	}
	printf("%d\n",(ans*C(k-2,m-2))%mod);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
