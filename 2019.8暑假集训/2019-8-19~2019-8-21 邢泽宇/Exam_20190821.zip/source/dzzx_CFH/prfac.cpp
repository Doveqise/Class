#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=1e8+2;
int l,r,ans;
bool v[N];
int stack[N],top;
inline int read()
{
	int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*w;
}

int main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	l=read();r=read();
	int t=sqrt(r);
	for(int i=2;i<=t;i++)
	{
		if(!v[i])
		{
			for(int j=i;j*i<=r;j++)
			v[i*j]=1;
			
		}
	}
	for(int i=2;i<=r;i++)
	if(!v[i]) stack[++top]=i;
    for(int i=l;i<=r;i++)
    {
    	if(i==1) continue;
    	if(v[i]==0) continue;
    	int cnt=0;
    	for(int j=1;j<=top;j++)
    	{
    		int s=i;
    		while((s%stack[j]==0))
    		{
    			cnt++;
    			s=(s/stack[j]);
    		}
    	}
    	if(!v[cnt]) ans++;
    }
    printf("%d\n",ans);
    return 0;
}
