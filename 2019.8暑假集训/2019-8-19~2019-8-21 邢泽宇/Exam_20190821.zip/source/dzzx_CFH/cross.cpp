#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=1005;
const int mod=73939133;
int n,m,k,tot,top;
int ver[N*2],Next[N*2],Head[N],jie[N],inv[N];
int stack[1005][500];
int pre[N];
bool flag=0;
int stop;
inline int read()
{
	int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*w;
}

void add(int x,int y)
{
	ver[++tot]=y;Next[tot]=Head[x];Head[x]=tot;
}

void dfs(int color,int x,int fa)
{
	if(flag) return;
	for(int i=Head[x];i;i=Next[i])
	{
		int y=ver[i];
		if(y==fa) 
		{
			
			for(int j=y;j!=stop;j=pre[j]) stack[color][++top]=j;
			stack[color][++top]=stop;
			flag=1;
			return;
		}
		pre[y]=x;
		dfs(color,y,fa);
	}
}
long long C(int x,int y)
{
	if(y>x) return 0;
	if(x<mod) return jie[x]*inv[y]%mod*inv[x-y]%mod;
	return C(x%mod,y%mod)*C(x/mod,y/mod)%mod;
}

int main()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	n=read();m=read();
	k=read();
	jie[0]=inv[0]=inv[1]=1;
	for(int i=1;i<=m;i++) jie[i]=jie[i-1]*i%mod;
	for(int i=2;i<=m;i++) inv[i]=(mod-mod/i)*inv[mod%i]%mod;
	for(int i=2;i<=m;i++) inv[i]=inv[i-1]*i%mod; 
	for(int i=1;i<=n-1;i++)
	{
		int x,y;
		x=read();y=read();
		add(x,y);
		add(y,x);
	}
	for(int i=1;i<=m;i++)
	{
		int u,v;
		u=read();v=read();
		flag=0;
		top=0;
		stop=u;
		dfs(i,u,v);
	}
	cout<<C(m,k)<<endl;
	
}
