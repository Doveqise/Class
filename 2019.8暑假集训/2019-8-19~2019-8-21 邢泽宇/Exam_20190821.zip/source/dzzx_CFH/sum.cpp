#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
#define ll long long
int n,k;
ll ans;
const int mod=1e9+9;
inline int read()
{
	int w=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*w;
}

ll calc(ll a,ll b)
{
	int ans=1%mod;
	for(;b;b>>=1)
	{
		if(b&1) ans=(ans*a)%mod;
		a=(a*a)%mod;
	}
	return ans;
}

ll euler(ll x)
{
	ll ret=x;
	int t=sqrt(x);
	for(int i=2;i<=t;i++)
	if(x%i==0)
	{
		ret=ret/i*(i-1);
		while(x%i==0)
		x/=i;
	}
	if(x>1) ret=ret/x*(x-1);
	return ret;
}

int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read();
	k=read();
	for(int i=1;i<=n;i++)
	{
		ll s=calc(i,k);
		ans=(ans+euler(s))%mod;
	}
	cout<<ans<<endl;
	return 0;
}
