#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int mod=1e9+9;
const int maxn=5e7+9;
int n,k;
ll ans;
int v[maxn],prime[maxn],phi[maxn];
void euler(int n){
	int tot=0;
	for(register int i=2;i<=n;++i){
		if(v[i]==0){
			v[i]=i,prime[++tot]=i;
			phi[i]=i-1;
		}
		for(register int j=1;j<=tot;++j){
			if(prime[j]>v[i] || prime[j]>n/i)break;
			v[i*prime[j]]=prime[j];
			phi[i*prime[j]]=phi[i]*(i%prime[j]? prime[j]-1:prime[j]);
		}
	}
}
ll qpow(ll a,ll b){
	ll ans=1,base=a;
	while(b){
		if(b&1)ans*=base;
		base*=base;
		b>>=1;
	}
	return ans;
}
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&k);
	phi[1]=1;
	euler(5e7);
	for(int i=1;i<=n;i++){
		(ans+=phi[qpow(i,k)])%=mod;
	}
	printf("%lld",ans);
}
