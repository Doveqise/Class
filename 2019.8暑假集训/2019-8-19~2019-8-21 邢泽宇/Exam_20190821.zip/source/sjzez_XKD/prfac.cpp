#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int maxn=50000009;
ll l,r,ans;
int num[maxn];
int prime[5000001],tot;
bool check[maxn];
void pre(int n){
	check[1]=1;
	for(register int i=2;i<=n;++i){
		if(!check[i])prime[++tot]=i;
		for(register int j=1;j<=tot;++j){
			if((ll)i*prime[j]>n) break;
			check[i*prime[j]]=1;
			if(i%prime[j]==0) break;
		}
	}
}
int main(){
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%lld%lld",&l,&r);
	pre(r);num[1]=1;
	for(register int i=2;i<=r;++i){
		if(!check[i])num[i]=1;
		for(register int j=1;j<=tot;++j){
			if((ll)i*prime[j]>r)break;
			num[i*prime[j]]=num[i]+1;
			if(i%prime[j]==0)break;
		}
	}
	for(register int i=l;i<=r;++i){
		if(!check[num[i]])ans++;
	}
	printf("%lld",ans);
}
