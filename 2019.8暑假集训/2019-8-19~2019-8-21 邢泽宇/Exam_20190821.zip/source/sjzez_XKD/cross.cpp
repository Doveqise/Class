#include<bits/stdc++.h>
using namespace std;
const int maxn=300009;
const int mod=73939133;
int n,m,k,ans;
struct node{
	int v,nxt;
}e[maxn<<1];
int head[maxn],cnt;
void add(int u,int v){
	e[++cnt].v=v;e[cnt].nxt=head[u];head[u]=cnt;
}
int u[maxn],v[maxn];
int dep[maxn],fa[maxn][20],lg[maxn];
void dfs(int x,int f){
	dep[x]=dep[f]+1;
	fa[x][0]=f;
	for(int i=1;(1<<i)<=dep[x];i++)
	fa[x][i]=fa[ fa[x][i-1] ][i-1];
	for(int i=head[x];i;i=e[i].nxt){
		if(e[i].v==f)continue;
		dfs(e[i].v,x);
	}
}
int lca(int x,int y){
	if(dep[x]<dep[y])swap(x,y);
	while(dep[x]>dep[y])
	x=fa[x][lg[dep[x]-dep[y]]-1];
	if(x==y)return x;
	for(int k=lg[dep[x]]-1;k>=0;k--)
	if(fa[x][k]!=fa[y][k])
	x=fa[x][k],y=fa[y][k];
	return fa[x][0];
}
bool pd(int x,int y){
	int l1=lca(u[x],v[x]),l2=lca(u[y],v[y]);
	if(dep[l1]<dep[l2])swap(l1,l2),swap(x,y);
	if(lca(l1,u[y])==l1||lca(l1,v[y])==l1)return 0;//�н� 
	return 1;
}
int C(int n,int m){
	int tmp=1;
	for(int i=1;i<=n;i++)tmp*=i;
	for(int i=1;i<=m;i++)tmp/=i;
	for(int i=1;i<=(n-m);i++)tmp/=i;
	return tmp%mod;
}
int main(){
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
	lg[i]=lg[i-1]+(1<<lg[i-1]==i);
	for(int i=1,u,v;i<n;i++){
		scanf("%d%d",&u,&v);
		add(u,v);add(v,u);
	}
	dfs(1,0);
	for(int i=1;i<=m;i++)scanf("%d%d",&u[i],&v[i]);
	if(k==2){
		for(int i=1;i<=m;i++)
		for(int j=i+1;j<=m;j++){
			if(pd(i,j))ans++;
		}
	}
	else if(k==3){
		for(int i=1;i<=m;i++)
		for(int j=i+1;j<=m;j++)
		if(pd(i,j))for(int l=j+1;l<=m;l++)
		if(pd(i,l)&&pd(j,l)){
			ans++;
		}
	}
	else if(k==4){
		for(int i=1;i<=m;i++)
		for(int j=i+1;j<=m;j++)
		if(pd(i,j))for(int l=j+1;l<=m;l++)
		if(pd(i,l)&&pd(j,l))for(int p=l+1;p<=m;p++)
		if(pd(i,p)&&pd(j,p)&&pd(l,p)){
			ans++;
		}
	}
	else if(k==5){
		for(int i=1;i<=m;i++)
		for(int j=i+1;j<=m;j++)
		if(pd(i,j))for(int l=j+1;l<=m;l++)
		if(pd(i,l)&&pd(j,l))for(int p=l+1;p<=m;p++)
		if(pd(i,p)&&pd(j,p)&&pd(l,p))for(int q=p+1;q<=m;q++)
		if(pd(i,q)&&pd(j,q)&&pd(l,q)&&pd(p,q)){
			ans++;
		}
	}
	ans%=mod;
	if(k==2)printf("%d",((m*(m-1)/2)%mod-ans+mod)%mod);
	else printf("%d",(C(m,k)-ans+mod)%mod);
}
