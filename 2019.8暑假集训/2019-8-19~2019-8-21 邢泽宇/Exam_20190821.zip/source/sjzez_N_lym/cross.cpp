#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	
	return 0;
}
