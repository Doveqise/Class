#include<bits/stdc++.h>
using namespace std;

#define int unsigned int

bool f[1000005];
int prim[1000005];
int tp=0;
int l,r;
int a[1000005];
int ps[1000005];

signed main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	for(int i = 2; i < 1000005; i++)
	{
		f[i] = 1;
	}
	for(int i = 2; i < 1000005; i++)
	{
		if(f[i])
		{
			prim[tp++] = i;
		}
		for(int j = 0; j < tp && prim[j]*i < 1000005; j++)
		{
			f[prim[j]*i] = 0;
			if(i%prim[j] == 0) break;
		}
	}
	cin >> l >> r;
	for(int i = 0; i <= r-l; i++)
	{
		a[i] = i+l;
	}
	for(int i = 0; i < 10005; i++)
	{
		for(int j = l/prim[i]; prim[i]*j <= r; j++)
		{
			if(prim[i]*j < l) continue;
			while(a[prim[i]*j-l]%prim[i] == 0)
			{
				a[prim[i]*j-l] /= prim[i];
				ps[prim[i]*j-l]++;
			}
		}
	}
	int ans=0;
//	for(int i = 0; i <= r-l; i++)
//	{
//		if(f[ps[i]])
//		{
//			cout << i << ' ';
//			ans++;
//		}
//	}
//	cout << endl;
	cout << ans << endl;
	return 0;
}
