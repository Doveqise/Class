#include<bits/stdc++.h>
using namespace std;

const int mod = 1e9+9;

bool f[10000005];
int prim[10000005];
int fi[10000005];
int tp;
int n,k;

int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	cin >> n >> k;
	for(int i = 2; i <= n; i++)
	{
		f[i] = 1;
	}
	fi[1] = 1;
	for(int i = 2; i <= n; i++)
	{
		if(f[i])
		{
			prim[tp++] = i;
			fi[i] = i-1;
		}
		for(int j = 0; j < tp && prim[j]*i <= n; j++)
		{
			f[prim[j]*i] = 0;
			fi[prim[j]*i] = fi[prim[j]]*fi[i];
			if(i%prim[j] == 0)
			{
				fi[prim[j]*i] += fi[i];
				break;
			}
		}
	}
	for(int i = 1; i <= n; i++) cout << fi[i] << ' ';
	cout << endl;
	long long ans=0;
	for(int i = 1; i <= n; i++)
	{
		ans += (long long)fi[i]*(long long)(pow(i,k-1)+0.000001);
		ans %= mod;
	}
	cout << ans << endl;
	return 0;
}
