#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<cmath>
#define ll long long
const int maxn=1000010;
using namespace std;
ll l,r,m,p[maxn],n,qqq,cnt;
int v[maxn],ans;
bool vis[maxn];
int main(){
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	cin>>l>>r;
	m=0;
	n=sqrt(r);
	for(int i=2;i<=sqrt(r);i++){
		if(v[i]==0){v[i]=i;p[++m]=i;}
		for(int j=1;j<=m;j++){
			if(p[j]>v[i]||p[j]>n/i) break;
			v[i*p[j]]=p[j];
		}
	}
	for(int i=l;i<=r;i++){
		qqq=i;cnt=0;
		if(!vis[qqq-l+1]){
		    vis[qqq-l+1]=1;
			for(int j=1;j<=m;j++)
			if(qqq%p[j]==0)while(qqq%p[j]==0)qqq/=p[j],cnt++;
			if(qqq>1) cnt++;
			if(v[cnt]==cnt&&cnt!=0) ans+=1;
			if(v[cnt+1]!=cnt+1){
				for(int k=1;k<=m;k++){
					if(i*p[k]<=r){
						if(!vis[i*p[k]-l+1])
						vis[i*p[k]-l+1]=1;
					}
					else break;
				}
			}
			 else if(v[cnt+1]==cnt+1)
				for(int k=1;k<=m;k++){
					if(i*p[k]<=r){
						if(!vis[i*p[k]-l+1])
						vis[i*p[k]-l+1]=1,ans+=1;
					}
					else break;
				}
			}
		}
	cout<<ans<<endl;
	return 0;
}
