#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
#define ll long long
using namespace std;
queue<int> q;
const int mod=73939133;
const int maxn=1000010;
ll ver[maxn*2],nxt[maxn*2],head[maxn],tot,ans,lca1,lca2,lca3,lca4;
bool v[maxn];
ll n,k,m,c[1010][1010],d[maxn],f[maxn][25],xx[maxn],yy[maxn];
inline void add(int x,int y){
	ver[++tot]=y;nxt[tot]=head[x];head[x]=tot;
}
inline void bfs(){
	q.push(1);d[1]=1;
	while(q.size()){
		int x=q.front();q.pop();
		for(int i=head[x];i;i=nxt[i]){
			int y=ver[i];
			if(d[y]) continue;	
			d[y]=d[x]+1;
			f[y][0]=x;
			for(int j=1;j<=20;j++)
			f[y][j]=f[f[y][j-1]][j-1];
			q.push(y);
		}
	}
}

inline int LCA(int x,int y){
	if(d[x]>d[y]) swap(x,y);
	for(int i=20;i>=0;i--){
		if(d[f[y][i]]>=d[x]) y=f[y][i];
	}
	if(x==y) return x;
	for(int i=20;i>=0;i--){
		if(f[x][i]!=f[y][i]) x=f[x][i],y=f[y][i];
	}
	return f[x][0];
}

int main(){
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<n;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	bfs();
	for(int i=1;i<=m;i++){
		scanf("%lld%lld",&xx[i],&yy[i]);
	}
    c[0][0]=1;
    for(int i=1;i<=m;i++) { c[i][0]=1;for(int j=1;j<=i;j++) c[i][j]=c[i-1][j-1]+c[i-1][j],c[i][j]%=mod; }
    
    for(int i=1;i<=m;i++){
    	for(int j=i+1;j<=m;j++){
    		if(d[xx[i]]>d[yy[i]])swap(xx[i],yy[i]);
    		if(d[xx[j]]>d[yy[j]])swap(xx[j],yy[j]);
    		lca1=LCA(xx[i],xx[j]);lca2=LCA(yy[i],yy[j]);lca3=LCA(xx[i],yy[i]),lca4=LCA(xx[j],yy[j]);
    		if(lca1==lca2&&lca3!=lca4){
    			if(xx[j]!=xx[i])
    			ans++;
			}
		}
	}
	if(k==2)
    cout<<c[m][k]-ans<<endl;
    else cout<<c[m][k]<<endl;
	return 0;
}
