#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#define ll long long
using namespace std;
const int maxn=1e6*3;
const int mod=1e9+9;
ll sum;
ll n,k,phi[maxn];
inline ll power(ll a,ll b){
	ll ans=1;
	for(;b;b>>=1){
		if(b&1) ans=ans*a%mod;
		a=a*a%mod;
	}
	return ans%mod;
}
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=maxn;i++) phi[i]=i;
	for(int i=2;i<=maxn;i++)if(phi[i]==i){
		for(int j=i;j<=maxn;j+=i) phi[j]=phi[j]/i*(i-1);
	}
	for(int i=1;i<=n;i++){
		sum+=phi[power(i,k)];
		sum%=mod;
	}
	cout<<sum<<endl;
	return 0;
}
