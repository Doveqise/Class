#include<bits/stdc++.h>
#define re register int
#define LL long long
#define mod 1000000009
#define maxn1 625000+5
#define maxn 10000000+5

using namespace std;
bool notpri[maxn];
int prime[maxn1];
int phi[maxn];
inline int read()
{
	int x=0;
	char ch=getchar();
	while(!isdigit(ch))
	ch=getchar();
	while(isdigit(ch))
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x;
}
inline void write(LL x)
{
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
int n,k;
int cnt;
LL ans;
inline LL qpow(int a,int b)
{
	LL res=1;
	while(b)
	{
		if(b&1) res=(res*a)%mod;
		a=(a*a)%mod;
		b>>=1;
	}
	return res;
}
void shai()
{
	ans=1;
	for(re i=2;i<=n;i++){
		if(!notpri[i]) 
	  prime[++cnt]=i,phi[i]=i-1;
			for(re j=1;j<=cnt;j++)
			{
				if(i*prime[j]>n) break;
				notpri[i*prime[j]]=true;
					if(i%prime[j]==0) {
					phi[i*prime[j]]=phi[i]*prime[j];
					break;
				}
			    phi[i*prime[j]]=phi[i]*phi[prime[j]];
			}
	}
}
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read();
	k=read();
	shai();
	for(re i=1;i<=n;i++)
	ans=(ans+qpow(i,k-1)*phi[i]%mod)%mod;
	write(ans);
	return 0;
}
