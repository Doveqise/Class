#include<bits/stdc++.h>
#define re register int
#define maxn 100000+5
#define maxn2 1000000+5
using namespace std;
bool notpri[maxn2];
int prime[maxn];
int c[maxn2],ans[maxn2];
inline int read()
{
	int x=0;
	char ch=getchar();
	while(!isdigit(ch))
	ch=getchar();
	while(isdigit(ch))
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x;
}
inline void write(int x)
{
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
int l,r;
int cnt;
void shai(int n)
{
	for(re i=2;i<=n;i++)
	{
		if(!notpri[i]) {
			prime[++cnt]=i;
			for(re j=1;j<=cnt;j++)
			{
				if(i*prime[j]>n) break;
				notpri[i*prime[j]]=true;
				c[i*prime[j]]=2;
				ans[i*prime[j]]++;
				if(i%prime[j]==0) break;
			}
		}
		else{
			for(re j=1;j<=cnt;j++)
			{
				if(i*prime[j]>n) break;
				notpri[i*prime[j]]=true;
				c[i*prime[j]]=c[i]+1;
				if(!notpri[c[i*prime[j]]]) ans[i*prime[j]]++;
				if(i%prime[j]==0) break;
			}
		}
	}
	for(re i=1;i<=n;i++)
	ans[i]=ans[i-1]+ans[i];
}
int main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	l=read();
	r=read();
	shai(r);
	int tmp=ans[r]-ans[l-1];
	write(tmp);
	return 0;
}
