#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1e6 + 9;
namespace force
{
int isans[MAXN];
int prime[MAXN], v[MAXN], m;
bool isprime[MAXN];
int ans;
void primes(int n)
{
    memset(v, 0, sizeof(v));
    m = 0;
    for (register int i = 2; i <= n; ++i)
    {
        if (v[i] == 0)
        {
            v[i] = i;
            prime[++m] = i;
            isans[prime[m]] = isprime[prime[m]] = 1;
        }
        for (register int j = 1; j <= m; ++j)
        {
            if (prime[j] > v[i] || prime[j] > n / i)
                break;
            v[i * prime[j]] = prime[j];
        }
    }
}
void find(int n)
{
    for (register int i = 2; i <= n; ++i)
    {
        for (register int j = 1; j <= m; ++j)
        {
            if(i * prime[j] > n)
                break;
            isans[i * prime[j]] = isans[i] + 1;
        }
    }
}
int _main()
{
    int l, r;
    cin >> l >> r;
    primes(r);
    find(r);
    for (register int i = l; i <= r; ++i)
    {
        ans += isprime[isans[i]];
        // cerr << ans <<endl;
    }
    cout << ans << endl;
    return 0;
}
} // namespace force

int main()
{
    freopen("prfac.in", "r", stdin);
    freopen("prfac.out", "w", stdout);
    force::_main();
}