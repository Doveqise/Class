#include <bits/stdc++.h>
using namespace std;
namespace fdata
{
inline char nextchar()
{
    static const int BS = 1 << 21;
    static char buf[BS], *st, *ed;
    if (st == ed)
        ed = buf + fread(st = buf, 1, BS, stdin);
    return st == ed ? -1 : *st++;
}
inline int poread()
{
    int ret = 0;
    char ch;
    while (!isdigit(ch = nextchar()))
        ;

    do
        ret = ret * 10 + ch - '0';
    while (isdigit(ch = nextchar()));
    return ret;
}
} // namespace fdata
const int MAXN = 300005;
int head[MAXN << 1], nxt[MAXN << 1], ver[MAXN << 1], tot;

int Lca[1005][1005];

int t;
int f[MAXN][20], d[MAXN];
queue<int> q;
void bfs()
{
    q.push(1);
    d[1] = 1;
    while (q.size())
    {
        int x = q.front();
        q.pop();
        for (register int i = head[x]; i; i = nxt[i])
        {
            int y = ver[i];
            if (d[y])
                continue;
            d[y] = d[x] + 1;
            f[y][0] = x;
            for (register int j = 1; j <= t; ++j)
                f[y][i] = f[f[y][j - 1]][j - 1];
            q.push(y);
        }
    }
}
int lca(int x, int y)
{
    if (d[y] < d[x])
        swap(x, y);
    for (register int i = t; i >= 0; --i)
    {
        if (d[f[y][i]] >= d[x])
            y = f[y][i];
    }
    if (x == y)
        return x;
    for (register int i = t; i >= 0; --i)
    {
        if (f[x][i] != f[y][i])
            x = f[x][i], y = f[y][i];
    }
    return f[x][0];
}
inline void add(int x, int y)
{
    ver[++tot] = y;
    nxt[tot] = head[x];
    head[x] = tot;
}
int n, m, k;
struct Road
{
    int x, y;
} road[MAXN];

namespace force1
{
int ans = 0;
bool v[10];
void dfs(int now)
{
    if (now == k)
    {
        for (register int i = 1; i <= m; ++i)
        {
            if (!v[i])
                continue;
            for (register int j = i + 1; j <= m; ++j)
            {
                if (!v[j])
                    continue;
                int I = i, J = j;
                int lca1 = Lca[road[i].x][road[i].y], lca2 = Lca[road[j].x][road[j].y];
                if (d[lca1] < d[lca2])
                    swap(lca1, lca2), swap(I, J);
                if (Lca[lca1][road[J].x] == lca1 || Lca[lca1][road[J].y] == lca1)
                    ++ans;
            }
        }
        return;
    }
    if (now > k)
        return;
    for (register int i = 1; i <= m; ++i)
    {
        if (!v[i])
        {
            v[i] = 1;
            dfs(now + 1);
            v[i] = 0;
        }
    }
}
int _main()
{
    for (register int i = 1; i <= n; ++i)
    {
        for (register int j = i; j <= n; ++j)
        {
            Lca[i][j] = Lca[j][i] = lca(i, j);
        }
    }
    dfs(0);
    cout << ans << endl;
}
} // namespace force1
namespace force2
{
int _main()
{
    for (register int i = 1; i <= n; ++i)
    {
        for (register int j = i; j <= n; ++j)
        {
            Lca[i][j] = Lca[j][i] = lca(i, j);
        }
    }
    int ans = 0;
    for (register int i = 1; i <= m; ++i)
    {
        for (register int j = i + 1; j <= m; ++j)
        {
            int I = i, J = j;
            int lca1 = Lca[road[i].x][road[i].y], lca2 = Lca[road[j].x][road[j].y];
            if (d[lca1] < d[lca2])
                swap(lca1, lca2), swap(I, J);
            if (Lca[lca1][road[J].x] == lca1 || Lca[lca1][road[J].y] == lca1)
                ++ans;
        }
    }
    cout << ans << endl;
    return 0;
}
} // namespace force2
int main()
{
    freopen("cross.in", "r", stdin);
    freopen("cross.out", "w", stdout);
    n = fdata::poread();
    m = fdata::poread();
    k = fdata::poread();
    for (register int i = 1; i < n; ++i)
    {
        int x = fdata::poread(), y = fdata::poread();
        add(x, y);
        add(y, x);
    }
    t = int(log(n) / log(2)) + 1;
    bfs();
    for (register int i = 1; i <= m; ++i)
    {
        road[i].x = fdata::poread();
        road[i].y = fdata::poread();
    }
    if (n <= 100 && k <= 5)
    {
        force1::_main();
    }
    if (k == 2)
    {
        force2::_main();
        return 0;
    }
}