// #pragma GCC target("avx2")
// #pragma GCC optimez("ofast")
#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1e7 + 7;
const int MOD = 1e9 + 9;
namespace force
{
int n, k;
int v[MAXN], prime[MAXN], m;
inline void primes(int n)
{
    for (register int i = 2; i <= n; ++i)
    {
        if (v[i] == 0)
        {
            v[i] = i;
            prime[++m] = i;
        }
        for (register int j = 1; j <= m; ++j)
        {
            if (prime[j] > v[i] || prime[j] > n / i)
                break;
            v[i * prime[j]] = prime[i];
        }
    }
}
inline int power(int a, int b)
{
    int ans = 1 % MOD;
    for (; b; b >>= 1)
    {
        if (b & 1)
            ans = (long long)ans * a % MOD;
        a = (long long)a * a % MOD;
    }
    return ans;
}
inline int phi(int n)
{
    int ans = n;
    for (register int i = 1; i <= m && prime[i] <= n; ++i)
    {
        if (n % prime[i] == 0)
        {
            ans = ans / prime[i] * (prime[i] - 1);
            while (n % prime[i] == 0)
                n /= prime[i];
        }
    }
    if (n > 1)
        ans = ans / n * (n - 1);
    return ans;
}
int _main()
{
    cin >> n >> k;
    primes(sqrt(n));
    int ans = 0;
    for (register int i = 1; i <= n; ++i)
    {
        ans = (ans + ((long long)power(i, k - 1) * phi(i) % MOD)) % MOD;
    }
    cout << ans << endl;
    return 0;
}
} // namespace force
int main()
{
    freopen("sum.in", "r", stdin);
    freopen("sum.out", "w", stdout);
    force::_main();
    return 0;
}