#include <fstream>
using namespace std;
ifstream cin("sum.in");
ofstream cout("sum.out");
const int kmaxn=10000000+5;
bool check[kmaxn];
int prime[kmaxn];
int phi[kmaxn];
int num;
int n,m;
typedef long long ll;
const int MOD=1e9+9;
ll mpow(ll b,ll p)
{
	ll ans=1;
	while(p)
	{
		if(p&1){
			ans*=b;
			ans%=MOD;
		}
		b*=b;
		b%=MOD;
		p>>=1;
	}
	return ans;
}  
int main()
{
    ios::sync_with_stdio(false);
    cin>>n>>m;
    for(int i=2;i<=n;++i)
    {
        if(!check[i])
        {
            prime[num++]=i;
            phi[i]=(i-1)%MOD;
        }
        for(int f=0;f<num&&i*prime[f]<=n;++f)
        {
            check[i*prime[f]]=true;
            if(!(i%prime[f])){
            	phi[i*prime[f]]=phi[prime[f]]*i%MOD;
            }
            else
            	phi[i*prime[f]]=phi[i]*phi[prime[f]]%MOD;
        }
    }
    check[0]=check[1]=true;
    ll ans=0;
    phi[1]=1;
    for(int i=1;i<=n;++i)
    {
    	ans+=phi[i]*mpow(i,m-1)%MOD;
    	ans%=MOD;
    }
    cout<<ans<<endl;
    return 0;
}

