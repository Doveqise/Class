#include <fstream>
#include <cmath>
using namespace std;
ifstream cin("prfac.in");
ofstream cout("prfac.out"); 
const int kmaxn=1000000+5;
int check[kmaxn];
int prime[kmaxn];
int num;
int l,r;
int n;
int ans;
inline int cal(int i)
{
	int j=0,res=0;
	while(j<num&&prime[j]<=i&&i>n)
	{
		if(0==i%prime[j])
		{
			i/=prime[j];
			++res;
			--j;
		}
		++j;
	}
	while(i>1&&i<=n&&check[i])
	{
		i/=check[i];
		++res;
	}
	return res+(i!=1);
}
int main()
{
    ios::sync_with_stdio(false);
    cin>>l>>r;
    n=sqrt(r)+5;
    for(int i=2;i<=n;++i)
    {
        if(!check[i])
        {
            prime[num++]=i;
        }
        for(int f=0;f<num&&i*prime[f]<=n;++f)
        {
            check[i*prime[f]]=prime[f];
            if(!(i%prime[f]))break;
        }
    }
    check[0]=check[1]=true;
	for(int i=l;i<=r;++i)
   	{
		ans+=!check[cal(i)];
	}
	cout<<ans<<endl;
    return 0;
}
/*
999000001 1000000000
*/

