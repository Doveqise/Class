#include <fstream>
#include <vector>
using namespace std;
ifstream cin("cross.in");
ofstream cout("cross.out");
const int kmaxn=300000+5;
const int kmaxlg=30;
const int MOD=73939133; 
struct edge{
	int d;
	edge* nxt;
};
edge mpool[kmaxn<<1];
edge* H[kmaxn];
int mpt;
void add_edge(int s,int d)
{
	mpool[mpt].nxt=H[s];
	H[s]=&mpool[mpt++];
	H[s]->d=d;
}
int fa[kmaxn][kmaxlg];
int lg[kmaxn];
int dep[kmaxn];
int A[kmaxn];
int B[kmaxn];
int n,m,k;
void dfs(int now,int f)
{
	fa[now][0]=f;
	dep[now]=dep[f]+1;
	for(int i=1;i<lg[dep[now]];++i)
	{
		fa[now][i]=fa[fa[now][i-1]][i-1];
	}
	edge *t=H[now];
	while(t)
	{
		if(t->d!=f)dfs(t->d,now);
		t=t->nxt;
	}
}
inline int lca(int x,int y)
{
	if(dep[x]<dep[y])swap(x,y);
	while(dep[x]>dep[y])
	{
//		cout<<"x	"<<x<<"	"<<lg[dep[x]-dep[y]]-1<<endl;
		x=fa[x][lg[dep[x]-dep[y]]-1];
	}
	if(x==y)return x;
	for(int i=lg[dep[x]]-1;i>=0;--i)
	{
		if(fa[x][i]!=fa[y][i])
		{
			x=fa[x][i];
			y=fa[y][i];
		}
	}
	return fa[x][0];
}
inline int dis(int x,int y)
{
	return dep[x]+dep[y]-2*dep[lca(x,y)];
}
int a,b;
vector<int> vec;
int cnt[kmaxn];
inline void check()
{
	int t,p=0;
	for(int i=0;i<k;++i)
	{
		t=lca(A[vec[i]],B[vec[i]]);
		p=A[vec[i]];
		while(p!=t){
			cnt[p]++;
			p=fa[p][0];
		}
		p=B[vec[i]];
		while(p!=t){
			cnt[p]++;
			p=fa[p][0];
		}
		cnt[t]++;
	}
	for(int i=1;i<=n;++i)
	{
		if(cnt[i]==k)p=-1;
		cnt[i]=0;
	}
	if(p==-1)
	{
		++b;
		b%=MOD;
	}
}
inline void run(int now,int dp)
{
	if(dp==k)
	{
		check();
		return;
	}
	if(now>m)return;
	for(int i=now;i<=m;++i)
	{
		vec.push_back(i);
		run(i+1,dp+1);
		vec.pop_back();
	}
}
inline void solve()
{
	b=0;
	run(1,0);
	cout<<b<<endl;
}
int main()
{
	ios::sync_with_stdio(false);
	cin>>n>>m>>k;
	for(int i=1;i<=n;++i)
	{
		lg[i]=lg[i-1]+(i==(1<<lg[i-1]));
	}
	for(int i=1;i<n;++i)
	{
		cin>>a>>b;
		add_edge(a,b);
		add_edge(b,a);
	}
	dfs(1,0);
	for(int i=1;i<=m;++i)
	{
		cin>>A[i]>>B[i];
	}
	if(k!=2)
	{
		solve();
		return 0;
	}
	int D,ans=0;
	for(int i=1;i<=m;++i)
	{
		for(int j=1;j<i;++j)
		{
			D=dis(A[i],B[i])+dis(A[j],B[j]);
			if(dis(A[i],A[j])+dis(B[i],B[j])==D||dis(A[i],B[j])+dis(B[i],A[j])==D)
			{
				++ans;
				ans%=MOD;
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}
/*

3 6 3
1 2
1 3
1 1
2 2
3 3
1 2
1 3
2 3

*/
