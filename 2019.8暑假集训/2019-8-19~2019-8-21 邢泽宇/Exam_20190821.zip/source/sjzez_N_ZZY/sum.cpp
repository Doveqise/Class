#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int mod=1e9+9;
int n,k;
int prime[10000010],v[10000010];
long long f[10000010];
int tot=0;
long long power(long long x){
	long long ans=1;
	int now=k;
	while(now){
		if(now&1){
			ans=(ans*x)%mod;
		}
		x=(x*x)%mod;
		now>>=1;
	}
	return ans;
}
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&k);
	f[1]=1;
	for(int i=2;i<=n;i++){
		if(!v[i]){
			v[i]=i;
			prime[++tot]=i;
			f[i]=power(i)/i*(i-1);
		}
		for(int j=1;j<=tot;j++){
			if(v[i]<prime[j]||i*prime[j]>n)break;
			v[i*prime[j]]=prime[j];
			f[i*prime[j]]=i%prime[j]?((f[i]*f[prime[j]])%mod):((f[i]*power(prime[j]))%mod);
		}
	}
//	cout<<1<<endl;
	long long ans=0;
	for(int i=1;i<=n;i++){
	//	cout<<power(i)<<endl;
		ans=(ans+f[i])%mod;
	}
	printf("%lld\n",ans);
	return 0;
}
