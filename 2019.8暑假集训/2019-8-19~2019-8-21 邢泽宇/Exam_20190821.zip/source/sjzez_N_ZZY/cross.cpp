#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int mod=73939133;
int n,m,k;
int num=1;
long long ans=0;
struct node{
	int to;
	int next;
}road[600010];
struct node2{
	int u;
	int v;
}cross[300010];
int head[300010];
int pre[300010][20],deep[300010];
int vis[20];
int pass[300010],pass2[300010];
int F[300010];
long long mul[300010],inv[300010],minv[300010];
void built(int from,int to){
	road[++num].next=head[from];
	road[num].to=to;
	head[from]=num;
}
long long C(int x,int y){
	if(x<y)return 0;
	if(y==0)return 1;
	return (mul[x]*minv[y])%mod*minv[x-y]%mod;
}
void dfs(int x,int fa){
	pre[x][0]=fa;
	deep[x]=deep[fa]+1;
	for(int i=1;i<=19;i++){
		pre[x][i]=pre[pre[x][i-1]][i-1];
	}
	for(int i=head[x];i;i=road[i].next){
		int y=road[i].to;
		if(y==fa)continue;
		dfs(y,x);
	}
}
int lca(int x,int y){
	if(deep[x]<deep[y])swap(x,y);
	int k=deep[x]-deep[y];
	for(int i=0;i<=19;i++){
		if((k>>i)&1)x=pre[x][i];
	}
	if(x==y)return x;
	for(int i=19;i>=0;i--){
		if(pre[x][i]!=pre[y][i]){
			x=pre[x][i];
			y=pre[y][i];
		}
	}
	return pre[x][0];
}
void dfs2(int x,int fa){
	for(int i=head[x];i;i=road[i].next){
		int y=road[i].to;
		if(y==fa)continue;
		dfs2(y,x);
		pass[x]+=pass[y];
		pass2[x]+=pass2[y];
	}
}
void solve(int now,int tot){
	if(now>m){
		if(tot<k)return;
		for(int i=1;i<=m;i++){
			if(vis[i]){
				pass[cross[i].u]++;
				pass[cross[i].v]++;
				int f=lca(cross[i].u,cross[i].v);
				pass[f]--;
				pass[pre[f][0]]--;
			}
		}
		bool flag=0;
		dfs2(1,0);
		for(int i=1;i<=n;i++){
			if(pass[i]==k)flag=1;
			pass[i]=0;
		}
	/*	for(int i=1;i<=m;i++){
			cout<<vis[i]<<" ";
		}
		cout<<endl;
		cout<<flag<<endl;*/
		if(flag)ans++;
		return;
	}
	if(tot<k){
		vis[now]=1;
		solve(now+1,tot+1);
		vis[now]=0;
	}
	solve(now+1,tot);
}
void dp(int x){
	int num=pass[x]-pass2[x];
	for(int i=head[x];i;i=road[i].next){
		int y=road[i].to;
		if(y==pre[x][0])continue;
		dp(y);
	//	F[x]+=F[y];
	}
	F[x]+=num;
//	cout<<x<<" "<<F[x]<<endl;
	ans=(ans+C(F[x],k))%mod;
}
int main(){
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	memset(head,0,sizeof(head));
	mul[1]=1;
	inv[1]=1;
	minv[1]=1;
	for(int i=2;i<=300000;i++){
		mul[i]=(mul[i-1]*i)%mod;
		inv[i]=(mod-mod/i)*inv[mod%i]%mod;
		minv[i]=(minv[i-1]*inv[i])%mod;
	}
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		built(u,v);
		built(v,u);
	}
	for(int i=1;i<=m;i++){
		scanf("%d%d",&cross[i].u,&cross[i].v);
	}
	if(n<=100){
		dfs(1,0);
		solve(1,0);
		printf("%lld\n",ans);
	}
	else{
		dfs(1,0);
		for(int i=1;i<=m;i++){
			int u=cross[i].u;
			int v=cross[i].v;
			int f=lca(u,v);
			pass[u]++;
			pass[v]++;
			pass[f]--;
			pass[pre[f][0]]--;
			pass2[u]++;
			pass2[v]++;
			pass2[f]-=2;
		}
		dfs2(1,0);
		pass[0]=0;
		pass2[0]=0;
		pass2[1]=0;
		dp(1);
		printf("%lld\n",ans);
	}
	return 0;
}
