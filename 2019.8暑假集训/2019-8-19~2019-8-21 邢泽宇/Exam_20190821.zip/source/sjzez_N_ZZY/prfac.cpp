#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int l,r;
int prime[1000010],v[1000010],tot=0;
int a[1000010],vis[1000010];
int main(){
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	memset(vis,0,sizeof(vis));
	for(int i=2;i<=1000000;i++){
		if(!v[i]){
			v[i]=i;
			prime[++tot]=i;
		}
		for(int j=1;j<=tot;j++){
			if(v[i]<prime[j]||i*prime[j]>1000000)break;
			v[i*prime[j]]=prime[j];
		}
	}
	scanf("%d%d",&l,&r);
	for(int i=l;i<=r;i++){
		a[i-l+1]=i;
	}
	for(int i=1;i<=tot;i++){
		int now=prime[i];
		if(now>r)break;
		int k=l/now;
		if(k*now<l)k++;
		for(int j=k;;j++){
			if(1ll*j*now>r)break;
			int num=j*now;
		//	cout<<num<<" "<<now<<endl;
			while(num%now==0){
				vis[j*now-l+1]++;
				num/=now;
				a[j*now-l+1]/=now;
			}
		}
	}
/*	for(int i=1;i<=r-l+1;i++){
		cout<<vis[i]<<" ";
	}
	cout<<endl;*/
	for(int i=l;i<=r;i++){
		if(a[i-l+1]>1)vis[i-l+1]++;
	}
	int ans=0;
	for(int i=1;i<=r-l+1;i++){
		if(!vis[i])continue;
		if(v[vis[i]]==vis[i])ans++;
	}
	printf("%d\n",ans);
	return 0;
}
