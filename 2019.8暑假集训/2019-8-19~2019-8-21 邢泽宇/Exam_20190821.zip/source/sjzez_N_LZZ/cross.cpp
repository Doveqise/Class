#include<bits/stdc++.h>
using namespace std;
const int maxn = 2e3+5;
int hd[maxn],nxt[maxn],to[maxn],cnt,n,m,k;
int fa[maxn],dep[maxn],road[maxn][2],vis[maxn],jl[maxn];
void adde(int u,int v)
{
	nxt[++cnt]=hd[u];
	hd[u]=cnt;
	to[cnt]=v;
}
void dfs(int u)
{
	vis[u]=1;
	for(int i=hd[u];i;i=nxt[i])
	{
		int v=to[i];
		if(vis[v])
			continue;
		dep[v]=dep[u]+1;
		vis[v]=1;
		fa[v]=u;
	}
	return;
}
void init()
{
	int rt=1;
	fa[1]=dep[1]=1;
	dfs(1);
	return;
}
int lca(int x,int y)
{
	if(dep[x]>dep[y])
		swap(x,y);
	if(dep[x]==dep[y])
		if(x==y)
			return x;
		else
			return lca(fa[x],fa[y]);
	return lca(x,fa[y]);
}
signed main()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<n;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		adde(u,v);
		adde(v,u);
	}
	init();
	for(int i=1;i<=m;i++)
		scanf("%d%d",&road[i][0],&road[i][1]);
	if(k==1)
	{
		puts("0");
		return 0; 
	}
	if(k==2)
	{
		int ans=0;
		for(int i1=1;i1<=m;i1++)
			for(int i2=i1+1;i2<=m;i2++)
			{
				int u1=road[i1][0],u2=road[i2][0],v1=road[i1][1],v2=road[i2][1];
				int la1=lca(u1,v1),la2=lca(u2,v2),flg=0;
				memset(jl,0,sizeof(jl));
				jl[la1]=jl[la2]=1;
				if(la1==la2)
				{
					ans++;
					continue;
				}
				for(int i=u1;i!=la1;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v1;i!=la1;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=u2;i!=la2;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v2;i!=la2;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
			}
		printf("%d\n",ans);
	}
	if(k==3)
	{
		int ans=0;
		for(int i1=1;i1<=m;i1++)
			for(int i2=i1+1;i2<=m;i2++)
				for(int i3=i2+1;i3<=m;i3++)
					{
				int u1=road[i1][0],v1=road[i1][1],u2=road[i2][0],v2=road[i2][1],u3=road[i3][0],v3=road[i3][1];
				int la1=lca(u1,v1),la2=lca(u2,v2),la3=lca(u3,v3),flg=0;
				memset(jl,0,sizeof(jl));
				jl[la1]=jl[la2]=jl[la3]=1;
				if(la1==la2||la1==la3||la2==la3)
				{
					ans++;
					continue;
				}
				for(int i=u1;i!=la1;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v1;i!=la1;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=u2;i!=la2;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v2;i!=la2;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=u3;i!=la3;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v3;i!=la3;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
			}
		printf("%d\n",ans);
	}
	if(k==4)
	{
		int ans=0;
		for(int i1=1;i1<=m;i1++)
			for(int i2=i1+1;i2<=m;i2++)
				for(int i3=i2+1;i3<=m;i3++)
					for(int i4=i3+1;i4<=m;i4++)
					{
				int u1=road[i1][0],v1=road[i1][1],u2=road[i2][0],v2=road[i2][1],u3=road[i3][0],v3=road[i3][1],u4=road[i4][0],v4=road[i4][1];
				int la1=lca(u1,v1),la2=lca(u2,v2),la3=lca(u3,v3),la4=lca(u4,v4),flg=0;
				memset(jl,0,sizeof(jl));
				jl[la1]=jl[la2]=jl[la3]=jl[la4]=1;
				if(la1==la2||la1==la3||la2==la3||la1==la4||la2==la4||la3==la4)
				{
					ans++;
					continue;
				}
				for(int i=u1;i!=la1;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v1;i!=la1;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=u2;i!=la2;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v2;i!=la2;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=u3;i!=la3;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v3;i!=la3;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=u4;i!=la4;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v4;i!=la4;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
			}
		printf("%d\n",ans);
	}
	if(k==4)
	{
		int ans=0;
		for(int i1=1;i1<=m;i1++)
			for(int i2=i1+1;i2<=m;i2++)
				for(int i3=i2+1;i3<=m;i3++)
					for(int i4=i3+1;i4<=m;i4++)
						for(int i5=i4+1;i5<=m;i5++)
						{
				int u1=road[i1][0],v1=road[i1][1],u2=road[i2][0],v2=road[i2][1],u3=road[i3][0],v3=road[i3][1],u4=road[i4][0],v4=road[i4][1],u5=road[i5][0],v5=road[i5][1];
				int la1=lca(u1,v1),la2=lca(u2,v2),la3=lca(u3,v3),la4=lca(u4,v4),la5=lca(u5,v5),flg=0;
				memset(jl,0,sizeof(jl));
				jl[la1]=jl[la2]=jl[la3]=jl[la4]=jl[la5]=1;
				if(la1==la2||la1==la3||la2==la3||la1==la4||la2==la4||la3==la4||la1==la5||la2==la5||la3==la5||la4==la5)
				{
					ans++;
					continue;
				}
				for(int i=u1;i!=la1;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v1;i!=la1;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=u2;i!=la2;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v2;i!=la2;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=u3;i!=la3;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v3;i!=la3;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=u4;i!=la4;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v4;i!=la4;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=u5;i!=la5;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
				for(int i=v5;i!=la5;i=fa[i])
				{
					if(jl[i])
					{
						flg=1;
						ans++;
						break;
					}
					jl[i]=1;
				}
				if(flg)
					continue;
			}
		printf("%d\n",ans);
	}
}
