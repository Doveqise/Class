#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn = 1e7+5;
const int mod = 1e9+9;
int pri[maxn],phi[maxn];
ll qpow(ll a,ll b)
{
	int ret=1,base=a;
	while(b)
	{
		if(b&1)
			ret=(ret*base)%mod;
		base=(base*base)%mod;
		b>>=1;
	}
	return ret;
}
void init()
{
	pri[1]=-1;
	for(ll i=2;i<=maxn;i++)
		if(!pri[i])
		{
			pri[i]=1;phi[i]=i-1;
			for(ll j=i*i;j<=maxn;j+=i)
				pri[j]=-1;		
		}
	phi[1]=0;
	for(ll i=2;i<=maxn;i++)
		for(ll j=i*i;j<=maxn;j+=i)
			phi[j]=phi[i]*phi[j/i];
}
signed main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	int n,k,ans=0;
	scanf("%d%d",&n,&k);
	init();
//	for(int i=1;i<=n;i++)
//		printf("pri[%d]=%d phi[%d]=%d\n",i,pri[i],i,phi[i]);
	for(int i=1;i<=n;i++)
		ans=(ans+qpow(phi[i],k))%mod;
	printf("%d\n",ans);
	return 0;
}
