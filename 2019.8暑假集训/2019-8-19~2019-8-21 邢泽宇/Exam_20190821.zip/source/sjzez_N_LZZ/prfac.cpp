#include<bits/stdc++.h>
using namespace std;
const int maxn = 1e6+5;
int ans[maxn],ini[maxn],pri[maxn],prim[maxn];
int cnt=0,l,r;
void init()
{
	pri[1]=-1;
	for(int i=2;i<=maxn;i++)
		if(!pri[i])
		{
			pri[i]=1;
			prim[++cnt]=i;
			for(int j=2*i;j<=maxn;j+=i)
				pri[j]=-1;		
		}
}
bool judge(int x)
{
	if(x==1)
		return 0;
	int lim=sqrt(x+0.5);
	for(int i=2;i<=lim;i++)
		if(!(x%i))
			return 0;
	return 1;
}
signed main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%d%d",&l,&r);
	init();
	int ans=0;
	for(int i=l;i<=r;i++)
	{
		int x=i,lim=ceil(pow(i,0.33)),num=0;
		for(int j=1;prim[j]<=lim;j++)
		{
			while(!(x%prim[j]))
			{
				x/=prim[j];
				num++;
			}
		}
		if(x<=1000000)
		{
			if(pri[x]==1)
				num++;
		}
		else
		{
			if(judge(x))
				num++;
		}
		if(pri[num]==1)
		{
			ans++;
		}
//		printf("num[%d]=%d\n",i,num);
	}
//	puts("");
	printf("%d\n",ans);
	return 0;
}
