#include<bits/stdc++.h>
using namespace std;
#define R register
#define int long long 
const int MOD=1000000000+9;
const int maxn=1000000050;
int mi[maxn],E[maxn];
int n,k,ans=0;
inline int quickpow(R int x,R int n)
{
	int res=1;
	int base=x;
	while(n)
	{
		if(n&1)
		{
			res*=base%MOD;
		}
		base*=base%MOD;
		n=n>>1;
	}return res%MOD;
}
inline int Euler(R int m)
{
	int re=m;
	for(R int i=2;i*i<=m;i++)
	 if(m%i==0)
	 {
	 	re=re-re/i;
	 	while(m%i==0)
	 	{
	 		m=m/i;
		 }
	 }
	 if(m>1)
	 re=re-re/m;
	 return re;
}
signed main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	for(R int i=1;i<=n;i++)
	
		mi[i]=quickpow(i,k);//�������ڴη������� 
	for(R int i=1;i<=n;i++)
	{
		E[i]=Euler(mi[i]);
		ans+=E[i];
	}
    printf("%lld",ans%MOD);
    fclose(stdin);
    fclose(stdout);
    return 0;
}
