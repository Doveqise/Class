#include<bits/stdc++.h>

using namespace std;

#define int long long

const int maxn=1e7+5,mod=1e9+9;

inline int read(){
	int x=0,f=1;
	char p=getchar();
	while(!isdigit(p)){
		if(p=='-') f=-1;
		p=getchar();
	}
	while(isdigit(p)) x=(x<<3)+(x<<1)+p-48,p=getchar();
	return x*f;
}

int phi[maxn],ans,prime[maxn],tot,v[maxn],n,k,inv[maxn];

inline void shaifa(int n){
	for(int i=2;i<=n;i++){
		if(!v[i]){
			v[i]=i;
			phi[i]=i-1;
			prime[++tot]=i;
		}
		for(int j=1;j<=tot&&prime[j]*i<=n;j++){
			v[i*prime[j]]=prime[j];
			if(i%prime[j]==0){
				phi[i*prime[j]]=phi[i]*prime[j];
				break;
			}
			else phi[i*prime[j]]=phi[i]*(prime[j]-1);
		}
	}
}

inline int power(int a,int b){
	int ans=1;
	while(b){
		if(b&1) ans=ans*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ans;
}

inline int solve(int x,int base){
	int ans=base;
	while(x!=1){
		ans=ans*inv[v[x]]%mod*(v[x]-1)%mod;
		int last=x;
		while(x%v[last]==0){
			x/=v[last];
		}
	}
	return ans;
}

signed main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	shaifa(1e7);
	n=read();k=read();
	inv[1]=1;inv[0]=1;
	for(int i=2;i<=n;i++) inv[i]=(mod-inv[mod%i]*(mod/i)%mod);
	for(int i=2;i<=n;i++){
		int x=power(i,k);
		ans=(ans+solve(i,x))%mod;
	}
	ans=(ans+1)%mod;
	cout<<ans<<endl;
	return 0;
}
