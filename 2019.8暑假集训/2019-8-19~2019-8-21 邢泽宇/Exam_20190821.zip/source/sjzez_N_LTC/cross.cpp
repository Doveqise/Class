#include<bits/stdc++.h>

using namespace std;

#define mid ((l+r)>>1)
#define lson k<<1,l,mid
#define rson k<<1|1,mid+1,r

#define re register

inline int read(){
	int x=0,f=1;
	char p=getchar();
	while(!isdigit(p)){
		if(p=='-') f=-1;
		p=getchar();
	}
	while(isdigit(p)) x=(x<<3)+(x<<1)+p-48,p=getchar();
	return x*f;
}

const int maxn=300005;

int n,m,k,head[maxn],ver[maxn],nxt[maxn],cnt;
int tree[maxn<<2],laz[maxn<<2],dep[maxn],top[maxn],f[maxn];
int qx[maxn],qy[maxn],node_cnt,son[maxn],siz[maxn],id[maxn];
int q[maxn],ans,v[maxn];

inline void pushup(int k){
	tree[k]=(tree[k<<1]|tree[k<<1|1]);
}

inline void down(int k){
	if(laz[k]){
		laz[k<<1]=1;
		laz[k<<1|1]=1;
		tree[k<<1]=1;
		tree[k<<1|1]=1;
		laz[k]=0; 
	}
}

inline void update(int k,int l,int r,int L,int R){
	if(L<=l&&r<=R){
		tree[k]=1;
		laz[k]=1;
		return;
	}
	down(k);
	if(L<=mid) update(lson,L,R);
	if(R>mid) update(rson,L,R);
	pushup(k); 
}

inline bool ask(int k,int l,int r,int L,int R){
	if(L<=l&&r<=R) return tree[k];
	down(k);
	if(L>mid) return ask(rson,L,R);
	else if(R<=mid) return ask(lson,L,R);
	else return ask(lson,L,mid)|ask(rson,mid+1,R);
}

inline void add(int x,int y){
	nxt[++cnt]=head[x];
	head[x]=cnt;
	ver[cnt]=y;
}

inline void dfs1(int x,int fa){
	f[x]=fa;siz[x]=1;
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==fa) continue;
		dep[y]=dep[x]+1;
		dfs1(y,x);
		siz[x]+=siz[y];
		if(siz[y]>siz[son[x]]) son[x]=y;
	}
}

inline void dfs2(int x,int tp){
	top[x]=tp;id[x]=++node_cnt;
	if(son[x]) dfs2(son[x],tp);
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==f[x]||y==son[x]) continue;
		dfs2(y,y);
	}
}

inline bool find_(int x,int y){
	if(x==y) return v[y];
	while(f[x]!=y){
		if(v[x]) return 1;
		x=f[x];
	}
	return v[y]|v[x];
}

inline bool find(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		if(find_(x,top[x])) return 1;
		x=f[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	if(find_(x,y)) return 1;
	return 0;
}

inline void paint_(int x,int y){
	if(x==y){
		v[x]=1;
		return;
	}
	while(f[x]!=y){
		v[x]=1;
		x=f[x];
	}
	v[y]=1;
}

inline void paint(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		paint_(x,top[x]);
		x=f[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	paint_(x,y);
}

inline bool check(){
	for(int i=1;i<=k;i++){
		if(find(qx[q[i]],qy[q[i]])) return 1;
		paint(qx[q[i]],qy[q[i]]);
	}
	return 0;
}

inline void dfs(int dep,int cnt){
	if(cnt==k){
		memset(v,0,sizeof(v));
		if(check()) ans++;
		return;
	}
	if(dep+1>m) return; 
	q[cnt+1]=dep+1;
	dfs(dep+1,cnt+1);
	dfs(dep+1,cnt);
}

inline void UPD(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		update(1,1,n,id[top[x]],id[x]);
		x=f[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	update(1,1,n,id[y],id[x]);
}

inline bool ASK(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		if(ask(1,1,n,id[top[x]],id[x])) return 1;
		x=f[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	if(ask(1,1,n,id[y],id[x])) return 1;
	return 0;	
}

int main(){
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	n=read();m=read();k=read();
	for(re int i=1;i<n;i++){
		int x=read(),y=read();
		add(x,y);add(y,x);
	}
	for(re int i=1;i<=m;i++)
		qx[i]=read(),qy[i]=read();
	dep[1]=1;
	dfs1(1,0);
	dfs2(1,1);
	if(n<=100&&m<=5&&k<=5){
		dfs(0,0);
		cout<<ans<<endl;
		return 0;
	}
	if(m<=1000&&k==2){
		for(re int i=1;i<m;i++){
			memset(tree,0,sizeof(tree));
			memset(laz,0,sizeof(laz));
			UPD(qx[i],qy[i]);
			for(re int j=i+1;j<=m;j++){
				if(ASK(qx[j],qy[j])) ans++;
			}
		}
		cout<<ans<<endl;
		return 0;
	}
	return 0;
}
