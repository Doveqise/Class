#include<bits/stdc++.h>

using namespace std;

const int maxn=1e6+5; 

int prime[maxn],ans,v[maxn],tot,l,r;

inline void shaifa(int n){
	for(int i=2;i<=n;i++){
		if(!v[i]){
			prime[++tot]=i;
			v[i]=i;
		}
		for(int j=1;j<=tot&&i*prime[j]<=n;j++){
			v[i*prime[j]]=prime[j];			
			if(i%prime[j]==0) break;
		}
	}
}

int main(){
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	shaifa(1000000);
	cin>>l>>r;
	for(int i=max(2,l);i<=r;i++){
		int cnt=0,x=i;
		while(x!=1){
			cnt++;
			x=x/v[x];
		}
		if(v[cnt]==cnt) ans++;
	}
	cout<<ans<<endl;
	return 0;
}








