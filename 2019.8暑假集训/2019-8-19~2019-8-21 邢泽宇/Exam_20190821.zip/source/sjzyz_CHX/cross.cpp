#include<bits/stdc++.h>
using namespace std;
#define maxn 1200000
#define mod 73939133
int n,m,k;
int head[maxn],to[maxn],nxt[maxn],cnt;
int son[maxn],size[maxn],fa[maxn],dep[maxn],top[maxn];
int C[2000][2000],lca[maxn];
void add(int u,int v)
{
	to[++cnt]=v;
	nxt[cnt]=head[u];
	head[u]=cnt;
}
void dfs1(int u)
{
	size[u]=1;
	dep[u]=dep[fa[u]]+1;
	for(int i=head[u];i;i=nxt[i])
	{
		int v=to[i];
		if(v!=fa[u])
		{
			fa[v]=u;
			dfs1(v);
			size[u]+=size[v];
			if(!son[u]||size[son[u]]<size[v])
			{
				son[u]=v;
			}
		}
	}
}
void dfs2(int u,int tu)
{
	top[u]=tu;
	if(son[u]) dfs2(son[u],tu);
	for(int i=head[u];i;i=nxt[i])
	{
		int v=to[i];
		if(v!=fa[u]&&v!=son[u])
			dfs2(v,v);
	}
}
void ask(int id,int x,int y)
{
	while(top[x]!=top[y])
	{
		dep[top[x]] < dep[top[y]] ? y=fa[top[y]] : x=fa[top[x]];
	}
	lca[id]=dep[x] < dep[y] ?  x : y ;
}
int main()
{
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<n;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);add(v,u);
	}
	dfs1(1);
	dfs2(1,1);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&v,&u);
		ask(i,u,v);
	}
	for(int i=0;i<=m;i++)
	{
		C[i][0]=1;
		for(int j=1;j<=i;j++)
		{
			C[i][j]=(C[i-1][j]+C[i-1][j-1])%mod;
		}
	}
	int tot=m+1,res=0;
	for(int i=1;i<=m;i++)
	{
		for(int j=i+1;j<=m;j++)
		{
			if(lca[i]==1||lca[j]==1)
			{
				if(lca[i]==lca[j]||top[i]==lca[j]||top[j]==lca[i])  
				{
					res++; res%mod;
				}
			}						
			else
			{
				ask(tot,lca[i],lca[j]);
				if (lca[tot]==lca[i]||lca[tot]==lca[j])
				{
					res++; res%=mod;
				}
			}
		}
	}
	if(k==2)
	{
		printf("%d\n",res%mod);
	}
	else 
	{
		printf("%d\n",res*C[m-2][k-2]%mod);
	}
	return 0;
}
