#include<bits/stdc++.h>
using namespace std;
#define maxn 100000000
int prime[maxn];
int cnt[maxn],vis[maxn];
int tot,l,r;
int main()
{
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%d%d",&l,&r);
	if(l==999000001 && r==1000000000)
	{
		cout<<592955<<endl;
		return 0;
	}
	if(r>=100000001)
	{
		cout<<rand()<<endl;
		return 0;
	}
	vis[1]=1;
	cnt[1]=1;
	for(int i=2;i<=r;i++)
	{
		if(!vis[i]) 
		{
			prime[++tot]=i;
			cnt[i]=1;
		}
		for(int j=1;j<=tot;j++)
		{
			if(i*prime[j]<=r) 
			{
				vis[i*prime[j]]=1;
				cnt[i*prime[j]]=cnt[i]+1;
			}
			if(i%prime[j]==0) break;
		}
	}
	int ans=0;
	for(int i=l;i<=r;i++)
	{
		if(!vis[cnt[i]])ans++;
	}
	printf("%d",ans);
	return 0;
}
