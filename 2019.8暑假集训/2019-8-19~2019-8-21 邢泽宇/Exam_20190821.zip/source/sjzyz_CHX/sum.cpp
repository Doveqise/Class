#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define maxn 100000000
const int mod = 1e9+7;
int pow(int a,int b)
{
	int res=1;
	while(b)
	{
		if(b&1) res=res*a%mod;
		a=a*a%mod; 
		b>>=1;
	}
	return res;
}
int n,k;
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&k);
	int ans;
	for(int i=1;i<=n;i++)
	{
		ans=(ans+pow(i,k))%mod;	
	}
	printf("%d",ans);
	return 0;
}
