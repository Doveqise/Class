#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
using namespace std;
const int N=1000010;
const int M=100000;
inline int rnd(){
	int res=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){res=res*10+ch-'0';ch=getchar();}
	return res*f;
}
inline void wr(int x){
	if(x<0)putchar('-'),x=-x;if(x>9)wr(x/10);putchar(x%10+'0');
}
int check[N],prime[N],tot,f[N],pre[N],ans;
int ku[15]={0,63255, 62687, 62463, 62377, 62189, 62304, 61919, 62108, 62109, 61821,61796};
int prek[15];
inline void shai(){
	for(int i=2;i<N;i++){
		if(!check[i])prime[++tot]=i;
		for(int j=1;j<=tot;j++){
			if(i*prime[j]>=N)break;
			check[i*prime[j]]=1;
			if(!(i%prime[j]))break;
		}
	}
}
inline int work(int l,int r){
	ans=0;
	for(int i=l;i<=r;i++){
		int x=i,num=0;
			for(int j=1;j<=tot;j++){
				if(x<prime[j])break;
				while(!(x%prime[j])){
					x/=prime[j];
					num++;
				}
			}
		if(!check[num]&&num>1){
			ans++;
		}
	}
	return ans;
}

int main(){
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	shai();
	for(int i=1;i<=12;i++){
		prek[i]=prek[i-1]+ku[i];
	}
	int l,r;
	l=rnd();r=rnd();
	if(r-l<=100000)
	wr(work(l,r));
	else if(r<=1100000){
		int x=l/100000+1,y=r/100000+1;//if(r==y*100000-1)y++;
		int sum=0;
		sum=prek[y-1]-prek[x];
		sum+=work(l,x*M-1);sum+=work(M*(y-1),r);
		wr(sum);
	}
	else{
		wr(work(l,r));
	}
	puts("");
	return 0;
}
