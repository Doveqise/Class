#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
using namespace std;
const int mod=73939133;
const int N=1000010;
inline int rnd(){
	int res=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){res=res*10+ch-'0';ch=getchar();}
	return res*f;
}
inline void wr(int x){
	if(x<0)putchar('-'),x=-x;if(x>9)wr(x/10);putchar(x%10+'0');
}
int C[1005][1005];
int ins[N],n,m,k,ans;
inline void pre()
{
	C[0][0]=1;
	for(int i=1;i<=1001;i++){
		for(int j=0;j<=5;j++){
			if(j==0){
				C[i][j]=1;continue;
			}
			C[i][j]=C[i-1][j]+C[i-1][j-1];
		}
	}
}
int main(){
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	pre();//cout<<C[2][1]<<' '<<C[5][2];
	n=rnd();m=rnd();k=rnd();int x,y;
	for(int i=1;i<n+m;i++){
		x=rnd();y=rnd();//if(x==y)continue;
		ins[x]++;ins[y]++;
		if(x==y)ins[x]--;
	}
	for(int i=1;i<=n;i++){
		//cout<<ins[i]<<' ';
		if(ins[i])
		ans=(ans+C[ins[i]][k])%mod;
	}
	wr(ans/2);
	return 0;
}
