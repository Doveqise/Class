#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>

using namespace std;
const int N=100000010;
const int mod=1e9+9;
inline int rnd(){
	int res=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0'){res=res*10+ch-'0';ch=getchar();}
	return res*f;
}
inline void wr(int x){
	if(x<0)putchar('-'),x=-x;if(x>9)wr(x/10);putchar(x%10+'0');
}
int prime[N],tot,phi[N];
bool chk[N];

inline int fast(int x,int b){
	int sum=1,base=x;
	while(b){
		if(b&1)sum=sum*base%mod;
		base=base*base%mod;
		b>>=1;
	}
	return sum;
}
inline void work(){
	for(int i=2;i<N;i++){
		if(!chk[i])prime[++tot]=i,phi[i]=1;
		for(int j=1;j<=tot;j++){
			if(i*prime[j]>N)break;
			chk[i*prime[j]]=1;
			if(i%prime[j]){
				phi[i*prime[j]]=phi[i]+phi[prime[j]];
			}
			else{
				phi[i*prime[j]]=(phi[i]+1)*phi[prime[j]];break;
			}
		}
	}
}
int n,k,ans=1;
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	work();
	n=rnd();k=rnd();
	for(int i=1;i<=n;i++){
		ans=(ans+phi[fast(i,k)])%mod;
	}
	wr(ans);
	return 0;
}
