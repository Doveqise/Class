#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=1e7+50,mod=1e9+9;
int phi[N],p[N],tot,mindiv[N],pw[N],ans=1,n,k;
int power(int x,int y){
	int ret=1;
	for(;y;y>>=1,x=1ll*x*x%mod)if(y&1)ret=1ll*ret*x%mod;
	return ret;
}
void pre(){
	phi[1]=1;pw[1]=1;
	for(int i=2;i<=n;i++){
		if(!mindiv[i])mindiv[i]=p[++tot]=i,phi[i]=i-1,pw[i]=power(i,k-1);
		for(int j=1,y;j<=tot&&p[j]<=mindiv[i]&&(y=p[j]*i)<=n;j++)
			mindiv[y]=p[j],phi[y]=phi[i]*(i%p[j]?p[j]-1:p[j]),pw[y]=1ll*pw[p[j]]*pw[i]%mod;
	}
}
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&k);
	if(k==0)printf("%d\n",n),exit(0);
	pre();
	for(int i=2;i<=n;i++)ans=(ans+1ll*phi[i]*pw[i])%mod;
	printf("%d\n",ans);
	return 0;
}
//10000000 1000
