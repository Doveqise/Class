#include<bits/stdc++.h>
#define LL long long
using namespace std;
const int N=1e5,M=1e6+50;
int n,p[M],mindiv[M],tot,cnt[M],ans,l,r,a[M];bool flag[100];
void pre(){
	for(int i=2;i<=n;i++){
		if(!mindiv[i])mindiv[i]=p[++tot]=i;
		for(int j=1,y;j<=tot&&p[j]<=mindiv[i]&&(y=p[j]*i)<=n;j++)
			mindiv[y]=p[j];
	}
}
void solve(int x,int p){
	int s=l/x*x;
	if(s<l)s+=x;
	for(int i=s;i<=r;i+=x)cnt[i-l]++,a[i-l]/=p;
}
int main(){
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	scanf("%d%d",&l,&r);
	for(int i=l;i<=r;i++)a[i-l]=i;
	n=sqrt(r);pre();
	for(int i=1;i<=tot;i++){
		LL tmp=p[i];
		while(tmp<=r)solve(tmp,p[i]),tmp*=p[i];
	}
	for(int i=1;i<=tot&&p[i]<=30;i++)flag[p[i]]=1;
	for(int i=0;i<=r-l;i++){
		if(a[i]!=1)cnt[i]++;
		ans+=flag[cnt[i]];
	}
	cout<<ans;
	return 0;
}
