#include<bits/stdc++.h>
using namespace std;
const int N=3e5+50;
int n,m,k,ver[N*2],nxt[N*2],head[N],tot,a[N],b[N],ff[N],f[N][20],d[N],lo[N],ans,pp[10][N],num;bool flag[200];
void add(int x,int y){ver[++tot]=y;nxt[tot]=head[x];head[x]=tot;}
void pre(int x,int fa){
	d[x]=d[fa]+1;f[x][0]=fa;
	for(int i=1;i<=lo[d[x]];i++)f[x][i]=f[f[x][i-1]][i-1];
	for(int i=head[x];i;i=nxt[i])if(ver[i]!=fa)pre(ver[i],x);
}
int lca(int x,int y){
	if(d[x]<d[y])swap(x,y);
	for(int i=lo[d[x]-d[y]];i>=0;i--)if(d[f[x][i]]>=d[y])x=f[x][i];
	if(x==y)return x;
	for(int i=lo[d[x]];i>=0;i--)if(f[x][i]!=f[y][i])x=f[x][i],y=f[y][i];
	return f[x][0];
}
bool check(int x,int y){
	if(d[ff[x]]<d[ff[y]])swap(x,y);
	return lca(ff[x],a[y])==ff[x]||lca(ff[x],b[y])==ff[x];
}
void solve1(){
	for(int i=1;i<m;i++)
		for(int j=i+1;j<=m;j++)
			ans+=check(i,j);
	printf("%d\n",ans);
}
void dfs(int now,int fr){
	if(now>k){ans++;return;}
	bool flagg[200];int numm=num;
	memcpy(flagg,flag,sizeof(flag));
	for(int i=fr;i<=m;i++){
		for(int j=1;j<=n;j++)if(flag[j]&&!pp[i][j])flag[j]=0,num--;
		if(num)dfs(now+1,i+1);
		memcpy(flag,flagg,sizeof(flag));num=numm;
	}
}
void solve2(){
	for(int i=1,x,y;i<=m;i++){
		x=a[i],y=b[i];
		while(x!=ff[i])pp[i][x]=1,x=f[x][0];
		while(y!=ff[i])pp[i][y]=1,y=f[y][0];
		pp[i][ff[i]]=1;
	}
	for(int i=1;i<=n;i++)flag[i]=1;num=n;
	dfs(1,1);
	printf("%d\n",ans);
}
int main(){
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1,x,y;i<n;i++){
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	for(int i=1;i<=m;i++)scanf("%d%d",&a[i],&b[i]);
	lo[0]=-1;
	for(int i=1;i<=n;i++)lo[i]=lo[i>>1]+1;
	pre(1,0);
	for(int i=1;i<=m;i++)ff[i]=lca(a[i],b[i]);
	if(k==2)solve1();
	else solve2();
	return 0;
}
//7 0 0
//1 2
//2 3
//3 5
//2 4
//1 6
//6 7
