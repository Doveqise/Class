#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<cmath>
using namespace std;
#define ll long long
const int mod=1e9+7;
ll ksm(ll a,ll b){
	ll ans=1;
	for(;b;b>>=1){
		if(b&1) ans=(ans*a)%mod;
		a=(a*a)%mod;
	}
	return ans%mod;
}
ll n,k;
int euler(int x){
	int len=sqrt(x);
	int ans=x;
	for(int i=2;i<=len;i++){
		if(x%i==0){
			while(x%i==0)x/=i;
			ans=ans/i*(i-1);
		}
	}
	if(x>1) ans=ans/x*(x-1);
	return ans;
}
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	ll ans=1;
	for(int i=2;i<=n;i++) ans=(ans+euler(ksm(i,k)))%mod,printf("%lld\n",ans);
	printf("%lld",ans);
	return 0;
}
