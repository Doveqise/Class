#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
#define N 300010
#define ll long long
const int mod=73939133;
int ver[N<<1],f[N],nxt[N<<1],head[N],tot,n,m,k,u[N],v[N],sum;
int size[N],d[N],top[N],son[N],ans[N],jie[N],c[1010][1010];
bool vis[10010][10010];
void add(int x,int y){
	ver[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
void dfs(int x,int fa){
	size[x]=1;
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==fa)continue;
		d[y]=d[x]+1;
		f[y]=x;
		dfs(y,x);
		size[x]+=size[y];
		if(!son[x]||size[son[x]]<size[y])
			son[x]=y;
	}
}
void dfs1(int x,int tp){
	top[x]=tp;
	if(son[x]) dfs1(son[x],tp);
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==f[x]||y==son[x])continue;
		dfs1(y,y);
	}
}
int LCA(int x,int y){
	while(top[x]!=top[y]){
		if(d[top[x]]>=d[top[y]]) x=f[top[x]];
		else y=f[top[y]];
	}
	return d[x]<d[y]?x:y;
}
int main(){
	freopen("cross.in","r",stdin);
	freopen("cross.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);int x,y;
	for(int i=1;i<n;i++) scanf("%d%d",&x,&y),add(x,y),add(y,x);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u[i],&v[i]);
		if(u[i]>v[i])swap(u[i],v[i]);
		if(vis[u[i]][v[i]])m--,i--;
	}
	d[1]=1;
	dfs(1,0);
	dfs1(1,1);
	jie[0]=1;
	for(int i=1;i<=m;i++) jie[i]=jie[i-1]*i%mod;
	for(int i=1;i<=m;i++) c[i][i]=1,c[i][0]=1;
	for(int i=1;i<=m;i++)
		for(int j=1;j<i;j++){
			c[i][j]=(c[i-1][j]+c[i-1][j-1])%mod;
		}
	for(int i=1;i<=m;i++)
		for(int j=i+1;j<=m;j++){
			if((d[u[i]]>d[v[j]])||(d[v[i]]<d[u[j]])) ans[i]++;
			if((d[u[i]]>d[u[j]&&d[u[i]]<d[v[j]]])||(d[u[j]]>d[u[i]]&&d[u[j]]<d[v[i]])){
				if(LCA(u[i],u[j])==u[i]||LCA(u[i],u[j])==u[j])continue;
				if(LCA(u[i],v[j])==u[i]||LCA(u[i],v[j])==v[j])continue;
				if(LCA(v[i],u[j])==v[i]||LCA(v[i],u[j])==u[j])continue;
				if(LCA(v[i],v[j])==v[i]||LCA(v[i],v[j])==v[j])continue;
				ans[i]++;
			}
		}
	ans[0]=1;
	for(int i=0;i<=m;i++) sum+=ans[i];
	printf("%d",c[m][k]-sum);
	return 0;
}
