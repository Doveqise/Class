#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cmath>
using namespace std;
int c[111000000],p[111000000],tot,n,ans;
void divide(int x){
	int len=sqrt(x);
	for(int i=2;i<=len;i++){
		if(n%i==0){
			p[++tot]=i;
			while(n%i==0)n/=i,c[tot]++;
		}
	}
	if(n>1) p[++tot]=n,c[tot]=1;
}
bool v[100025012];
void shai(){
	for(int i=2;i<=n;i++)
		for(int j=2;j*i<=n;j++) v[i*j]=1;
}
int main(){
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	int l,r;
	scanf("%d%d",&l,&r);
	n=r;
//	v[1]=1;
	int sum=0;
	shai();
//	for(int i=1;i<=n;i++) printf("%d %d\n",i,v[i]);
	for(int i=l;i<=r;i++){
		divide(i);
//		sum=0;
		for(int j=1;j<=tot;j++) sum+=c[j];
		if(!v[sum]) ans++;
		for(int j=1;j<=tot;j++) p[j]=0,c[j]=0;
		tot=0;
	}
	printf("%d",ans);
}
