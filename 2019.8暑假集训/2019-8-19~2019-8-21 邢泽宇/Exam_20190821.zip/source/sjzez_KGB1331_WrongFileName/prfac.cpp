#pragma GCC optimize(3)
#pragma GCC target("avx")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("inline")

#include <bits/stdc++.h>
#define FR freopen
typedef long long ll;
using namespace std;
int prime[10000005];
int a[1000005];
bool vis[10000005];
int cnt=0;
void primejudge(int n)
{
    memset(vis,false,sizeof(vis));
    vis[1]=true;
    int i,j;
    for(i=2;i<=n;i++)
    {
        if(!vis[i]) prime[cnt++]=i;
        for(j=0;j<cnt&&i*prime[j]<=n;j++)
        {
            vis[i*prime[j]]=true;
            if(i%prime[j]==0) break;
        }
    }
}

bool is(unsigned long long n) 
{ 
	if(n==1) return 0;
	unsigned long long stop=n/6+1,Tstop=sqrt(n)+5;
	if (n==2||n==3||n==5||n==7||n==11) return 1;
	if (n%2==0||n%3==0||n%5==0||n==1) return 0;
	for (unsigned long long i=1;i<=stop;i++)
	{
		if (i*6 >=Tstop) break;
		if ((n%(i * 6 + 1)==0)||(n%(i*6+5)==0)) return 0;
	}
	return 1;
}

int ask(int n)
{
	int index=0;
	int ad=0;
	for(register int i=0;i<cnt;i++)
    {
        while(n%prime[i]==0)
        {
            a[index++]=prime[i];
            n/=prime[i];
        }
        if(n==1) break;
    }
    if(n!=1)
    {
        a[index++]=n;
    }
    for(register int i=0;i<index;i++)
    {
        ad++;
    }
    return ad;
}

signed main(void)
{
	FR("prfac.in","r",stdin);
	FR("prfac.out","w",stdout);
    primejudge(10000005); 
    ll n,m;
    cin>>n>>m;
    ll sum=0;
    for(register int i=n;i<=m;i++)
	{
		if(is(i)==1) continue;
		ll as=ask(i);
		sum+=is(as);
	} 
    printf("%d",sum);
    return 0;
}
