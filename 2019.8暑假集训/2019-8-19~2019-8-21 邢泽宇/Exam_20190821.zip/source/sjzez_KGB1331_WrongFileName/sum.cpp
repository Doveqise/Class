#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int long long
ll eu(ll n)
{
	ll ans=n;
	for(ll i=2;i*i<=n;i++)
	{   
		if(n%i==0)
		{   
			ans=ans/i*(i-1);
			while(n%i==0) n/=i;
		}
	}
	if(n>1)
	ans=ans/n*(n-1);
	return ans;
}

ll pow(ll x,ll n,ll mod)
{
    ll res=1;
	while(n>0)
	{
	   if(n%2==1)	
	   {
	   	 res=res*x;
	   	 res=res%mod;
	   }
	   x=x*x;
	   x=x%mod;
	   n>>=1;
	}
	return res;	
}


signed main(void)
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	int n,k;
	cin>>n>>k; 
	ll sum=0,moda=1e9+9;
	for(int i=1;i<=n;i++)
	{
		int p=pow(i,k,moda);
		p%=moda;
		int ulr=eu(p);
		ulr%=moda;
		sum+=ulr;
		sum%=moda;
	}
	cout<<sum%moda;
} 
