#include<bits/stdc++.h>
using namespace std;
const long long mod=1000000009;
long long n,k,ans;
long long qpow(long long a,long long b){
	long long ans=1;
	while(b){
		if(b&1) ans=ans*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ans;
}
long long phi(long long x){
	long long sum=x;
	int sq=sqrt(x);
	for(int i=2;i<=sq;i++){
		if(x%i==0){
			sum=sum/i*(i-1);
			while(x%i==0) x/=i;
		}
	}
	if(x>1) sum=sum/x*(x-1);
	return sum;
}
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
		ans=(ans+phi(qpow(i,k)))%mod;
	cout<<ans;
}
