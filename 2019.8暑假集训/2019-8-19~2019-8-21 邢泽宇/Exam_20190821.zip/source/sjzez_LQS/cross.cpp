#include<bits/stdc++.h>
using namespace std;
const int N=300010,M=600010,mod=73939133;
int n,m,k,u,v,tot;
int head[N],ver[M],nx[M],fac[M]={1,0},inv[M]={1,0};
int f[N][25],d[N],pls[N],cs[N];
long long qpow(long long a,long long b){
	long long ans=1;
	while(b){
		if(b&1) ans=ans*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ans;
}
long long C(long long a,long long b){
	if(b==0||b>a) return 0;
	return fac[a]*inv[b]%mod*inv[a-b]%mod;
}
void add(int x,int y){
	ver[++tot]=y;
	nx[tot]=head[x];
	head[x]=tot;
}
void dfs(int x,int fa){
	d[x]=d[fa]+1;
	f[x][0]=fa;
	for(int i=head[x];i;i=nx[i]){
		if(ver[i]==fa) continue;
		dfs(ver[i],x);
	}
}
void pre(){
	for(int i=1;i<=600000;i++){
		fac[i]=fac[i-1]*i%mod;
		inv[i]=qpow(fac[i],mod-2);
	}
	for(int i=1;i<=20;i++)
		for(int j=1;j<=n;j++)
			f[j][i]=f[f[j][i-1]][i-1];
}
int lca(int x,int y){
	if(d[x]<d[y]) swap(x,y);
	while(d[x]!=d[y]){
		for(int i=20;i>=0;i--)
			if((d[x]-(1<<i))>=d[y]) x=f[x][i];
	}
	if(x==y) return x;
	for(int i=20;i>=0;i--)
		if(f[x][i]!=f[y][i])
			x=f[x][i],y=f[y][i];
	return f[x][0];
}
void dfs1(int x,int fa){
	for(int i=head[x];i;i=nx[i]){
		if(ver[i]==fa) continue;
		dfs1(ver[i],x);
		pls[x]+=pls[ver[i]];
	}
}
int main(){
	freopen("cross.in","r",stdin);
    freopen("cross.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	dfs(1,0);
	pre();
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		int L=lca(u,v);
		cs[L]++;
		pls[u]++,pls[v]++,pls[L]--,pls[f[L][0]]--;
	}
	dfs1(1,0);
	long long ans=0;
	for(int i=1;i<=n;i++)
		ans=(ans+(C(pls[i],k)-C(pls[i]-cs[i],k)%mod+mod)%mod)%mod;
	cout<<ans;
}
