#include<bits/stdc++.h>
using namespace std;
int l,r,tot,n;
bool y[1000010],v[1000010];
int p[1000010];
void prime(int x){
	for(int i=2;i<=x;i++){
		if(v[i]) continue;
		p[++tot]=i;
		for(int j=i;j<=x/i;j++)
			v[i*j]=1;
	}
}
void dfs(int now,int sum){
	if(sum>r) return;
	if(y[sum]) return;
	if(!v[now]) y[sum]=1;
	for(int i=1;i<=tot;i++)
		dfs(now+1,sum*p[i]);
}
int main(){
	freopen("prfac.in","r",stdin);
	freopen("prfac.out","w",stdout);
	cin>>l>>r;
	prime(r);
	v[1]=1;
	dfs(0,1);
	y[1]=0;
	int ans=0;
	for(int i=l;i<=r;i++)
		if(y[i]) ans++;
	cout<<ans;
}
