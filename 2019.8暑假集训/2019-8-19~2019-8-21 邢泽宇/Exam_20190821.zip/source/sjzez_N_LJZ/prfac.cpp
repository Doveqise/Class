#include <cstdio>
#include <cctype>
#include <vector>

using namespace std;

namespace BANANA {

template<typename T> inline void read(T &x) {
	x = 0; T k = 1; char in = getchar();
	while (!isdigit(in)) { if (in == '-') k = -1; in = getchar(); }
	while (isdigit(in)) x = x * 10 + in - '0', in = getchar();
	x *= k;
}

const int N = 2e7 + 5;

int l, r, ans;
int sum[N];
bool vis[N];
vector<int> pri;

inline void oula(int n) {
	vis[1] = vis[0] = true;
	for (int i = 2; i <= n; ++i) {
		if (!vis[i]) {
			pri.push_back(i);
			sum[i] = 1;
		}
		for (int j = 0; j < pri.size() && pri[j] * i <= n; ++j) {
			vis[pri[j] * i] = true;
			sum[i * pri[j]] = sum[i] + 1;
			if (i % pri[j] == 0)
				break;
		}
	}
}

inline void main() {
	read(l), read(r);
	oula(r);
	for (int i = l; i <= r; ++i)
		ans += !vis[sum[i]];
	printf("%d\n", ans);
}
}

int main() {
	freopen("prfac.in", "r", stdin);
	freopen("prfac.out", "w", stdout);
	BANANA::main();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
