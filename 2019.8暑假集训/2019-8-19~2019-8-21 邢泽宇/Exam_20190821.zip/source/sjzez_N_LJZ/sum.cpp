#include <cstdio>
#include <cctype>
#include <vector>

using namespace std;

namespace BANANA {

template<typename T> inline void read(T &x) {
	x = 0; T k = 1; char in = getchar();
	while (!isdigit(in)) { if (in == '-') k = -1; in = getchar(); }
	while (isdigit(in)) x = x * 10 + in - '0', in = getchar();
	x *= k;
}

const int N = 1e7 + 5;
const int MOD = 1e9 + 9;

int n, k, ans;
int phi[N];
bool vis[N];
vector<int> pri;

inline int q_pow(int a, int b) {
	int re = 1;
	while (b) {
		if (b & 1)
			re = (1ll * re * a) % MOD;
		a = (1ll * a * a) % MOD;
		b >>= 1;
	}
	return re;
}

inline void oula() {
	phi[1] = 1;
	for (int i = 2; i <= n; ++i) {
		if (!vis[i]) {
			vis[i] = true;
			pri.push_back(i);
			phi[i] = i - 1;
		}
		for (int j = 0; j < pri.size() && pri[j] * i <= n; ++j) {
			vis[pri[j] * i] = true;
			if (i % pri[j] == 0) {
				phi[i * pri[j]] = pri[j] * phi[i];
				break;
			}
			phi[i * pri[j]] = (pri[j] - 1) * phi[i];
		}
	}
}

inline void main() {
	read(n), read(k);
	oula();
	for (int i = 1; i <= n; ++i)
		ans = (1ll * phi[i] * q_pow(i, k-1) % MOD + ans) % MOD;
	printf("%d\n", ans);
}
}

int main() {
	freopen("sum.in", "r", stdin);
	freopen("sum.out", "w", stdout);
	BANANA::main();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
