#pragma GCC optimize("Ofast")
#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int maxn=1e6+10;
int l,r;
int prime1[maxn],v[maxn],m;
inline void prime3(int n){
    memset(v,0,sizeof(v));
    m=0;
    for(register int i=2;i<=n;i++){
        if(v[i]==0){
            v[i]=i;prime1[++m]=i;
        }
        for(register int j=1;j<=m;j++){
            if(prime1[j]>v[i]||prime1[j]>n/i) break;
            v[i*prime1[j]]=prime1[j];
        }
    }
    for(register int i=2;i<=n;i++)
        if(v[i]==i) v[i]=1;
        else v[i]=0;
}
inline bool shu(int x){
    int cnt=0;
    for(register int j=2;j<=sqrt(x);j++)
        while (x%j==0){
            cnt++;
            x/=j;
            if(x==1) break;
        }
    if(x>1) 
        cnt++;
    return v[cnt];
}
int main()
{
    freopen("prfac.in","r",stdin);
    freopen("prfac.out","w",stdout);
    scanf("%d%d",&l,&r);
    prime3(r);
    int ans=0;
    for(register int i=l;i<=r;i++){
        if(shu(i)) ans++;
    }
    printf("%d\n",ans);
    // system("pause");
    fclose(stdin);fclose(stdout);
    return 0;
}