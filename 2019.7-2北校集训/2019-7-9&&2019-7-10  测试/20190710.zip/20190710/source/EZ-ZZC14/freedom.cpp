#include<bits/stdc++.h>
#define R register int
#define il inline
const int N=1000001;
struct ztree{int t,s,size,l,r;}h[N];struct edge{int to,nxt;}e[N*2];int p,n,ans=-1,root,ttt,d[N],z[N];bool vis[N];
il int merge(int a,int b){
	if(a==0)return b;if(b==0)return a;if(h[a].t<h[b].t){int ant=b;b=a;a=ant;}
	h[a].r=merge(h[a].r,b);int l=h[a].l,r=h[a].r;if(h[l].s<h[r].s){int ant=r;r=l;l=ant;}
	h[a].l=l,h[a].r=r;h[a].s=h[r].s+1;h[a].size=h[l].size+h[r].size+1;return a;
}
il int add2(int s,int x){h[++p].t=x;h[p].s=0;h[p].size=1;return merge(s,p);}
il void add(const int a,const int b){e[++ttt].to=b;e[ttt].nxt=d[a];d[a]=ttt;} 
il int dfs(int x){
		vis[x]=true;bool flg=true;
		for(int i=d[x];i;i=e[i].nxt){int y;if(!vis[y=e[i].to]){root=flg?dfs(y):merge(root,dfs(y));flg=0;}}
		if(flg)return add2(0,1);h[root].t++;return root;
}
signed main(){
	freopen("freedom.in","r",stdin);freopen("freedom.out","w",stdout);
	scanf("%d",&n);for(R i=1;i<n;i++){int a,b;scanf("%d %d",&a,&b);add(a,b);add(b,a);}
	root=dfs(1);printf("%d\n",h[root].size);
	while(h[root].size){ans+=h[root].t;printf("%d\n",ans);root=merge(h[root].l,h[root].r);}fclose(stdout);return 0;   
}
