#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
using namespace std;
int main()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	srand(time(0));
	int a,b,c,d,e,f;
	cin>>a>>b;
	while(b--) cin>>c;
	cin>>c;
	c--;
	while(c--) cin>>e;
	float n=(float)(rand()%a)/10;
	float m=(float)(rand()%a)/10;
	cout<<n<<" "<<m;
}
