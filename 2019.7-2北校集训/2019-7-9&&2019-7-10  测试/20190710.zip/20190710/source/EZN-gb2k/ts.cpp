#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <cstring>
using namespace std;
const int maxn=5e6+233;
int n,m;
int maxx;

int fa[maxn],cnt[maxn],use,used[maxn];

void init()
{
	memset(used,0,sizeof(used));
	for(int i=1;i<=n;i++) fa[i]=i;
}

int find(int x)
{
	if(x==fa[x]) return fa[x];
	fa[x]=find(fa[x]);
}

void ins(int x,int y)
{
	if(find(x)==find(y)) return ;
	fa[y]=find(x);
}

int main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	int x,y;
	cin>>n>>m;
	use=n;
	init();
	int ans=0;
	for(int i=1;i<=m;i++)
	{
		cin>>x>>y;
		if(fa[x]!=fa[y])
		{
			ins(x,y);
			if(!used[x]) use--,used[x]=1;
			if(!used[y]) use--,used[y]=1; 
			cout<<1<<" ";
			cnt[x]++;
			cnt[y]++;
			maxx=max(max(cnt[x],cnt[y]),maxx);
			ans=max(maxx+use,n-(maxx+use));
			cout<<ans<<endl;
		/*	cout<<"-------------"<<endl;
			cout<<endl<<ans<<" "<<maxx<<" "<<use<<endl;
			cout<<"-------------"<<endl;
		*/
		}else{
			cout<<0<<" "<<ans<<endl;
		}
		
	}
}
