#include<cstdio>
#include<iostream>
#include<set>
using namespace std;
#define R register int
#define ull unsigned long long
#define ll long long
#define pause (for(R i=1;i<=10000000000;++i))
#define In freopen("NOIPAK++.in","r",stdin)
#define Out freopen("out.out","w",stdout)
namespace Fread {
	static char B[1<<15],*S=B,*D=B;
#ifndef JACK
	#define getchar() (S==D&&(D=(S=B)+fread(B,1,1<<15,stdin),S==D)?EOF:*S++)
#endif
	inline int g() {
		R ret=0,fix=1; register char ch;
		while(!isdigit(ch=getchar()))
			fix=ch=='-'?-1:fix;
		if(ch==EOF) return EOF;
		do
			ret=ret*10+(ch^48);
		while(isdigit(ch=getchar()));
		return ret*fix;
	}
	inline bool isempty(const char& ch) {
		return (ch<=36||ch>=127);
	}
	inline void gs(char* s) {
		register char ch; while(isempty(ch=getchar()));
		do *s++=ch; while(!isempty(ch=getchar()));
	}
}
using Fread::g;
using Fread::gs;

namespace Jack {	
const int N=1000010;
int n,cnt;
int vr[N<<1],nxt[N<<1],fir[N],d[N],mxd[N],anss[N];
set<pair<int,int> > s[N];
inline void add(int u,int v) {
	vr[++cnt]=v,nxt[cnt]=fir[u],fir[u]=cnt;
}
inline void dfs(int u) {
	for(R i=fir[u];i;i=nxt[i]) { 
		R v=vr[i]; 
		if(d[v]) continue;
		d[v]=d[u]+1,mxd[v]=d[v];
		dfs(v); 
		mxd[u]=max(mxd[u],mxd[v]);
		s[u].insert(make_pair(mxd[v]-d[u],v));
	}
}
inline int upd(int u) {
	if(!s[u].size()) return 0;
	R v=(*--s[u].end()).second;
	s[u].erase(--s[u].end());
	R tmp=upd(v);
	if(tmp!=0) 
		s[u].insert(make_pair(tmp,v));
	if(s[u].size()) 
		return (*--s[u].end()).first;
	else return 0;
}
inline void print(int u) {
	for(set<pair<int,int> >::iterator it=s[u].begin();it!=s[u].end();++it) 
		cout<<(*it).first<<" "<<(*it).second<<endl;
}
void main() {
	n=g(); 
	for(R i=1,u,v;i<n;++i) 
		u=g(),v=g(),
		add(u,v),add(v,u);
	mxd[1]=d[1]=1; dfs(1);
	R ans=0;
	for(ans=1;s[1].size();++ans) 
		anss[ans]=anss[ans-1]+(*--s[1].end()).first,
		//print(2),
		upd(1);
	printf("%d\n",ans-=1);
	for(R i=1;i<=ans;++i) 
		printf("%d\n",anss[i]);
}
}
signed main() {
#ifdef JACK
In; Out;
#endif
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	Jack::main();
}
