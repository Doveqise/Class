#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
#define R register double
#define ull unsigned long long
#define ll long long
#define pause (for(R i=1;i<=10000000000;++i))
#define In freopen("NOIPAK++.in","r",stdin)
#define Out freopen("out.out","w",stdout)
namespace Fread {
	static char B[1<<15],*S=B,*D=B;
#ifndef JACK
	#define getchar() (S==D&&(D=(S=B)+fread(B,1,1<<15,stdin),S==D)?EOF:*S++)
#endif
	inline int g() {
		R ret=0,fix=1; register char ch;
		while(!isdigit(ch=getchar()))
			fix=ch=='-'?-1:fix;
		if(ch==EOF) return EOF;
		do
			ret=ret*10+(ch^48);
		while(isdigit(ch=getchar()));
		return ret*fix;
	}
	inline bool isempty(const char& ch) {
		return (ch<=36||ch>=127);
	}
	inline void gs(char* s) {
		register char ch; while(isempty(ch=getchar()));
		do *s++=ch; while(!isempty(ch=getchar()));
	}
}
using Fread::g;
using Fread::gs;

namespace Jack {

const int N=310;
double L,p[N],d[N],w[N],anss,ans;
int n,m;
void main() {
	scanf("%lf%d",&L,&m);
	for(register int i=1;i<=m;++i) scanf("%lf",&p[i]);
	scanf("%d",&n);
	for(register int i=2;i<=n;++i) scanf("%lf",&d[i]);
	R mn=0,mx=L-d[n]; 
	for(R t=mn;t<=mx;t+=0.01) { 
		for(register int i=1;i<=m;++i) { w[i]=100000000.0;
			for(register int j=1;j<=n;++j) {
				w[i]=min(abs(d[j]+t-p[i]),w[i]);
			}
		}  
		R tmp=0;
		for(register int i=1;i<=m;++i) tmp+=w[i];
		if(tmp>ans) ans=tmp,anss=t;
	}
	printf("%.1lf %.1lf\n",anss,ans);
}
}
signed main() {
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	Jack::main();
}
