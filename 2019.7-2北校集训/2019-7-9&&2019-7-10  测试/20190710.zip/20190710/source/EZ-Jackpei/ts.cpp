#include<cstdio>
#include<iostream>
using namespace std;
#define R register int
#define ull unsigned long long
#define ll long long
#define pause (for(R i=1;i<=10000000000;++i))
#define In freopen("NOIPAK++.in","r",stdin)
#define Out freopen("out.out","w",stdout)
namespace Fread {
	static char B[1<<15],*S=B,*D=B;
#ifndef JACK
	#define getchar() (S==D&&(D=(S=B)+fread(B,1,1<<15,stdin),S==D)?EOF:*S++)
#endif
	inline int g() {
		R ret=0,fix=1; register char ch;
		while(!isdigit(ch=getchar()))
			fix=ch=='-'?-1:fix;
		if(ch==EOF) return EOF;
		do
			ret=ret*10+(ch^48);
		while(isdigit(ch=getchar()));
		return ret*fix;
	}
	inline bool isempty(const char& ch) {
		return (ch<=36||ch>=127);
	}
	inline void gs(char* s) {
		register char ch; while(isempty(ch=getchar()));
		do *s++=ch; while(!isempty(ch=getchar()));
	}
}
using Fread::g;
using Fread::gs;

namespace Jack {
const int N=500010;
int n,m,ct,tot,tim,fa[N],cnt[2],c[N],sz[N];
bool vis[N];
inline int getf(int x) {
	if(x==fa[x]) return x;
	R r=getf(fa[x]);
	return fa[x]=r;
}
int vr[N<<1],nxt[N<<1],fir[N];
int usd[N];
inline void add(int u,int v) {
	vr[++ct]=v,nxt[ct]=fir[u],fir[u]=ct;
}
inline void dfs(int u,int cl,int fa) { 
	usd[u]=tim;
	vis[u]?--cnt[c[u]]:vis[u]=true;
	c[u]=cl;
	++cnt[c[u]];
	for(R i=fir[u];i;i=nxt[i]) { 
		R v=vr[i]; if(usd[v]==tim) return ;
		dfs(v,cl^1,u);
	}
}
void main() {
	tot=n=g(),m=g();
	for(R i=1;i<=n;++i) fa[i]=i,sz[i]=1;
	for(R i=1,u,v;i<=m;++i) {
		u=g(),v=g();
		tot-=(!vis[u]),tot-=(!vis[v]);
		R uf=getf(u),vf=getf(v);
		if(uf==vf) {
			if(c[u]==c[v]) 
				printf("0 %d\n",max(cnt[0],cnt[1])+tot);
			else 
				printf("1 %d\n",max(cnt[0],cnt[1])+tot),add(u,v),add(v,u);
		} else {
			
//			if(u==2&&v==5)
//				cout<<"fhajsdf"<<'\n';
			
			add(u,v),add(v,u);
			sz[uf]>sz[vf]?swap(uf,vf),swap(u,v):void(0);
			if(c[u]==c[v]&&vis[u]) 
				++tim,
				dfs(u,c[v]^1,-1);
			if(!vis[v]) 
				++cnt[c[v]];
			if(!vis[u]) {
				c[u]=c[v]^1;
				++cnt[c[u]];
			}
			fa[uf]=vf;
			sz[vf]+=sz[uf];
			printf("1 %d\n",max(cnt[0],cnt[1])+tot);
		}
		vis[u]=true,vis[v]=true;
		//cout<<cnt[0]<<" "<<cnt[1]<<'\n';
//		cout<<'\n'<<'\n';
//		for(R i=1;i<=n;++i) cout<<i<<" "<<vis[i]<<" "<<c[i]<<'\n';
//		cout<<'\n'<<'\n';
	}
}
}
signed main() {
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	Jack::main();
}
