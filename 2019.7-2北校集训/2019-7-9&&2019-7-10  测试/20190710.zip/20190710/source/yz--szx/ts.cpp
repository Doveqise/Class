#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
#define rg register
inline int read(){
	rg char ch=getchar();
	rg int x=0,f=0;
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
int fa[500010],to[500050],t[500050],sz[500050],n,m,now;
int find(int x){
	if(fa[x]==x) return x;
	int ff=find(fa[x]);
	to[x]=to[x]^to[fa[x]];
	fa[x]=ff;
	return ff;
}
int main(){
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	now=n=read(),m=read();
	for(int i=1;i<=n;++i) fa[i]=i,sz[i]=1;
	for(int x,y,xl,yl,i=1;i<=m;++i){
		x=read(),y=read();
//		cout<<"-----------"<<endl;
		xl=find(x),yl=find(y);
//		cout<<xl<<" "<<yl<<endl;
		if(xl==yl){
			if((to[x]^to[y])!=1){
				printf("0 %d\n",now);
			}else printf("1 %d\n",now);
		}else{
			now+=min(t[xl],sz[xl]-t[xl])+min(t[yl],sz[yl]-t[yl]);
			if(to[x]^1) t[yl]+=sz[xl]-t[xl];
			else t[yl]+=t[xl];
			sz[yl]+=sz[xl];
			sz[xl]=t[xl]=0;
			to[xl]=1^to[x];
			fa[xl]=yl;
//			cout<<to[x]<<" "<<to[y]<<" "<<to[xl]<<" "<<sz[yl]<<endl;
//			cout<<"upupupup"<<endl;
			now-=min(t[yl],sz[yl]-t[yl]);
			printf("1 %d\n",now);
		}
	}
	return 0;
}
