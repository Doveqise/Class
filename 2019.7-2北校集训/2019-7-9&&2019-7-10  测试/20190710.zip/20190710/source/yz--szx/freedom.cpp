#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<queue>
using namespace std;
#define rg register
inline int read(){
	rg char ch=getchar();
	rg int x=0,f=0;
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
const int ver=0,nxt=1;
int tot,head[1000010],edge[2000010][2],n,dp[1000010],sum,hehe,dep[1000010],ans[1000010],cnt,now[1000010],f[1000010];
void add(int x,int y){
	edge[++tot][ver]=y;
	edge[tot][nxt]=head[x];
	head[x]=tot;
}
void find(int x,int fa,int dp){
	now[x]=dep[x]=dp;f[x]=fa;
	for(int y,i=head[x];i;i=edge[i][nxt]){
		y=edge[i][ver];
		if(y==fa) continue;
		find(y,x,dp+1);
		dep[x]=max(dep[x],dep[y]);
	}
}
void dfs(int x,int fa){
//	dp[x]=1;
	int flag=0;
	for(int y,i=head[x];i;i=edge[i][nxt]){
		y=edge[i][ver];
		if(y==fa) continue;
		dfs(y,x);
//		sz[x]+=sz[y];
		++flag;
	}
	if(flag) sum+=flag-1;
//	else sz[x]=1;
}
priority_queue<pair<int,pair<int,int> >,vector<pair<int,pair<int,int> > >,less<pair<int,pair<int,int> > > > q;
void bfs(){
	q.push(make_pair(dep[1]-now[1],make_pair(now[1],1)));
	while(!q.empty()){
		int x=q.top().second.second,no=q.top().first,st=q.top().second.first;q.pop();
		int flag=0;
		for(int y,i=head[x];i;i=edge[i][nxt]){
			y=edge[i][ver];
			if(y==f[x]) continue;
			if(dep[y]-st==no&&!flag){
				flag=1;
				q.push(make_pair(no,make_pair(st,y)));
			}else{
				q.push(make_pair(dep[y]-now[x],make_pair(now[x],y)));
			}
		}
		if(!flag){
			hehe+=no;
			ans[++cnt]=hehe;
		}
	}
}
//int work(int x,int fa,int now){
//	int uesd=1,flag=0;
//	for(int y,i=head[x];i;i=edge[i][nxt]){
//		y=edge[i][ver];
//		used+=work(y,x,now+used);
//		++flag;
//	}
//	if(!flag) ans[++cnt]=now+1;
//	return used;
//}
int main(){
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	n=read();
	for(int x,y,i=1;i<n;++i){
		x=read(),y=read();
		add(x,y);
		add(y,x);
	}
	find(1,0,1);
	dfs(1,0);
	bfs();
	cout<<sum+1<<endl;
	for(int i=1;i<=cnt;++i) printf("%d\n",ans[i]);
	return 0;
}
