#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
#define rg register
inline int read(){
	rg char ch=getchar();
	rg int x=0,f=0;
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
double L,id;
int n,m;
double p[330],d[330],ans;
int main(){
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	srand(time(0));
	L=read();
	m=read();
	for(int i=1;i<=m;++i) p[i]=read();
	n=read();
	for(int i=2;i<=n;++i) d[i]=read();
	L-=d[n];
	
	if(L<=200){
		
		for(double i=0;i<=L;i+=0.1){
			double sum=0;
			for(int j=1;j<=m;++j){
				double now=1e9;
//				int pre=lower_bound(d+1,d+1+n,p[j]-i)-d-1;
//				int nxt=upper_bound(d+1,d+1+n,p[j]-i)-d-1;
//				cout<<i<<" "<<p[j]-i<<" "<<pre<<" "<<nxt<<endl;
//				now=min(abs(d[pre]+i-p[j]),abs(d[nxt]+i-p[j]));
				for(int k=1;k<=n;++k){
					now=min(now,abs(d[k]+i-p[j]));
				}
				sum+=now;
			}
			if(sum>ans){
				id=i;
				ans=sum;
			}
		}
	//	cout<<id<<" "<<ans<<endl;
		printf("%.1lf %.1lf",id,ans);
		return 0;
	}else{
		rg int T=max(5000000/(n*m*80)+1,2);
		rg double haha=0,lsz,lsy,sum,now,to,pi=0.967,st,ll;
		rg int k,j;
//		cout<<T<<endl;
		while(T--){
			st=L/2+rand()%((int)(L/2)+1);
			ll=L/2;
			sum=0;
			for(j=1;j<=m;++j){
				now=1e9;
				for(k=1;k<=n;++k){
					now=min(now,abs(d[k]+ll-p[j]));
				}
				sum+=now;
			}
			to=sum;
			while(st>0.01){
				st*=pi;
//				cout<<st<<endl;
				double left=ll-st,right=ll+st;
				lsz=lsy=0;
				if(left>=0){
					sum=0;
					for(j=1;j<=m;++j){
						now=1e9;
//						int pre=lower_bound(d+1,d+1+n,p[j]-left)-d;
//						int nxt=upper_bound(d+1,d+1+n,p[j]-left)-d;
//						now=min(abs(d[pre]+left-p[j]),abs(d[nxt]+left-p[j]));
						for(k=1;k<=n;++k){
							now=min(now,abs(d[k]+left-p[j]));
						}
						sum+=now;
					}
					lsz=sum;
				}
				if(right<=L){
					sum=0;
					for(j=1;j<=m;++j){
						now=1e9;
						for(k=1;k<=n;++k){
							now=min(now,abs(d[k]+right-p[j]));
						}
						sum+=now;
					}
					lsy=sum;
				}
//				cout<<lsy<<" "<<lsz<<" "<<to<<endl;
				if(lsy>lsz&&lsy>to){
					to=lsy;
					ll=right;
				}
				if(lsz>to){
					to=lsz;
					ll=left;
				}
			}
//			cout<<now<<" "<<ll<<endl;
			if(to>haha){
				haha=to;
				id=ll;
			}
//			haha=max(haha,now);
		}
		sum=0;
//		cout<<id<<endl;
//		id=270029.1;
//		printf("%lf\n",id);
//		cout<<id<<endl;
		id=((long long)(id*10))/10.0;
//		cout<<id<<endl;
//		printf("%lf\n",id);
		for(j=1;j<=m;++j){
			now=1e9;
			for(k=1;k<=n;++k){
				now=min(now,abs(d[k]+id-p[j]));
			}
			sum+=now;
		}
		haha=sum;
		printf("%.1lf %.1lf",id,haha);
		return 0;
	}
}
