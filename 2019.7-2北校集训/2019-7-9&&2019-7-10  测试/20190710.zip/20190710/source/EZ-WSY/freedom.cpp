#include<bits/stdc++.h>
using namespace std;
const int maxn=1000100;
struct node{
    int nxt,to;
}e[maxn<<1];
int tot,head[maxn],n,du[maxn];
int f[maxn];
int dep[maxn];
inline void add(int x,int y){
    e[++tot].to=y;
    e[tot].nxt=head[x];head[x]=tot;
}
inline void dfs(int now,int fa){
    dep[now]=dep[fa]+1;
    f[now]=fa;
    for(int i=head[now];i;i=e[i].nxt){
        int to=e[i].to;
        if(to==fa) continue;
        dfs(to,now);
    }
}
queue<int> q;
inline void bfs(){
    while(q.size()){
        int now=q.front();
        q.pop();
        for(int i=head[now];i;i=e[i].nxt){
            int to=e[i].to;
            if(dep[to]==1||to==f[now]) continue;
            dep[to]=dep[now]+1;
            q.push(to);
        }
    }
}
int main()
{
    freopen("freedom.in","r",stdin);
    freopen("freedom.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<n;i++){
        int u,v;
        scanf("%d%d",&u,&v);
        add(u,v);add(v,u);
        du[u]++;du[v]++;
    }
    int ans=0;
    for(int i=1;i<=n;i++)
        if(du[i]==1) ans++;
    printf("%d\n",ans);
    dfs(1,0);
    int res=0,maxx=-1;
    while(ans--){
        maxx=-1;
        int j;
        for(int i=1;i<=n;i++)
            if(maxx<dep[i]) 
                j=i,maxx=dep[i];
        while(j!=1){
            q.push(j);
            dep[j]=1;
            j=f[j];
        }
        bfs();
        res+=maxx-1;
        printf("%d\n",res);
    }
    // system("pause");
    return 0;
}