#include<bits/stdc++.h>
using namespace std;
const int maxn=310;
int n,m;
double L,p[maxn],d[maxn];
double ans1,ans2;
int main()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	scanf("%lf%d",&L,&m);
	for(int i=1;i<=m;i++)
		scanf("%lf",&p[i]);
	scanf("%d",&n);
	for(int i=1;i<n;i++)
		scanf("%lf",&d[i+1]);
	for(double s=0;s<=L-d[n];s+=0.1)
	{
		double sum=0;
		for(int j=1;j<=m;j++)
		{
			int l=1,r=n;
			while(r-l>5)
			{
				int mid1=l+(r-l)/3,mid2=l+(r-l)/3*2;
				double a1=abs(d[mid1]+s-p[j]);
				double a2=abs(d[mid2]+s-p[j]);
				if(a1<=a2) r=mid2;
				else l=mid1;
			}
			int pos;
			double ans=9999999;
			for(int k=l;k<=r;k++)
			{
				double ss=abs(d[k]+s-p[j]);
				if(ss<ans)
					ans=ss,pos=k;
			}
			sum+=abs(d[pos]+s-p[j]);
		}
		if(sum>ans1) ans1=sum,ans2=s;
	}
	printf("%.1lf %.1lf\n",ans2,ans1);
	// system("pause");
	return 0;
}