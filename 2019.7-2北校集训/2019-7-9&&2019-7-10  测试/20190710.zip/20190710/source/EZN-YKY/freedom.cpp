#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <queue>
#include <algorithm>
using namespace std;
const int N=1000010;
int n,ans,tot,sum,cnt;
struct pp{
	int v,nxt;
}edge[N*2];
int head[N*2],a[N];
bool vis[N];
bool cmp(int x,int y){
	return x>y;
}
inline void add(int u,int v){
	edge[++tot].nxt=head[u],head[u]=tot;
	edge[tot].v=v;
}
inline int dfs(int u,int f,int sum){
	vis[u]=1;
	for(int i=head[u];i;i=edge[i].nxt){
		int v=edge[i].v;
		if(v==f)continue;
		if(vis[v])continue;
		else{
			sum+=dfs(v,u,1);
			break;
		}
	}
	return sum;
}
inline void Dfs(int u,int f){
	for(int i=head[u];i;i=edge[i].nxt){
		int v=edge[i].v;
		if(v==f)continue;
		if(!vis[v]){
			a[++cnt]=dfs(v,u,1);
		}
		Dfs(v,u);
	}
}
int main(){
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	cin>>n;int x,y;
	for(int i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	Dfs(1,0);
	cout<<cnt<<endl;
	sort(a+1,a+1+cnt,cmp);
	int ans=0;
	for(int i=1;i<=cnt;i++){
		ans+=a[i];
		printf("%d\n",ans);
	}
	return 0;
}
/*

7
1 2
1 3
2 4
2 5
3 6
3 7

*/
