#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <queue>
#include <algorithm>
using namespace std;
const int N=1000010;
int n,m,tot,ans;
struct pp{
	int x,y;
}e[N];
struct ppp{
	int u,v,nxt;
}edge[N];
int fa[N],head[N],pre[N],a[N],siz[N];
inline int find(int x){
	return x==fa[x]?x:fa[x]=find(fa[x]);
}
inline void add(int u,int v){
	edge[++tot].nxt=head[u],head[u]=tot;
	edge[tot].v=v;
}
bool vis[N];
inline int dfs(int u){
	if(vis[u])return 0;
	vis[u]=1;
	for(int i=head[u];i;i=edge[i].nxt){
		int v=edge[i].v;
		if((!pre[v])||dfs(pre[v])){
			pre[v]=u;
			return 1;
		}
	}
	return 0;
}
int main(){
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&e[i].x,&e[i].y);
	}
	for(int i=1;i<=n;i++){
		fa[i]=i;siz[i]=1;
	}
	for(int j=1;j<=m;j++){
		int x=e[j].x,y=e[j].y;
		if(find(x)!=find(y)){
			ans=0;
			add(x,y);add(y,x);
			int cnt=0;
			for(int i=head[x];i;i=edge[i].nxt){
				int v=edge[i].v;
				a[++cnt]=v;
			}
			int now=find(a[1]);
			for(int i=2;i<=cnt;i++){
				fa[find(a[i])]=now;
				siz[now]++;
			} 
			cnt=0;
			for(int i=head[y];i;i=edge[i].nxt){
				int v=edge[i].v;
				a[++cnt]=v;
			}
			int now2=find(a[1]);
			for(int i=2;i<=cnt;i++){
				fa[find(a[i])]=now;
				siz[now]++;
			}
			for(int i=1;i<=n;i++){
				ans=max(ans,siz[i]);
			}
			ans=max(ans,n-ans);
			printf("%d %d\n",1,ans);
		}
		else{
			
			printf("%d %d\n",0,ans);
		}
	}
	
	return 0;
}
