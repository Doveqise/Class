#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <queue>
#include <algorithm>
using namespace std;
const int N=1000010;
int l,n,m;
int a[N];
double d[N];
double ans1,ans2;
inline double find(double s,int j){
	double maxx=100000009;
	for(int i=1;i<=n;i++){
		if((double)fabs(d[i]+s-(double)a[j])<maxx)maxx=(double)fabs(d[i]+s-(double)a[j]);
	}
	return maxx;
}
int main(){
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	cin>>l>>m;
	for(int i=1;i<=m;i++){
		scanf("%d",&a[i]);
	}
	cin>>n;
	d[1]=0;
	for(int i=2;i<=n;i++){
		cin>>d[i];
	}
	for(double i=0.0;i<=(double)l-d[n];i+=0.1){
		double now=0;
		for(int j=1;j<=m;j++){
			now+=find(i,j);
		}
		if(now>ans2){
			ans2=now;
			ans1=i;
		}
		//if(i==0.5)cout<<now<<endl;
	}
	printf("%.1lf %.1lf",ans1,ans2);
	return 0;
}

/*
4 5
0 1 2 3 4 
4
1 2 3

*/
