#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
const int N=305;
const double eps=1e-1;
const double INF=1<<30;
double l;
int m,n;
double ans,s;
double L,R;
double P[N],D[N];
inline int read()
{
	register char ch=getchar();register int f=1,x=0;
	while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
inline void work(double x)
{
	double res=0;
	static double tmp[N];
	tmp[0]=-INF;
	for(int i=1;i<=n;i++)tmp[i]=D[i]+x;
	for(int i=1;i<=m;i++)
	{
		int pos=lower_bound(tmp+1,tmp+n+1,P[i])-tmp;
		res+=min(fabs(tmp[pos]-P[i]),fabs(tmp[pos-1]-P[i]));
	}
	if(res>ans)
	{
		ans=res;
		s=x;
	}
}
int main()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	srand(712);
	l=read();
	m=read();
	for(int i=1;i<=m;i++)P[i]=read();
	n=read();
	for(int i=2;i<=n;i++)D[i]=read();
	R=l-D[n];L=0.0;

	for(double i=L;i<=R;i+=eps)
	{
		work(i);
	}
	printf("%.1f %.1f",s,ans);
}
/*
4
5
0 1 2 3 4
4
1 2 3
*/
