#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
#include<queue>
using namespace std;
const int N=5e5+7;
int n,m,sum1=0,sum2=0,ans;
bool falg=false;
bool cnt[N];
bool vis[N];
vector<int>e[N];
inline int read()
{
	register char ch=getchar();register int f=1,x=0;
	while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
inline void walk(int x,bool chk)
{
	vis[x]=true;
	sum1+=chk;
	sum2+=(!chk);
	for(register int i=0;i<e[x].size();i++)
	{
		int y=e[x][i];
		if(!vis[y])walk(y,chk^1);
	}
}
inline void dfs(int u,int fa)
{
	if(cnt[u])
	{
		falg=true;
		return;
	}
	cnt[u]=true;
	for(register int i=0;i<e[u].size();i++)
	{
		int v=e[u][i];
		if(v==fa)continue;
		dfs(v,u);
	}
}

int main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	n=read();m=read();
	for(register int i=1;i<=m;i++)
	{
		ans=0;
		register int u=read(),v=read();
		e[u].push_back(v);
		e[v].push_back(u);
		falg=false;
		dfs(u,u);
		cout<<!falg<<" ";
		if(falg)
		{
			e[u].pop_back();
			e[v].pop_back();
		}
		for(register int i=1;i<=n;i++)
		{
			if(!vis[i])
			{
				sum1=sum2=0;
				walk(i,0);
				ans+=min(sum1,sum2);
			}
		}
		memset(cnt,0,sizeof(cnt));
		memset(vis,0,sizeof(vis));
		printf("%d\n",n-ans);
	}
}
