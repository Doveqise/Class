#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<queue>
#define re register
using namespace std;
const int N=1e6+7;
int n;
int son[N],fa[N],dep[N],len[N],dis[N];
vector<int>e[N];
priority_queue<int>ans;
inline void dfs1(int x,int father,int deep)
{
	fa[x]=father;dep[x]=deep;len[x]=deep;
	for(int i=0;i<e[x].size();i++)
	{
		int y=e[x][i];
		if(y==father)continue;
		dfs1(y,x,deep+1);
		if(len[y]>len[x])
		{
			len[x]=len[y];
			son[x]=y;
		}
	}
}
inline void dfs2(int x,int y,int topp)
{
	if(topp==x)dis[x]=1;
	else dis[x]=dis[y]+1;
	if(!son[x])
	{
		ans.push(dis[x]);
		return;
	}
	dfs2(son[x],x,topp);
	for(int i=0;i<e[x].size();i++)
	{
		int y=e[x][i];
		if(y==fa[x]||y==son[x])continue;
		dfs2(y,x,y);
	}
}
inline int read()
{
	re char ch=getchar();re int f=1,x=0;
	while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	n=read();
	for(re int i=1;i<n;i++)
	{
		re int u=read(),v=read();
		e[u].push_back(v);
		e[v].push_back(u);
	}
	dfs1(1,0,1);
	dfs2(1,0,1);
	int u=ans.top();ans.pop();u--;ans.push(u);
	cout<<ans.size()<<endl;
	int sum=0;
	while(!ans.empty())
	{
		sum+=ans.top();
		cout<<sum<<endl;
		ans.pop();
	}
	return 0;
}
/*
6
1 2
1 3
1 4
1 5
5 6
*/
