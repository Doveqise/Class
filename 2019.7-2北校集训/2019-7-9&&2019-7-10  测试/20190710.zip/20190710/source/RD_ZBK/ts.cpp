#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=5e5+50;
int n,m,f[N*2],sz1[N*2],sz2[N*2],ans;
int find(int x){return f[x]==x?x:f[x]=find(f[x]);}
int main(){
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n*2;i++)f[i]=i;
	for(int i=1;i<=n;i++)sz1[i]=1;
	for(int i=n+1;i<=n*2;i++)sz2[i]=1;
	for(int i=1,x,y;i<=m;i++){
		scanf("%d%d",&x,&y);
		int fx=find(x),fy=find(y),fx1=find(x+n),fy1=find(y+n);
		if(fx==fy)printf("0 ");
		else{
			printf("1 ");
			int n1=sz1[fx]+sz1[fy1],n2=sz2[fx]+sz2[fy1];
			int la=min(sz1[fx],sz2[fx])+min(sz1[fy1],sz2[fy1]);
			ans-=la;ans+=min(n1,n2);
			sz1[fy1]=n1,sz2[fy1]=n2;
			f[fx]=fy1;f[fy]=fx1;
			sz1[fx1]+=sz1[fy],sz2[fx1]+=sz2[fy];
		}
		printf("%d\n",n-ans);
	}
	return 0;
}
