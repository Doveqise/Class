#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=1e6+50;
int n,ver[N*2],nxt[N*2],head[N],tot,son[N],h[N],tp[N],d[N],du[N],m,ans[N];
void add(int x,int y){
	ver[++tot]=y;nxt[tot]=head[x];head[x]=tot;du[y]++;
}
void dfs1(int x,int fa){
	d[x]=d[fa]+1;
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==fa)continue;
		dfs1(y,x);
		if(h[y]>h[son[x]])son[x]=y;
	}
	h[x]=h[son[x]]+1;
}
void dfs2(int x,int fa){
	if(son[x]){
		tp[son[x]]=tp[x];
		dfs2(son[x],x);
	}
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==fa||y==son[x])continue;
		tp[y]=y;
		dfs2(y,x);
	}
}
int main(){
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	scanf("%d",&n);
	for(int i=1,x,y;i<n;i++){
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	dfs1(1,0);
	tp[1]=1;dfs2(1,0);
	for(int i=1;i<=n;i++)if(du[i]==1&&i!=1)
		ans[++m]=d[i]-d[tp[i]]+1;
	sort(ans+1,ans+m+1);
	ans[m]--;
	printf("%d\n",m);
	for(int i=m;i;i--)ans[i]+=ans[i+1],printf("%d\n",ans[i]);
	return 0;
}
