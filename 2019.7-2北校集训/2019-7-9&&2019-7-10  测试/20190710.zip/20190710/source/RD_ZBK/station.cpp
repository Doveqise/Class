#include<map>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=310;
int l,m,n,p[N],d[N];double mi[N],a[N],ss,ans;
map<double,bool>mp;
void check(double x){
	double ret=0;
	for(int i=1;i<=n;i++)a[i]=d[i]+x;
	int i=1,j=1;
	while(i<=m&&p[i]<=a[j])ret+=a[j]-p[i++];
	for(;i<=m;i++){
		while(j<n&&p[i]>a[j+1])j++;
		if(j==n)ret+=p[i]-a[n];
		else ret+=min(p[i]-a[j],a[j+1]-p[i]);
	}
	if(ret>ans)ans=ret,ss=x;
	else if(ret==ans&&x<ss)ss=x;
}
int main(){
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	scanf("%d%d",&l,&m);
	for(int i=1;i<=m;i++)scanf("%d",&p[i]);
	scanf("%d",&n);
	for(int i=2;i<=n;i++)scanf("%d",&d[i]);
	for(int i=1;i<n;i++)mi[i]=(d[i]+d[i+1])/2.0;
	check(0);check(l-d[n]);mp[0]=1;mp[l-d[n]]=1;
	for(int i=1;i<=m;i++){
		for(int j=1;j<n;j++){
			double len=p[i]-mi[j];
			if(len+d[n]>l||len<0||mp[len])continue;
			check(len);mp[len]=1;
		}
	}
	printf("%.1f %.1f",ss,ans);
	return 0;
}
