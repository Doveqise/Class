#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int N = 500005;
int f[N], tot;
int d[N], s1[N], s2[N];
int read(void) {
	int x = 0;
	char c = getchar();
	while (!isdigit(c)) c = getchar();
	while (isdigit(c)) {
		x = (x << 3) + (x << 1) + c - '0';
		c = getchar();
	}
	return x;
}

int ans;

int get(int x) {
	if (f[x] == x) return x;
	int root = get(f[x]);
	d[x] ^= d[f[x]];
	return f[x] = root;
}

	

int main() {
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	int n = read(), m = read();
	for (int i = 1;i <= n; i++) f[i] = i, s1[i] = 1;
	ans = n;
	for (int i = 1;i <= m; i++) {
		int xx = read(), yy = read();
		int fx = get(xx), fy = get(yy);
		if (fx == fy) {
			if (d[xx] ^ d[yy])
				printf("1 %d\n", ans);
			else printf("0 %d\n", ans);
			continue;
		}
		d[fx] = 1 ^ d[xx];
		f[fx] = fy;
		ans -= max(s1[fx], s2[fx]);
		ans -= max(s2[fy], s1[fy]);
		s1[fy] += s2[fx];
		s2[fy] += s1[fx];
		ans += max(s1[fy], s2[fy]);
		printf("1 %d\n", ans);
	}
	return 0;
}

/*
5 5
1 2
1 3
2 3
4 5
4 1

*/
