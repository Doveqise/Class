#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int N = 105;
float d[N], p[N];
int tot;
struct pos{
	float s;
	int ch;
	bool operator < (const pos &i) const{
		return s < i.s;
	}
}cnt[100000];
int L, n, m;
int main() {
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	double ans = 0;
	scanf ("%d%d", &L, &m);
	for (int i = 1;i <= m; i++) {
		scanf ("%f", p + i);
		ans += p[i];
	}
	scanf ("%d", &n);
	for (int i = 2;i <= n; i++) 
		scanf ("%f", d + i);	
	for (int i = 1;i <= m; i++) {
		cnt[++tot] = (pos) {p[i] - d[n], 2};
		for (int j = 1;j < n; j++) {
			cnt[++tot] = (pos) {p[i] - d[j],2};
			float po = p[i] - (d[j + 1] + d[j]) / 2;
			cnt[++tot] = (pos) {po, -2};
		}
	}
	sort(cnt + 1, cnt + tot + 1);
	int ch = -m;
	float now = p[1] - d[n];
	float real_ans = 0, real_pos;
	if (d[n] < p[0]) {
		real_ans = ans + m * (p[0] - d[n]);
		real_pos = 0;
	}
	for (int i = 1;i <= tot; i++) {
		ans += (cnt[i].s - now) * ch;
		now = cnt[i].s;
		ch += cnt[i].ch;
		if (now > L - d[n]) break;
		if (now >= 0 && ans > real_ans)
			real_ans = ans, real_pos = now;
	}
	printf("%.1f %.1f", real_pos, real_ans);
	return 0;
}

/*
4
5
0 1 2 3 4
4 
1 2 3

*/
