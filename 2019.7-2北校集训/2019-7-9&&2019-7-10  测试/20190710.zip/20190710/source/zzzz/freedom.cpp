#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int N = 1000005;
int h[N], ne[N<<1];
int tot, to[N<<1];
int dis[N];

void add(int x,int y) {
	ne[++tot] = h[x];
	h[x] = tot, to[tot] = y;
}
int read(void) {
	int x = 0;
	char c = getchar();
	while (!isdigit(c)) c = getchar();
	while (isdigit(c)) {
		x = (x << 3) + (x << 1) + c - '0';
		c = getchar();
	}
	return x;
}

int cnt;

int dfs(int x,int fa) {
	int tmp = 0;
	for (int i = h[x]; i; i = ne[i]) {
		int y = to[i];
		if (y == fa) continue;
		int k = dfs(y, x) + 1;
		if (tmp == 0) tmp = k;
		else {
			if (k >= tmp) dis[++cnt] = tmp, tmp = k;
			else dis[++cnt] = k;
		}
	}
	return tmp;
}

int main() {
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	int n = read();
	for (int i = 1;i < n; i++) {
		int x = read(), y = read();
		add(x, y); add(y, x);
	}
	if (n == 1) {
		cout << "0" << endl;
		return 0;
	}
	int ans = dfs(1, 0);
	sort(dis + 1, dis + cnt + 1);
	int tmp = ans;
	printf("%d\n%d\n", cnt + 1, ans);
	for (int i = cnt;i >= 1; i--) {
		tmp += dis[i];
		printf("%d\n", tmp);
	}
	return 0;
}

/*
12
7 12
1 2
1 3
2 11
2 4
2 5
5 8
5 6
5 7
3 10
3 9

*/
