#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
#define N 1000010
int ver[N*2],nxt[N*2],head[N],n,tot,ans1,ans[N],dep[N],cnt,size[N],root[N];
int bz[N][20];
bool v[N];
struct node{
	int deep;
	int id;
}a[N];
void add(int x,int y)
{
	ver[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
void dfs1(int x,int fa)
{
	bz[x][0]=fa;
	for(int i=head[x];i;i=nxt[i])
	{	
		if(ver[i]==fa)continue;
		dep[ver[i]]=dep[x]+1;
		if(x==1)ans1++;
		root[ver[i]]=x;
		dfs1(ver[i],x);	
		size[x]+=size[ver[i]];
	}
}
bool cmp(node g,node h)
{
	return g.deep>h.deep;
}
int LCA(int x,int y)
{
	if(dep[x]>dep[y])swap(x,y);
	for(int i=19;i>=0;i--)
	{
		if(dep[bz[y][i]]>=dep[x])
		y=bz[y][i]; 
	}
	if(x==y)return x;
	for(int i=19;i>=0;i--)
	{
		if(dep[bz[x][i]]!=dep[bz[y][i]])
		x=bz[x][i],y=bz[y][i];	
	} 
	return bz[x][0];
}
int main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	scanf("%d",&n);
	int e,b;
	for(int i=1;i<=n;i++)size[i]=1;
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&e,&b);
		add(e,b);
		add(b,e);
	}
	dfs1(1,0);
	for(int i=1;i<=19;i++)
		for(int j=1;j<=n;j++)
			bz[j][i]=bz[bz[j][i-1]][i-1];
	for(int i=1;i<=n;i++)
	{
		a[i].deep=dep[i];
		a[i].id=i;
	}
	sort(a+1,a+n+1,cmp);
	for(int i=2;i<=n;i++)
	{
		if(a[i].deep!=0&&LCA(a[i].id,a[i-1].id)==1)
		{
		 ans[++cnt]=a[i-1].deep+ans[cnt-1];
		 if(a[i].deep==a[i-1].deep&&size[a[i].id]==1&&size[a[i-1].id]==1)
		  ans[++cnt]=a[i].deep+ans[cnt-1],i++;
		}
	}
	printf("%d\n",ans1);
	for(int i=1;i<=cnt;i++)
		printf("%d\n",ans[i]);
}
