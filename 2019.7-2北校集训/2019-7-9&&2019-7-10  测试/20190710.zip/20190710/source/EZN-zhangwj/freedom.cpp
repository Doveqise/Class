#include<cstdio>
#include<queue>
struct chains
{
	int bot,lenth;
};
bool operator <(const chains &a,const chains &b)
{
	return a.lenth<b.lenth;
}
std::priority_queue<chains> QUE;
int first[1000050],next[2000050],to[2000050],tot=0,father[1000050],maxdepth[1000050],top[1000050],depth[1000050],son[1000050];
int add(int x,int y)
{
	next[++tot]=first[x];
	to[tot]=y;
	first[x]=tot;
	return 0;
}
int dfs(int a,int &mode,int lenth)
{
	register int T,maxson=0;
	T=first[a];
	if(mode==1)
	{
		maxdepth[a]=depth[a];
		while(T)
		{
			if(father[a]==to[T])
			{
				T=next[T];
				continue;
			}
			depth[to[T]]=depth[a]+1;
			father[to[T]]=a;
			dfs(to[T],mode,0);
			if(maxdepth[to[T]]>maxson)
			{
				maxson=maxdepth[to[T]];
				maxdepth[to[T]]=maxson;
				son[a]=to[T];
			}
			T=next[T];
		}
	}
	if(mode==2)
	{
		if(!top[a])
		{
			top[a]=a;
			lenth=1;
		}
		if(son[a])
		{
			lenth++;
			top[son[a]]=top[a];
			dfs(son[a],mode,lenth);
		}
		else
		{
			chains t;
			t.bot=a;
			if(top[a]==1)
			{
				lenth--;
			}
			t.lenth=lenth;
			QUE.push(t);
		}
		while(T)
		{
			if(to[T]==father[a]||to[T]==son[a])
			{
				T=next[T];
				continue;
			}
			dfs(to[T],mode,0);
			T=next[T];
		}
	}
	return 0;
}
int main()
{
	int a,b;
	register int i,j,x,y,mode=1,ans=0;
	register chains t;
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	scanf("%d",&a);
	for(i=1;i<a;i++)
	{
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	depth[1]=1;
	father[1]=1;
	dfs(1,mode,0);
	mode=2;
	dfs(1,mode,0);
	printf("%d\n",QUE.size());
	while(!QUE.empty())
	{
		t=QUE.top();
		QUE.pop();
/*		printf("T.LENTH=%d\n",t.lenth);
		int pos=t.bot;
		while(pos!=top[pos])
		{
			printf("%d ",pos);
			pos=father[pos];
		}
		printf("%d\n",pos);*/
		ans+=t.lenth;
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
11
1 2 
2 3
2 4
4 5 
5 6
5 7
1 8
8 9 
8 10
10 11
*/

