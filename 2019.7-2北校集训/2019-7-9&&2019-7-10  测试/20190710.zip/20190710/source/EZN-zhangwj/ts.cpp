#include<cstdio>
int tag[500050],father[500050],size[500050],joenum[500050],lastfather[500050];
const int joetag=1,trovskytag=2,commtag[2]={1,2};
int totaljoenum=0;
int swap(int &a,int &b)
{
	a^=b;
	b^=a;
	a^=b;
	return 0;
}
int find(int a)
{
	if(father[a]==a)
	{
		return a;
	}
	else
	{
		father[a]=find(father[a]);
		if(lastfather[a]!=father[a])
		{
			tag[a]=commtag[(tag[father[a]]-tag[lastfather[a]]+2)%2];
			lastfather[a]=father[a];
		}
		return father[a];
	}
}
int merge(int a,int b)
{
	int x=find(a),y=find(b);
	if(size[x]<size[y])
	{
		swap(x,y);
	}
	if(!tag[x]&&!tag[y])
	{
		tag[x]=joetag;
		tag[y]=trovskytag;
		joenum[y]=0;
		father[y]=x;
		lastfather[y]=x;
		size[x]+=size[y];
		totaljoenum--;
	}
	else
	{
		if(tag[x]&&tag[y])
		{
			if(tag[x]==tag[y])
			{
				if(joenum[x]+size[y]-joenum[y]>joenum[y]+size[x]-joenum[x])
				{
					tag[y]=3-tag[y];
					totaljoenum-=joenum[y];
					joenum[x]=joenum[x]+size[y]-joenum[y];
					totaljoenum+=size[y]-joenum[y];
					size[x]+=size[y];
					father[y]=x;	
					lastfather[y]=x;
					if(size[x]-joenum[x]>joenum[x])
					{
						tag[x]=3-tag[x];
						totaljoenum-=joenum[x];
						joenum[x]=size[x]-joenum[x];
						totaljoenum+=joenum[x];
					}
				}
				else
				{
					tag[x]=3-tag[x];
					totaljoenum-=joenum[x];
					joenum[y]=joenum[y]+size[x]-joenum[x];
					totaljoenum+=size[x]-joenum[x];
					size[y]+=size[x];
					father[x]=y;
					lastfather[x]=y;
					if(size[y]-joenum[y]>joenum[y])
					{
						tag[y]=3-tag[y];
						totaljoenum-=joenum[y];
						joenum[y]=size[y]-joenum[y];
						totaljoenum+=joenum[y];
					}
				}
			}
			else
			{
				size[x]+=size[y];
				joenum[x]+=joenum[y];
				father[y]=x;
				lastfather[y]=x;
				if(size[x]-joenum[x]>joenum[x])
				{
					tag[x]=3-tag[x];
					totaljoenum-=joenum[x];
					joenum[x]=size[x]-joenum[x];
					totaljoenum+=joenum[x];
				}
			}
		}
		else
		{
			if(tag[x])
			{
				tag[y]=3-tag[a];
				father[y]=x;
				lastfather[y]=x;
				size[x]+=size[y];
				if(tag[y]==joetag)
				{
					joenum[x]++;
				}
				else
				{
					totaljoenum--;
					joenum[y]=0;
				}
				if(size[x]-joenum[x]>joenum[x])
				{
					tag[x]=3-tag[x];
					totaljoenum-=joenum[x];
					joenum[x]=size[x]-joenum[x];
					totaljoenum+=joenum[x];
				}
			}
			else
			{
				tag[x]=3-tag[b];
				father[x]=y;
				lastfather[x]=y;
				size[y]+=size[x];
				if(tag[x]==joetag)
				{
					joenum[y]++;
				}
				else
				{
					totaljoenum--;
					joenum[x]=0;
				}
				if(size[y]-joenum[y]>joenum[y])
				{
					tag[y]=3-tag[y];
					totaljoenum-=joenum[y];
					joenum[y]=size[y]-joenum[y];
					totaljoenum+=joenum[y];
				}
			}
		}
	}
	return 0;
}
int main()
{
	int a,b;
	register int i,j,x,y;
	bool truth=0;
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	scanf("%d%d",&a,&b);
	totaljoenum=a;
	for(i=1;i<=a;i++)
	{
		father[i]=i;
		size[i]=1;
		joenum[i]=1;
		lastfather[i]=i;
	}
	for(i=1;i<=b;i++)
	{
		truth=0;
		scanf("%d%d",&x,&y);
		if(find(x)==find(y))
		{
			if(tag[x]==tag[y])
			{
				truth=1;
			}
		}
		else
		{
			merge(x,y);
		}
		if(truth)
		{
			printf("0 %d\n",totaljoenum);
		}
		else
		{
			printf("1 %d\n",totaljoenum);
		}
	/*	for(j=1;j<=a;j++)
		{
			printf("LASTFATHER[%d]=%d\n",j,lastfather[j]);
			printf("FATHER[%d]=%d JOENUM[%d]=%d TAG[%d]=%d SIZE[%d]=%d\n",j,father[j],j,joenum[j],j,tag[j],j,size[j]);
		}*/
	}
	fclose(stdin);
	fclose(stdout);
}
/*
7 7
1 2
2 3
3 4
4 5
3 6
5 7
6 7
*/
