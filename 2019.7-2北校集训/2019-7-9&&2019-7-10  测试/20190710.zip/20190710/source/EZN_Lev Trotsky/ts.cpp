#include <iostream>
#include <algorithm>
#include <set>
#include <cstdio>
using namespace std;

int n[500000], tuo[500000];
set <int> tl, sdl;
set <int> tl0, sdl0;

int main()
{
	freopen("ts.in", "r", stdin);
	freopen("ts.out", "w", stdout);
	int n, m, ans;
	cin >> n >> m;
	{
		int u, v;
		cin >> u >> v;
		ans = n - 1;
		cout << 1 << ' ' << ans << '\n';
		tl.insert(u);
		sdl.insert(v);
		sdl0.insert(v);
		tl0.insert(u);
	}
	for (int i = 1; i < m; ++i)
	{
		int u, v;
		cin >> u >> v;
		if((tl.find(u) != tl.end() && tl.find(v) != tl.end()) || (sdl.find(u) != sdl.end() && sdl.find(v) != sdl.end()))
		{
			if((tl0.find(u) != tl0.end() && tl0.find(v) != tl0.end()) || (sdl0.find(u) != sdl0.end() && sdl0.find(v) != sdl0.end()))
			{
  		        cout << 0 << ' ' << ans << '\n';	
			}	
			else
			{
				cout << 1 << ' ' << ans << '\n';
			}
		}
		else
		{
			cout << 1 << ' ';
			if(tl.find(u) != tl.end())
			{
				cout << ans << '\n';
				sdl.insert(v);
				sdl0.insert(v);
			}
			else if(tl.find(v) != tl.end())
			{
				cout << ans << '\n';
				sdl.insert(u);
				sdl0.insert(u);
			}
			else if(sdl.find(u) != sdl.end())
			{
				cout << ans << '\n';
				tl.insert(v);
				tl0.insert(v);
			}
			else if(sdl.find(v) != sdl.end())
			{
				cout << ans << '\n';
				tl.insert(u);
				tl0.insert(u);
			}
			else
			{
				cout << --ans << '\n';
				sdl.insert(u);
				tl.insert(v);
				sdl0.insert(v);
				tl0.insert(u);
			}
		}
	}
	return 0;
}
