#include <algorithm>
#include <iostream>
#include <cstdio>
#include <cmath>

using namespace std;

long long P[301], D[301], N, M, L;
const double eps = 0.05;
double s0, Cnt;

double calc(double s)
{
	double last = 1e9, ans = 0;
	D[0] = s;
	for(int i = 0; i < M; ++i)
	{
		last = 1e9;
		for (int j = 0; last > abs(D[j] + s - P[i]) && j < N ; ++j)
		{
			last = abs(D[j] + s - P[i]);
		} 
		ans = max(last, ans);
	}
	return ans;
}

void work(double s, double last, double ans)
{
	double t = abs(last - s) / 2, c;
	if(t > eps)
	{	
		if((c = calc(s - t)) > ans)
		{
			if(Cnt < c)
			{
				Cnt = c;
				s0 = s - t;
			}
			work (last , s - t, c);
		}
		if((c = calc(s + t)) > ans)
		{
			if(Cnt < c)
			{
				Cnt = c;
				s0 = s + t;
			}
			work (last , s + t, c);	
		}
	}	
}

int main()
{
	freopen("station.in", "r", stdin);
	freopen("station.out", "w", stdout);

	cin >> L >> M;
	for (int i = 0; i < M; ++i)
	{
		cin >> P[i];
	}
	cin >> N;
	for (int i = 1; i < N; ++i)
	{
		cin >> D[i];
	}
	double s = L / 2, ans = calc(s);
	//cout  << s << '\n' << (long long)ans;
	work(s, 0, ans);
	printf("%.1f %.1f", s0, Cnt);
	return 0;
}
