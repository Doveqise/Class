#include <iostream>
#include <cstdio>
#include <algorithm>
using namesapce std;

int main()
{
	freopen("freedom.in", "r", stdin);
	freopen("freedom.out", "w", stdout);
	
	retrun 0;
}
