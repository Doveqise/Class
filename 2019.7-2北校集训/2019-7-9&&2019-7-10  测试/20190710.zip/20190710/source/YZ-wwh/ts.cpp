#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<queue>
using namespace std;
const int N=5e5+10;
int fa[N],n,m,cap,dis[N],vis[N],out[N];
int read(){
	int x=0,f=1; char ch;
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void write(int x){
	if(x<0) x=-x,putchar('-');
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
int find(int x){
	if(x!=fa[x]){
		int tmp=fa[x];
		fa[x]=find(fa[x]);
		dis[x]=(dis[tmp]+1)%2;
		//cout<<"!!"<<dis[2]<<endl;
		return fa[x];
	}
	else return x;
}
int main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	n=read(); m=read();
	for(int i=1;i<=n;++i) fa[i]=i;cap=n;
	for(int i=1;i<=m;++i){
		int u,v;
		u=read(); v=read();
		if(u==v){
			putchar('0'); putchar(' '); write(cap); putchar('\n');
			continue;
		}
		int a,b;
		a=find(u); b=find(v);
		if(a!=b){
			if((!vis[u]||!vis[v])&&(!out[u]&&!out[v])) --cap;
			out[u]++;
			fa[b]=a;
			cap=max(cap,n-cap);
			putchar('1'); putchar(' '); write(cap); putchar('\n');
			vis[u]=vis[v]=1;
		}
		if(a==b){
			//cout<<1111<<endl;
			if(((dis[v]-dis[u]+2+1)%2)!=0){
				putchar('0'); putchar(' '); write(cap); putchar('\n');
			}
			else{
				putchar('1'); putchar(' '); write(cap); putchar('\n');
			}
		}
	}
	//cout<<dis[2]<<endl;
	fclose(stdin); fclose(stdout);
	return 0;
}
