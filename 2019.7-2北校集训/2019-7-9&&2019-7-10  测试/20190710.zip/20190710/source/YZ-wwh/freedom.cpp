#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<queue>
using namespace std;
const int N=50005;
struct node{
	int pos;
	int dis;
}a[N];
int nxt[N],head[N],to[N],w[N],vis[N],d[N],m,n,flag,cnt,dis[N],tot,res,day;
int read(){
	int x=0,f=1; char ch;
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void write(int x){
	if(x<0) x=-x,putchar('-');
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
bool cmp(node a,node b){
	return a.dis>b.dis;
	return a.pos<b.pos;
}
void add(int u,int v){
	nxt[++cnt]=head[u];
	to[cnt]=v;
	head[u]=cnt;
}
void dfs(int u){
	for(int i=head[u];i;i=nxt[i]){
		int v=to[cnt]; if(vis[v]) return;
		vis[v]=1;
		dfs(v);
		dis[u]=dis[v]+w[u];
		if(flag) w[u]=0;
		if(v==1){ flag=1; return;}
	}
}
int main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	n=read();
	for(int i=2;i<=n;++i) w[i]=1;
	if(n==2){ cout<<1<<" "<<1<<endl; return 0;}
	for(int i=1;i<n;++i){
		int u,v;
		u=read(); v=read();
		add(u,v);
		add(v,u);
		d[u]++; d[v]++;
	}
	for(int i=1;i<=n;++i){
		if(d[i]==1) a[++day].pos=i;
	}
	cout<<day<<endl;
	for(int j=1;j<=day;++j){
		for(int i=1;i<=day;++i){
			memset(dis,0,sizeof(dis));
			memset(vis,0,sizeof(vis));
			flag=0;
			dfs(a[i].pos);
			a[i].dis=dis[a[i].pos];
			sort(a+1,a+day+1,cmp);
		}
		cout<<res+a[1].dis<<endl;
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
