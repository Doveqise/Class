#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<cmath>
#include<vector>
#include<windows.h>
#define ll long long
using namespace std;
int m,n;
double ans,p[305],d[305],l,aa;
double check(double s)
{
	double ansl=0;
	for(int i=1;i<=m;i++)
	{
		int u=lower_bound(d+1,d+n+1,p[i]-s)-d;
		double ul=999999;
		if(u!=1)ul=abs(p[i]-d[u-1]-s);
		if(u!=n+1)ul=min(ul,abs(d[u]-p[i]+s));
		ansl+=ul;
	}
	return ansl;
}
void sa()
{
	double heat=10000,down=0.95,now=ans;
	while(heat>0.01)
	{
		double nowl;
		if(rand()%2)nowl=(now+((rand()*((int)heat+1))%((int)l))*heat);
		else nowl=(now-((rand()*((int)heat+1))%((int)l))*heat);
		if(nowl>l-d[n])nowl=l-d[n];
		if(nowl<0)nowl=0;
		double ansl=check(nowl);
		if(ansl>aa)now=nowl,ans=nowl,aa=ansl;
		heat*=down;
	}
}
int main()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	scanf("%lf%d",&l,&m);
	for(int i=1;i<=m;i++)scanf("%lf",&p[i]);
	scanf("%d",&n);
	d[1]=0;
	for(int i=2;i<=n;i++)scanf("%lf",&d[i]);
	ans=(l-d[n])/2;
	for(int i=1;i<=100;i++)sa();
	printf("%.1lf %.1lf",ans,check(ans));
	return 0;
}
