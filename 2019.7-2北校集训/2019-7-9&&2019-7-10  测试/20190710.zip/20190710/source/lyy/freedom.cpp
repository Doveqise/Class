#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<cmath>
#include<vector>
#define ll long long
using namespace std;
const int maxn=2000005;
ll n,m,x,y,head[maxn],nxt[maxn],to[maxn],tot,dep[maxn];
ll son[maxn],top[maxn],siz[maxn],ans[maxn],num[maxn],cnt;
ll ansl;
ll now;
vector<ll>p[1000005];
bool cmp(ll a,ll b)
{
	return a>b;
}
void add(ll x,ll y)
{
	to[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
void dfs(ll x,ll fa,ll deep)
{
	dep[x]=deep;
	int y=0;
	for(int i=head[x];i;i=nxt[i])
	{
		ll g=to[i];
		if(g==fa)continue;
		dfs(g,x,deep+1);
		siz[x]+=siz[g];
		if(siz[g]>y)
		{
			y=siz[g];son[x]=g;
		}
	}
	siz[x]++;
}
void dfs2(ll x,ll tp,ll fa,ll l)
{
	top[x]=tp;
	if(!son[x])
	{
		ans[x]=l;
		if(tp==1)ans[x]--;
		return;
	}
	dfs2(son[x],tp,x,l+1);
	for(int i=head[x];i;i=nxt[i])
	{
		ll g=to[i];
		if(g==fa||g==son[x])continue;
		dfs2(g,g,x,1);
	}
}
int main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	cin>>n;
	for(int i=1;i<n;i++)
	{
		cin>>x>>y;
		add(x,y);add(y,x);
	}
	dfs(1,0,1);
	dfs2(1,1,0,1);
	for(int i=1;i<=n;i++)p[ans[i]].push_back(i);
	for(int i=1000000;i>=1;i--)
	{
		int nw=p[i].size();
		for(int j=0;j<nw;j++)num[++ansl]=i;
	}
    cout<<ansl<<endl;
    for(int i=1;i<=ansl;i++)
    {
    	now+=num[i];
    	cout<<now<<endl;
    }
	return 0;
}
