#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<cmath>
#include<vector>
#define ll long long
using namespace std;
int n,m,x,y,f[1000005],ans,siz[1000005],about,first,fl[1000005];
bool p[1000005];
int find(int x)
{
	if(f[x]==x)return x;
	return f[x]=find(f[x]);
}
int main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n*2;i++)f[i]=i;
	for(int i=1;i<=m;i++)
	{
		cin>>x>>y;
		ll fx=find(x),fy=find(y),fxx=find(x+n),fyy=find(y+n);
		if(fx==fy||fyy==fxx)
		{
		cout<<0<<" "<<ans<<endl;
	}
		else
		{
			first=x;
			if(!p[x])p[x]=1,about++;
			if(!p[y])p[y]=1,about++;
			cout<<1<<" ";
			f[fyy]=fx;f[fxx]=fy;
			if(fl[fx])f[find(fl[fx])]=fy;
			else fl[fx]=fy;
			if(fl[fy])f[find(fl[fy])]=fx;
			else fl[fy]=fx;
			ll now=0;
			for(int j=1;j<=n;j++)
			{
				if(p[j]&&find(j+n)!=find(x))now++;
			}
			ans=max(now+n-about,n-now);
			cout<<ans<<endl;
		}
	}
	return 0;
}
