#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<ctime>

using namespace std;

double x;

int main(){
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	int t=rand()+time(0);
	t%=10;
	x=(double)t/10;
	printf("%.1f",x);
	return 0;
}
