#include<bits/stdc++.h>

using namespace std;

inline int read(){
	int x=0,f=1;
	char p=getchar();
	while(!isdigit(p)){
		if(p=='-') f=-1;
		p=getchar();
	}
	while(isdigit(p)) x=(x<<3)+(x<<1)+p-48,p=getchar();
	return x*f;
}

const int maxn=500005;

int n,m,ans,f[maxn],b[maxn],color[maxn],head[maxn];
int nxt[maxn<<1],cnt,ans1,ans2,ver[maxn<<1],v[maxn];

inline void add(int x,int y){
	nxt[++cnt]=head[x];
	head[x]=cnt;
	ver[cnt]=y;
}

inline int find(int x){
	if(f[x]==x) return x;
	else return f[x]=find(f[x]);
}

inline void dfs(int x,int fa){
	if(color[x]==1) ans1++;
	if(color[x]==2) ans2++;
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==fa) continue;
		color[y]=3-color[x];
		dfs(y,x);
	}
}

int main(){
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);	
	n=read();m=read();
	for(int i=1;i<=n;i++) f[i]=i;
	while(m--){
		ans1=0;ans2=0;
		int x=read(),y=read();
		if(find(x)==find(y)){
			printf("0 %d\n",ans);
			continue;
		}
		ans=0;
		printf("1 ");
		if(b[x]) f[find(y)]=b[x];
		else b[x]=y;
		if(b[y]) f[find(x)]=b[y];
		else b[y]=x;
		add(x,y);add(y,x);
		v[x]=1;v[y]=1;
		memset(color,0,sizeof(color));
		for(int i=1;i<=n;i++){
			if(!color[i]&&v[i]){
				ans1=0;ans2=0;
				color[i]=1;
				dfs(i,0);
				ans+=min(ans1,ans2);
			}
		}
		ans=n-ans;
		printf("%d\n",ans);
	}
	return 0;
}
