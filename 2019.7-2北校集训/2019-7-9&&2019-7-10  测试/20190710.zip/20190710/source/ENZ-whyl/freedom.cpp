#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

inline int read(){
	int x=0,f=1;
	char p=getchar();
	while(!isdigit(p)){
		if(p=='-') f=-1;
		p=getchar();
	}
	while(isdigit(p)) x=(x<<3)+(x<<1)+p-48,p=getchar();
	return x*f;
}

const int maxn=1000005;
int head[maxn],nxt[maxn<<1],ver[maxn<<1],n,cnt,m;
int f[maxn],w[maxn],sum[maxn],pos,tot,ans;

inline void add(int x,int y){
	nxt[++cnt]=head[x];
	head[x]=cnt;
	ver[cnt]=y;
}

inline void dfs_pre(int x,int fa){
	int siz=0;f[x]=fa;
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==fa) continue;
		siz++;
		dfs_pre(y,x);
	}
	if(siz==0) m++;
}

inline void dfs(int x,int fa){
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==fa) continue;
		sum[y]+=sum[x]+w[y];
		if(sum[y]>tot){
			tot=sum[y];
			pos=y;
		}
		dfs(y,x);
	}
}

int main(){
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	n=read();
	for(int i=1;i<n;i++){
		int x=read(),y=read();
		add(x,y);add(y,x);
	}
	for(int i=2;i<=n;i++) w[i]=1;
	dfs_pre(1,0);
	printf("%d\n",m);
	for(int i=1;i<=m;i++){
		for(int i=1;i<=n;i++) sum[i]=0;
		tot=0;pos=0;
		dfs(1,0);
		ans+=tot;
		while(pos!=1){
			w[pos]=0;
			pos=f[pos];
		}
		printf("%d\n",ans);
	}
	return 0;
}
