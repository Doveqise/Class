//
//  main.cpp
//  ts
//
//  Created by gengyf on 2019/7/10.
//  Copyright © 2019 yifan Geng. All rights reserved.
//

#include <iostream>
#include<cstdio>
using namespace std;
const int N=500010;
int f[N],n,m,dis[N],flag=0;
int ans,sz[N],d[N];
int find(int x){
    if(f[x]!=x){
        int y=f[x];
        f[x]=find(f[x]);
        dis[x]=(dis[x]+dis[y])%3;
        d[x]+=d[f[x]];
    }
    return f[x];
}
void find(int v,int u) {
    int t1,t2;
    t1=find(v);
    t2=find(u);
    if(t1==t2){
        if((dis[u]-dis[v]+3)%3!=2)
            printf("0 ");
    }
    else{
        dis[t2]=(1-dis[u]+3)%3;
        f[t2]=v;
        d[v]=sz[u];
        sz[u]+=sz[v];
        printf("1 ");
    }
}
int main() {
    freopen("ts.in", "r", stdin);
    freopen("ts.out", "w", stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++){
        f[i]=i;
        d[i]=0;sz[i]=1;
    }
    for(int i=1;i<=m;i++){
        int x,y;
        ans=0;
        scanf("%d%d",&x,&y);
        find(x,y);
        printf("%d",max(sz[find(1)],n-sz[find(1)]));
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
