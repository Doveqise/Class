//
//  main.cpp
//  freedom
//
//  Created by gengyf on 2019/7/10.
//  Copyright © 2019 yifan Geng. All rights reserved.
//


#include <bits/stdc++.h>
using namespace std;
#define N 1000010
struct edge{
    int nxt,to;
}e[N];
int n,cnt,ans,tot;
int head[N],fa[N],son[N],top[N],dfn[N],fdfn[N],dfn2[N],size[N],deep[N];
int a[N],sum[N],vis[N];
bool cmp(int x,int y){
    return x<y;
}
inline void add(int from,int to){
    e[++cnt].nxt=head[from];e[cnt].to=to;head[from]=cnt;
}
inline void dfs1(int x,int f,int d){
    deep[x]=d;
    size[x]=1;
    int mx=0;
    for(int i=head[x];i;i=e[i].nxt){
        int y=e[i].to;
        if(y==f)continue;
        if(!size[y]){
            fa[y]=x;
            dfs1(y,x,d+1);
            size[x]+=size[y];
            if(size[y]>mx){
                mx=size[y];son[x]=y;
            }
        }
    }
}
inline void dfs2(int x,int f){
    dfn[x]=++tot;
    fdfn[tot]=x;
    if(!top[x])top[x]=x;
    if(son[x]){
        top[son[x]]=top[x];
        dfs2(son[x],x);
    }
    for(int i=head[x];i;i=e[i].nxt){
        int y=e[i].to;
        if(y==son[x]||y==f)continue;
        dfs2(y,x);
    }
    dfn2[x]=tot;
}
struct tree{
    int sum;
#define s(x) t[x].sum
}t[4*N];
inline void pushup(int x){
    s(x)=s(x<<1)+s(x<<1|1);
}
inline void build(int x,int l,int r){
    if(l==r){
        s(x)=a[fdfn[l]];
        return ;
    }
    int mid=(l+r)>>1;
    build(x<<1,l,mid);
    build(x<<1|1,mid+1,r);
    pushup(x);
}
inline int query(int x,int l,int r,int L,int R){
    if(L<=l&&R>=r){
        return s(x);
    }
    int mid=(l+r)>>1;
    int res=0;
    if(L<=mid)res=res+query(x<<1,l,mid,L,R);
    if(R>mid)res=res+query(x<<1|1,mid+1,r,L,R);
    return res;
}
int main() {
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
    int u,v;
    scanf("%d",&n);
    for(int i=1;i<=n-1;i++){
        scanf("%d%d",&u,&v);
        add(u,v);add(v,u);
    }
    dfs1(1,-1,1);
    dfs2(1,-1);
    fa[1]=-1;
    a[1]=0;
    for(int i=2;i<=n;i++){
        a[i]=1;
    }
    build(1,1,tot);
    for(int i=2;i<=n;i++){
        if(vis[top[i]]==0){
            ans++;
            vis[top[i]]=1;
        }
    }
    printf("%d\n",ans);
    int k=0;
    for(int i=1;i<=n;i++){
        if(!top[son[i]]){
            sum[++k]=query(1,1,tot,dfn[1],dfn[i]);
        }
    }
    sort(sum+1,sum+k+1,cmp);
    for(int i=1;i<=k;i++){
        printf("%d\n",sum[i]);
    }
    fclose(stdin);fclose(stdout);
	return 0;
}
