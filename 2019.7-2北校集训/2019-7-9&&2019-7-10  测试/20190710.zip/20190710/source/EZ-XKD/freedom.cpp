#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=1000009;
inline int read(){
	int fix=1,ret=0;char ch;
	while(!isdigit(ch=getchar()))fix=ch=='-'?-1:fix;
	do ret=(ret<<1)+(ret<<3)+ch-'0';
	while(isdigit(ch=getchar()));
	return fix*ret;
}
int n,ans,a[maxn];
struct node{
	int u,v,nxt;
}e[maxn<<1];
int head[maxn],cnt;
bool vis[maxn];
inline void add(int u,int v){
	e[++cnt].u=u;e[cnt].v=v;e[cnt].nxt=head[u];head[u]=cnt;
}

bool cmp(int a,int b){
	return a>b;
}
int d[maxn],f[maxn],mx[maxn],son[maxn],top[maxn],len[maxn];
void dfs(int x,int fa){
	d[x]=d[fa]+1;
	mx[x]=d[x];
	f[x]=fa;
	bool b=0;
	for(int i=head[x];i;i=e[i].nxt){
		int y=e[i].v;
		if(y==fa)continue;
		b=1;
		dfs(y,x);
		mx[x]=max(mx[y],mx[x]);
		if(mx[y]>mx[son[x]])son[x]=y;
	}
	if(!b)++ans;
}
void dfs2(int x,int tp,int l){
	top[x]=tp;len[tp]=l;
	if(son[x])dfs2(son[x],tp,l+1);
	for(int i=head[x];i;i=e[i].nxt){
		int y=e[i].v;
		if(y!=f[x] && y!=son[x])dfs2(y,y,1);
	}
}
int main(){
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	n=read();
	for(int i=1,u,v;i<n;i++){
		u=read(),v=read();
		add(u,v);add(v,u);
	}
	dfs(1,0);
	dfs2(1,1,1);
	cnt=0;
	if(top[1]==1)a[++cnt]=len[1]-1;
	for(int i=2;i<=n;i++)if(top[i]==i)a[++cnt]=len[i];
	sort(a+1,a+1+cnt,cmp);
	printf("%d\n",ans);ans=0;
	for(int i=1;i<=cnt;i++)
	ans+=a[i],printf("%d\n",ans);
}
