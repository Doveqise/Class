//�������߶����ϲ��� ������д���ܲ��ܲ�������ʽ�ϲ� 
#include <fstream>
#include <set>
using namespace std;
ifstream cin("freedom.in");
ofstream cout("freedom.out"); 
const int kmaxn=1000000+5;
struct edge{
	int d;
	edge* nxt;
};
edge mpool[kmaxn<<1];
int mpt;
edge* H[kmaxn];
void add_edge(int s,int d)
{
	mpool[mpt].nxt=H[s];
	H[s]=&mpool[mpt++];
	H[s]->d=d;
}
multiset<int> st[kmaxn];
multiset<int>::iterator itr;
void merge(multiset<int>& a,multiset<int>& b)
{
	if(b.size()>a.size())
		swap(a,b);
	itr=b.begin();
	while(itr!=b.end())
	{
		a.insert(*itr);
		++itr;
	}
	b.clear();
}
void dfs(int now,int f)
{
	edge* t=H[now];
	while(t)
	{
		if(t->d!=f)
		{
			dfs(t->d,now);
			merge(st[now],st[t->d]);
		}
		t=t->nxt;
	}
	if(st[now].empty())
	{
		st[now].insert(1);
	}
	else
	{
		int t=*(--st[now].end());
		st[now].erase(--st[now].end());
		st[now].insert(t+1);
	}
}
int n,x,y;
int main()
{
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<n;++i)
	{
		cin>>x>>y;
		add_edge(x,y);
		add_edge(y,x);
	}
	dfs(1,0);
	if(st[1].size()==1&&1==*st[1].begin())
	{
		cout<<0<<endl;
		return 0;
	}
	cout<<st[1].size()<<endl;
	int ans=-1;
	itr=--st[1].end();
	while(!st[1].empty())
	{
		cout<<(ans+=*itr)<<endl;
		st[1].erase(itr--);
	}
	return 0;
} 
