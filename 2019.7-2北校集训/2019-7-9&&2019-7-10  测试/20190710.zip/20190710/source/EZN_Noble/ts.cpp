#include <fstream>
using namespace std;
ifstream cin("ts.in");
ofstream cout("ts.out"); 
const int kmaxn=500000+5;
int n,m;//���ܳ��ֱ��滷  %2 
int dsu[kmaxn];
int dis[kmaxn];
int x,y;
int tot[kmaxn];
int cnt[kmaxn];//��rootͬɫ�Ľڵ�
int res[kmaxn];//������ɫ���Ľڵ� res=max(tot-cnt,cnt) 
int ans;
int anc(int p)
{
	if(dsu[p]==p)return p;
	int a=anc(dsu[p]);
	dis[p]=(dis[p]^dis[dsu[p]]);
	return dsu[p]=a;
} 
bool merge(int a,int b)
{
	x=anc(a);
	y=anc(b);
	if(x==y&&dis[a]==dis[b])
		return true;
	if(x!=y){
		ans-=res[x]+res[y];
		dsu[x]=y;
		tot[y]+=tot[x];
		if((dis[x]=dis[a]^dis[b]^1))//x��y��ɫ
		{
			cnt[y]+=tot[x]-cnt[x];
		}
		else//x,yͬɫ 
		{
			cnt[y]+=cnt[x];
		}
		res[y]=max(cnt[y],tot[y]-cnt[y]);
		ans+=res[y];
	}
	return false;
}
/*
dis[x]=(dis[a]^dis[b]^1);
		tot[y]+=tot[x];
		ans-=cnt[x];
		ans-=cnt[y];
		cnt[x]=tot[x]-cnt[x];
		cnt[y]+=cnt[x];

*/
int main()
{
	ios::sync_with_stdio(false);
	cin>>n>>m;
	ans=n;
	for(int i=1;i<=n;++i)
	{
		dsu[i]=i;
		tot[i]=cnt[i]=res[i]=1;
	}
	while(m--)
	{
		cin>>x>>y;
		cout<<(int)!merge(x,y)<<' ';
		cout<<ans<<endl;
		/*cout<<"debug"<<endl;
		for(int i=1;i<=n;++i)
		{
			cout<<res[i]<<' ';
		}
		cout<<endl;*/
	}

	return 0;
}
