#include<bits/stdc++.h>
using namespace std;

const int N=1000010;
int n,m,tot,head[N],ind[N],d[N],fa[N];
queue<int>q;
struct Edge{
	int ver,suiv;
}e[N<<1];

inline void lnk(int x,int y)
{
	e[++tot].ver=y;
	e[tot].suiv=head[x];
	head[x]=tot;
}

inline void dfs(int x)
{
	d[x]=d[fa[x]]+1;
	for(int i=head[x];i;i=e[i].suiv)
	{
		int y=e[i].ver;
		if(y==fa[x])continue;
		fa[y]=x;
		dfs(y);
	}
}


inline void bfs()
{
	while(q.size())
	{
		int x=q.front();
		q.pop();
		for(int i=head[x];i;i=e[i].suiv)
		{
			int y=e[i].ver;
			if(d[y]==1 || y==fa[x])continue;
			d[y]=d[x]+1;
			q.push(y);
		}
	}
}

int main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	scanf("%d",&n);
	for(int i=1,x,y;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		lnk(x,y),lnk(y,x);
		ind[x]++,ind[y]++;
	}
	int ans=0;
	for(int i=2;i<=n;i++)
		if(ind[i]==1)ans++;
//	cout<<endl;
//	for(int i=1;i<=n;i++)
//		cout<<ind[i]<<" ";
//	cout<<endl<<ans<<endl;
	printf("%d\n",ans);
	dfs(1);
	int sum=0;
	while(ans--)
	{
		int maxson=-1;
		int pos;
		for(int i=1;i<=n;i++)
			if(d[i]>maxson)maxson=d[i],pos=i;
		while(pos!=1)
			q.push(pos),d[pos]=1,pos=fa[pos];
		bfs();
		sum+=maxson-1;
		printf("%d\n",sum);
	}
	fclose(stdout);
	return 0;
}
/*
8
1 2
1 3
2 4
2 5
4 7
4 8
3 6
*/
