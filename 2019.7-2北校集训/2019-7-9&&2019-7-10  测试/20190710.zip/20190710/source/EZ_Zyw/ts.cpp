#include<bits/stdc++.h>
using namespace std;

const int N=500010;
int n,m,tot,head[N];
int fa[N],siz[N],cnt[N];
bool col[N],v[N];
struct Edge{
	int ver,suiv;
}e[N<<1];

inline void lnk(int x,int y)
{
	e[++tot].ver=y;
	e[tot].suiv=head[x];
	head[x]=tot;
}

inline int find(int x){return x==fa[x]?x:fa[x]=find(fa[x]);}

int stk[N],top;
inline void flip(int x)
{
	v[x]=1,stk[++top]=x;
	col[x]^=1;
	for(int i=head[x];i;i=e[i].suiv)
	{
		int y=e[i].ver;
		if(v[y])continue;
		flip(y);
	}
}

//inline void debg(int *a,int n)
//{
//	for(int i=1;i<=n;i++)
//		cout<<a[i]<<" ";
//	cout<<endl;
//}

int main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		fa[i]=i,siz[i]=1;
	int sum=n;
	for(int i=1,x,y;i<=n;i++)
	{
		scanf("%d%d",&x,&y);
		int fx=find(x),fy=find(y);
		if(fx==fy)
		{
			if(col[x]==col[y]) printf("0 %d\n",sum);
			else printf("1 %d\n",sum);
		}
		else
		{
			if(col[x]==col[y])
			{
				if(siz[fx]<siz[fy])swap(x,y);
				top=0;
				sum-=max(cnt[fx],siz[fx]-cnt[fx]);
				sum-=max(cnt[fy],siz[fy]-cnt[fy]);
//				sum-=cnt[fy];
				
				flip(y);

				
				cnt[fy]=siz[fy]-cnt[fy];
//				sum+=cnt[fy];
				
				for(int j=1;j<=top;j++)
					v[stk[j]]=0;
				lnk(x,y),lnk(y,x);
				fa[fy]=fa[fx];
				siz[fx]+=siz[fy];
				cnt[fx]+=cnt[fy];
				sum+=max(cnt[fx],siz[fx]-cnt[fx]);
				printf("1 %d\n",sum);
			}
			else
			{
				if(siz[fx]<siz[fy])swap(x,y);
				lnk(x,y),lnk(y,x);
				fa[fy]=fx;
				siz[fx]+=siz[fy];
				cnt[fx]+=cnt[fy];
				printf("1 %d\n",sum);
			}
		}
//		for(int i=1;i<=n;i++)
//			cout<<col[i]<<" ";
//		cout<<endl;
//		
//		debg(fa,n);
//		debg(siz,n);
//		debg(cnt,n);
//		cout<<"-------------"<<endl;
	}
	fclose(stdout);
	return 0;
}
/*
6 6
1 2
3 4
2 4
5 6
2 6
1 4
*/

