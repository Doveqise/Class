#include<bits/stdc++.h>
using namespace std;

const int N=310;
int n,m;
double l,p[N],d[N];

int main()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	scanf("%lf%d",&l,&m);
	for(int i=1;i<=m;i++)
		scanf("%lf",&p[i]);
	scanf("%d",&n);
	for(int i=2;i<=n;i++)
		scanf("%lf",&d[i]);
	double ans=0;
	double sp;
	for(double i=0,ed=l-d[n];i<=ed;i+=0.1)
	{
		double sum=0;
		for(int j=1;j<=m;j++)
		{
			int ll=1,r=n;
			while(r-ll>5)
			{
				int m1=ll+(r-ll)/3,m2=ll+(r-ll)/3*2;
				double r1=abs(d[m1]+i-p[j]);
				double r2=abs(d[m2]+i-p[j]);
				if(r1<=r2)r=m2;
				else ll=m1;
			}
			int pos;
			double maxi=10000000;
			for(int k=ll;k<=r;k++)
			{
				double cur=abs(d[k]+i-p[j]);
				if(cur<maxi)
					maxi=cur,pos=k;
			}
			sum+=abs(d[pos]+i-p[j]);
		}
		if(sum>ans)ans=sum,sp=i;
	}
	printf("%.1lf %.1lf\n",sp,ans);
	fclose(stdout);
	return 0;
}
