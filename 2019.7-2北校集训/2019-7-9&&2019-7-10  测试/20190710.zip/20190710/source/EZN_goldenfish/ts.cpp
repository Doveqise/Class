#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#define R register
namespace Littlegoldenfish
{
	int fa[500005],n,m,head[500005];
	int x,y,fx,fy,se[5],tot=0,ans,vis[500005],ti=0;
	int find(int x)
	{
		if(x==fa[x])return x;
		else return fa[x]=find(fa[x]);
	}
	struct ccf
	{
		int to,nxt;
	}e[1000005];
	void add(int a,int b)
	{
		tot++;
		e[tot].to=b;
		e[tot].nxt=head[a];
		head[a]=tot;
	}
	void dfs(int fa,int now,int col)
	{
		se[col]++;vis[now]=ti;
		for(R int i=head[now];i;i=e[i].nxt)
		{
			if(e[i].to==fa)continue;
			dfs(now,e[i].to,3-col);
		}
	}
}
using namespace Littlegoldenfish;
int main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(R int i=1;i<=n;i++)fa[i]=i;
	while(m--)
	{
		scanf("%d%d",&x,&y);
		fx=find(x);fy=find(y);
		if(fx==fy)
		{
			printf("0 %d\n",ans);
			continue;
		}
		else
		{
			add(x,y);add(y,x);ti++;
			printf("1 ");
			ans=0;
			fa[fx]=fy;
			for(R int i=1;i<=n;i++)
			{
				se[1]=se[2]=0;
				if(vis[i]!=ti)
				{
					dfs(0,i,1);
					ans+=std::max(se[1],se[2]);
				}
			}
			printf("%d\n",ans);
		}
	}	
}
