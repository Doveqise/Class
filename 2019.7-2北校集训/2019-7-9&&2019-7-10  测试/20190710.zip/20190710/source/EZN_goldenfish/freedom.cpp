#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#define R register
namespace Littlegoldenfish
{
	int head[1000005],tot=0,n,x,y,siz[1000005],top;
	int zson[1000005],sta[1000005],val[1000005];
	bool vis[1000005];
	struct ccf
	{
		int to,nxt;
	}e[2000005];
	void add(int a,int b)
	{
		tot++;
		e[tot].to=b;
		e[tot].nxt=head[a];
		head[a]=tot;
	}
}
using namespace Littlegoldenfish;
void dfs1(int now,int fa)
{
	for(R int i=head[now];i;i=e[i].nxt)
	{
		if(e[i].to==fa)continue;
		dfs1(e[i].to,now);
	}
	for(R int i=head[now];i;i=e[i].nxt)
		if(e[i].to!=fa)
		{
			if(siz[e[i].to]+1>siz[now])
			{
				siz[now]=siz[e[i].to]+1;
				zson[now]=e[i].to;
			}
		}
}
void dfs2(int now,int fa)
{
	if(zson[now])dfs2(zson[now],now);
	if(now==zson[fa])
	{
		val[fa]=val[now]+1;
	}
	vis[now]=1;
	for(R int i=head[now];i;i=e[i].nxt)
	{
		if(e[i].to==zson[now]||e[i].to==fa)continue;
		dfs2(e[i].to,now);
	}	
	if(vis[fa])
	{
		sta[++top]=val[now]+1;
		return;
	}
}
int main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	scanf("%d",&n);
	for(R int i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	int ans=0;
	for(R int i=head[1];i;i=e[i].nxt)dfs1(e[i].to,1);
	vis[1]=true; 
	dfs2(1,0);
	std::sort(sta+1,sta+top+1);
	printf("%d\n",top);
	for(R int i=top;i>=1;i--)
	{
		ans+=sta[i];
		printf("%d\n",ans);
	}
	return 0;
}

