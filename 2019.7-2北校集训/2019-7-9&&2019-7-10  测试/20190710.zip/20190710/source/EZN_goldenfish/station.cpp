#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#define LL long long
#define LD long double
#define R register
using namespace std;
namespace Littlegoldenfish
{
	LD sum,L,che[305],ren[305],wei;
	LL n,m;
	LD dis(LD now)
	{
		LD ans=0;
		for(R int i=1;i<=n;i++)
		{
			LL k=lower_bound(che+1,che+n+1,ren[i]-now)-che;
			//printf("%lld\n",k);
			if(k==m+1)ans+=ren[i]-now-che[k-1];
			else if(che[k]==ren[i]-now)continue;
			else if(k==1)ans+=che[k]-ren[i]+now;
			else ans+=min(che[k]-ren[i]+now,ren[i]-che[k-1]-now);
			//cout<<i<<"="<<ans<<endl;
		}
		return ans;
	}
}
using namespace Littlegoldenfish;
int main()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	cin>>L;
	scanf("%d",&n);
	for(R int i=1;i<=n;i++)cin>>ren[i];
	scanf("%d",&m);
	for(R int i=2;i<=m;i++)cin>>che[i];
	che[m+1]=L+1;
	//sum=max(dis(0),dis(L-che[m]));
	//cout<<dis(0.9)<<endl;
	for(R LD i=0;i<=L-che[m];i+=0.1)
	{
		LD kkk=dis(i);
		if(kkk>sum)
		{
			wei=i;
			sum=kkk;
		}
	}
	cout<<wei<<" "<<sum<<endl;
	return 0;
}
