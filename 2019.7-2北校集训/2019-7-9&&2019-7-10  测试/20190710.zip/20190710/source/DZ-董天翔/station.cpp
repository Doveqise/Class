#include<iostream>
#include<cmath>
#include<cstdio>

using namespace std;
int l,m,n;
double p[310],d[310],maxx,qqq,cccc,qqqq;

int main(){
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	cin>>l>>m;
	for(int i=1;i<=m;i++){
		cin>>p[i];
	}
	cin>>n;
	for(int i=2;i<=n;i++){
		cin>>d[i];
	}
	double len=(l-d[n])*10; 
	for(double i=1;i<=len;i++){
		double cccc=0;
		for(int j=1;j<=n;j++){
			d[j]+=0.1;
		}
	    for(int k=1;k<=m;k++){
	    	double minn=1000000000;
	    	for(int q=1;q<=n;q++){
	    		minn=min(minn,abs(p[k]-d[q]));
	    	}
	    	cccc+=minn;
	    }
		if(cccc>maxx){
			qqq=i*0.1;
			maxx=cccc;
		}	
	}
	cout<<qqq<<endl;
	cout<<maxx<<endl;
	
	return 0;
}
