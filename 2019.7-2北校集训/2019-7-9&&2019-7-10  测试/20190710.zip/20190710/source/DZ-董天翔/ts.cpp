#include<iostream>
#include<cstdio>

using namespace std;
int fa[500100],n,m,tot=0;
  
bool v[500010];  
  
int get(int x){
	if(x==fa[x]) return x;
	return fa[x]=get(fa[x]);
}
bool merge(int x,int y,int r){
	int fx=get(x),fy=get(y);
	if(fx==fy) return 0;
	if(fx!=fy) {
		if(v[x]==0){
			tot++;
			v[x]=1;
		}
	fa[fx]=fy;return 1;	
	}
}
int main(){
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	cin>>n>>m;
	int x,y;
	int num=n;
	for(int i=1;i<=n;i++){
		fa[i]=i;
	}
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		cout<<merge(x,y,i);
		cout<<" "<<max(num-tot,tot)<<endl;
	}
	return 0;
}
