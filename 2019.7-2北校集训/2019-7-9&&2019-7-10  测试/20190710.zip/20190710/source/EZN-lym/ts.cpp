#include<bits/stdc++.h>

using namespace std;

int n,m;
int fa[1000005];
int sz[1000005];
int misz[1000005];
int ans;

int getf(int p)
{
	int pp=fa[p],tp;
	while(fa[pp] != pp) pp = fa[pp];
	while(fa[p] != p) tp=p, p=fa[p], fa[tp]=pp;
	return p;
}

const int P = 500000;
int main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	cin >> n >> m;
	ans = n;
	for(int i = 1; i <= n; i++)
	{
		fa[i] = i;
		fa[i+P] = i+P;
		sz[i] = 1;
		sz[i+P] = 1;
		misz[i] = 1;
		misz[i+P] = 0;
	}
	while(m--)
	{
		int x,y;
		cin >> x >> y;
		if(getf(x) == getf(y))
		{
			cout << 0 << ' ' << ans << endl;
		}
		else
		{
			int tmp1 = sz[getf(x)] + sz[getf(y+P)];
			int tmp2 = misz[getf(x)] + misz[getf(y+P)];
			ans -= max(misz[getf(x)],sz[getf(x)]-misz[getf(x)]) + max(misz[getf(y)],sz[getf(y)]-misz[getf(y)]);
			fa[getf(x)] = getf(y+P);
			sz[getf(x)] = tmp1;
			misz[getf(x)] = tmp2;
			fa[getf(y)] = getf(x+P);
			sz[getf(y)] = tmp1;
			misz[getf(y)] = tmp1-tmp2;
			ans += max(misz[getf(x)],sz[getf(x)]-misz[getf(x)]);
			cout << 1 << ' ' << ans << endl;
		}
	}
	return 0;
}
