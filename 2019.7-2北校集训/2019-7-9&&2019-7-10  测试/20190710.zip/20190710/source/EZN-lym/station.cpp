#include<bits/stdc++.h>

using namespace std;

int l,m,n;
int p[305],d[305];
double mxp,mxs=0;

int main()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	cin >> l;
	cin >> m;
	for(int i = 1; i <= m; i++)
	{
		cin >> p[i];
	}
	cin >> n;
	d[1] = 0;
	for(int i = 2; i <= n; i++)
	{
		cin >> d[i];
	}
	for(double s=0; s <= l-d[n]; s+=0.03125)
	{
		double tps=0;
		for(int i = 1; i <= m; i++)
		{
			double mi = 0x3f3f3f3f;
			for(int j = 1; j <= n; j++)
			{
				mi = min(mi,fabs(d[j]-p[i]+s));
			}
			tps += mi;
		}
		if(tps > mxs)
		{
			mxp = s;
			mxs = tps;
		}
	}
	printf("%.1lf %.1lf\n",mxp,mxs);
	return 0;
}
