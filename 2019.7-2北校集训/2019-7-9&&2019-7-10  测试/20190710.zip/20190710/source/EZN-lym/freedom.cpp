#include<bits/stdc++.h>

using namespace std;

int n;
vector<int> v[1000005];
int ans[1000005];
int tp = 0;

int dfs(int fa, int p)
{
	vector<int> tdp;
	int tmx = 0;
	for(int i = 0; i < (int)v[p].size(); i++)
	{
		if(v[p][i] != fa)
		{
			tdp.push_back(dfs(p,v[p][i]));
			tmx = max(tmx,tdp[tdp.size()-1]);
		}
	}
	int ret = tmx+1;
	for(int i = 0; i < (int)tdp.size(); i++)
	{
		if(tdp[i] == tmx)
		{
			tmx = 0x3f3f3f3f;
		}
		else
		{
			ans[tp++] = tdp[i];
		}
	}
	return ret;
}

int ton[1000005];

int main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	cin >> n;
	for(int i = 1; i < n; i++)
	{
		int x,y;
		cin >> x >> y;
		v[x].push_back(y);
		v[y].push_back(x);
	}
	int tmp = dfs(0,1)-1;
	ans[tp++] = tmp;
	for(int i = 0; i < tp; i++) ton[ans[i]]++;
	tp = 0;
	for(int i = 1000004; i >= 0; i--)
		for(int j = 0; j < ton[i]; j++)
			ans[tp++] = i;
	cout << tp << endl;
	cout << ans[0] << endl;
	for(int i = 1; i < tp; i++)
	{
		ans[i] += ans[i-1];
		cout << ans[i] << endl;
	}
	return 0;
}
