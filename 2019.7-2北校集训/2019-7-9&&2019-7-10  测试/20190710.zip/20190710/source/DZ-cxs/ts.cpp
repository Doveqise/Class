#include<iostream>
#include<cstdio>
using namespace std;
int fa[5000100],n,m,tot=0;
bool v[5000010];
int get(int x)
{
	if(x==fa[x]) return x;
	return fa[x]=get(fa[x]);
}
int merge(int x,int y,int r)
{
	int fx=get(x),fy=get(y);
	if(fx==fy) return 0;
	if(fx!=fy)
	{
		if(v[x]==0)
		{
			tot++;
			v[x]=1;
		}
		fa[fx]=fy;return 1;	
	}
}
int main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	scanf("%d%d",&n,&m);
	int x,y;
	int num=n;
	for(int i=1;i<=n;i++){
		fa[i]=i;
	}
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		printf("%d ",merge(x,y,i));
		printf("%d\n",max(num-tot,tot));
	}
	return 0;
}
