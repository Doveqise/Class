#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>

using namespace std;

typedef pair<int, int> P;

namespace Main
{
	inline void file()
	{
		freopen("freedom.in", "r", stdin);
		freopen("freedom.out", "w", stdout);
	}
	
	const int maxn = 1e6 + 10;
	
	int n, head[maxn], to[maxn << 1], nxt[maxn << 1], tot = 1;
	int Size[maxn], depth[maxn], day = 0;
	int son[maxn], Top[maxn], fa[maxn];
	priority_queue<P, vector<P> > q;
	
	inline void add_edge(int u, int v)
	{
		to[++tot] = v;
		nxt[tot] = head[u];
		head[u] = tot;
	}
	
	void dfs_1(int u, int pre)
	{
		fa[u] = pre;
		depth[u] = depth[pre] + 1;
		Size[u] = 1;
		for (int c = head[u], v; c; c = nxt[c])
		{
			v = to[c];
			if (v == pre) continue;
			dfs_1(v, u);
			Size[u] += Size[v];
			if (Size[son[u]] < Size[v]) son[u] = v;
		}
		if (!son[u])
		{
			++day;
			q.push(P(depth[u], u));
			return;
		}
	}
	
	void dfs_2(int u, int p)
	{
		Top[u] = p;
		if (!son[u]) return;
		dfs_2(son[u], p);
		for (int c = head[u], v; c; c = nxt[c])
		{
			v = to[c];
			if (v == fa[u] || v == son[u]) continue;
			dfs_2(v, v);	
		}
	}
	
	inline int lca(int x, int y)
	{
		while (Top[x] != Top[y])
		{
			if (depth[Top[x]] < depth[Top[y]]) swap(x, y);
			x = fa[Top[x]];
		}
		return depth[x] < depth[y] ? x : y;
	}
	
	void main()
	{
		file();
		scanf("%d", &n);
		for (int i = 1, u, v; i < n; ++i)
		{
			scanf("%d%d", &u, &v);
			add_edge(u, v), add_edge(v, u);
		}
		depth[1] = -1;
		dfs_1(1, 1), dfs_2(1, 1);
		printf("%d\n", day);
		int ans = 0, u, pre = 0, p;
		while (!q.empty())
		{
			u = q.top().second;
			if (pre != 0)
			{
				p = lca(u, pre);
				if (p == 1) 
				{
					pre = u;
					ans += q.top().first;
					printf("%d\n", ans);
				}
				else
					q.push(P(depth[p] - depth[u], u));
			}
			else 
			{
				pre = u;
				ans += q.top().first;
				printf("%d\n", ans);
			}
			q.pop();
		}
	}
}

int main()
{
	Main::main();
	return 0;
}
