#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <algorithm>
#define extend_rand ((int)rand() * RAND_MAX + rand())
#define random(s, e) ((s) + extend_rand % ((e) - (s) + 1))

using namespace std;

namespace Main
{
	inline void file()
	{
		freopen("station.in", "r", stdin);
		freopen("station.out", "w", stdout);
	}
	
	int L, m, n;
	int P[310], D[310];
	const double delta = 0.9937;
	const double eps = 1e-14;
	
	void main()
	{
		file();
		scanf("%d%d", &L, &m);
		for (int i = 1; i <= m; ++i)
		{
			scanf("%d", P + i);
		}
		scanf("%d", &n);
		D[1] = 0;
		for (int i = 2; i <= n; ++i)
		{
			scanf("%d", D + i);
		}
		if (L == D[n])
		{
			printf("0.0 ");
			int sum = 0, res = 0;
			for (int i = 1; i <= n; ++i)
			{
				res = 0x7f7f7f7f;
				for (int j = 1; j <= m; ++j)
				{
					res = min(res, abs(D[j] - P[i]));
				}
				sum += res;
			}
			printf("%d.0", sum);
			return;
		}
//		srand(42324), srand(rand()), srand(rand());
		double S = 0, dis = 0, ans = 0;
//		int T = 1000;
//		while (T--)
//		{
//			S = (S + (double)random(0, 100) / 100.00) * delta;
//			double sum = 0, res = 0;
//			for (int i = 1; i <= n; ++i)
//			{
//				res = 0x7f7f7f7f;
//				for (int j = 1; j <= m; ++j)
//				{
//					res = min(res, fabs((double)(D[j] - P[i]) + S));
//				}
//				sum += res;
//			}
//			if (sum - dis > eps)
//			{
//				dis = sum;
//				ans = S;
//			}
//			if (random(1, 100) > 83) S = (double)random(0, 100) / 100.00;
//		}
		for (double S = 0; S <= L; S += 0.1)
		{
			double sum = 0, res = 0;
			for (int i = 1; i <= m; ++i)
			{
				res = 0x7f7f7f7f;
				for (int j = 1; j <= n; ++j)
				{
					res = min(res, fabs((double)(D[j] - P[i]) + S));
				}
				sum += res;
			}
			if (sum - dis > eps)
			{
				dis = sum;
				ans = S;
			}
		}
		printf("%.1lf %.1lf", ans, dis);
	}
}

int main()
{
	Main::main();
	return 0;
}
