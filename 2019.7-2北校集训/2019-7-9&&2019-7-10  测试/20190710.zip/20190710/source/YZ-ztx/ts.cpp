#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

namespace Main
{
	inline void file()
	{
		freopen("ts.in", "r", stdin);
		freopen("ts.out", "w", stdout);
	}
	
	const int maxn = 500010;
	int n, m;
	
	class union_find_set
	{
		private:
		  int fa[maxn << 1];
		  
		public:
		  int depth[maxn << 1];
		  	
			inline void Init(int bound)
		  	{
		  	 	for (int i = 1; i <= bound; ++i) 
			  	{
				  	fa[i] = i;
				  	depth[i] = 1;
			  	}
		  	}
		  
		    int Find(int x)
		    {
		  	    return x == fa[x] ? x : fa[x] = Find(fa[x]);
		    }
		  
		    inline bool Merge(int x, int y)
		    {
		  		int fx = Find(x), fy = Find(y);
		  		if (fx == fy) return false;
		  		if (depth[fx] > depth[fy]) swap(fx, fy);
		  		depth[fy] += depth[fx];
				fa[fx] = fy;
		  		return true;
		    }
		    
		    inline bool judge(int x, int y)
		    {
		    	return Find(x) == Find(y);
		    }
	}S;
	
	void main()
	{
		file();
		scanf("%d%d", &n, &m);
		S.Init(n << 1);
		int x, y, ans = 5, depth_x, depth_y;
		while (m--)
		{
			scanf("%d%d", &x, &y);
			if (S.judge(x, y))
			{
				printf("0 %d\n", ans);
			}
			else 
			{
				depth_x = S.depth[S.Find(x)];
				depth_y = S.depth[S.Find(y)];
				if (S.Merge(x, y + n) && S.Merge(x + n, y))
				{
					ans -= depth_x + depth_y;
					ans += max(depth_x + depth_y - S.depth[S.Find(x)], 
								S.depth[S.Find(x)] - 1); 
				}
				printf("1 %d\n", ans);
			}
		}
	}
}

int main()
{
	Main::main();
	return 0;
}
