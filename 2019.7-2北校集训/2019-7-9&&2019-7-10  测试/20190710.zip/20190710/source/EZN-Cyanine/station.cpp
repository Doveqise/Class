#include<bits/stdc++.h>
using namespace std;
int p[1000001],d[100001];
int main()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w,",stdout);
	int l,n,m;
	scanf("%d%d",&l,&m);
	for(int i=1;i<=m;i++)scanf("%d",&p[i]);
	scanf("%d",&n);
	for(int i=2;i<=n;i++)scanf("%d",&d[i]);
	double s=0,realans=0,realans2;
	for(s=0;s<=1.0*l-d[n];s+=0.1)
	{
		double ans=0;
		for(int i=1;i<=m;i++)
		{
			double tmp=100000000;
			for(int j=1;j<=n;j++)tmp=min(tmp,abs(d[j]+s-p[i]));
			ans+=tmp;
		}
		if(ans>realans)realans=ans,realans2=s;
	}
	printf("%.1lf %.1lf",realans2,realans);
}
