#include<bits/stdc++.h>
using namespace std;
int fa[1000001],with[10000001],target[1000001],pre[1000001],last[1000001],tot;
bool matched[10000001];
int find(int x)
{
	if(fa[x]==x)return x;
	int t=find(fa[x]);
	fa[x]=t;
	return t;
}
void add(int x,int y)
{
	tot++;
	target[tot]=y;
	pre[tot]=last[x];
	last[x]=tot;
}
bool match(int x)
{
	bool ans=0;
	for(int i=last[x];i;i=pre[i])
	{
		int to=target[i];
		if(!with[to])
		{
			with[to]=x;
			with[x]=to;
			matched[x]=1;
			return 1;
		}
		else if(!matched[with[to]])ans|=match(with[to]);
	}
	return 0;
}
int main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout); 
	int n,m;
	scanf("%d%d",&n,&m);
	int a,b,ans=n;
	for(int i=1;i<=n*2;i++)fa[i]=i;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&a,&b);
		int f=find(a),fb=find(b),fc=find(a+n),fd=find(b+n);
		if((f==fb)||(fc==fd))printf("0 %d\n",ans);
		else
		{
			fa[fb]=f,fa[fd]=fc;
			add(f,fd),add(fb,fd);
			if(!with[f])memset(matched,0,sizeof(matched)),ans-=match(f);
			//if(!with[fb])memset(matched,0,sizeof(matched)),ans-=match(fb);
			//if(!with[fc])memset(matched,0,sizeof(matched)),ans-=match(fc);
			//if(!with[fd])memset(matched,0,sizeof(matched)),ans-=match(fd);
			printf("1 %d\n",ans);
		}
	}
	return 0;
}
