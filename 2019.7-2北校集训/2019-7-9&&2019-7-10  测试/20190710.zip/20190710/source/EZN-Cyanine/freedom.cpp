#include<bits/stdc++.h>
using namespace std;
int target[2000001],pre[2000001],last[1000001],tot,fa[1000001],deep[1000001];
bool leaf[1000001],undeleted[1000001];
int ans,ans2,ans3,ans4;
void add(int x,int y)
{
	target[++tot]=y;
	pre[tot]=last[x];
	last[x]=tot;
}
void dfs(int x)
{
	for(int i=last[x];i;i=pre[i])
	{
		int to=target[i];
		if(leaf[to])
		{
			leaf[x]=0;
			dfs(to);
		}
	}
	if(leaf[x])ans++;
}
void dfs2(int x)
{
	deep[x]=deep[fa[x]]+undeleted[x];
	if(deep[x]>ans2)ans2=deep[x],ans3=x;
	for(int i=last[x];i;i=pre[i])
	{
		int to=target[i];
		if(to!=fa[x])
		{
			fa[to]=x;
			dfs2(to);
		}
	}
}
int main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	int n,x,y;
	scanf("%d",&n);
	memset(leaf,0x01,sizeof(leaf));
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	dfs(1);
	memset(undeleted,0x01,sizeof(undeleted));
	undeleted[1]=0;
	printf("%d\n",ans);
	for(int i=1;i<=ans;i++)
	{
		ans2=0;
		dfs2(1);
		ans4+=ans2;
		printf("%d\n",ans4);
		int now=ans3;
		while(ans3!=1)
		{
			undeleted[ans3]=0;
			ans3=fa[ans3];
		}
	}
	return 0;
}
