#include<bits/stdc++.h>
using namespace std;

const int maxn=5e5+10;
int n,m,ans;
int sum[3];
int fa[maxn<<1];
int vis[maxn];

int find(int x){
	if(x==fa[x]) return x;
	return fa[x]=find(fa[x]);
}

void bank(){
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
}

int main(){
	bank();
	scanf("%d%d",&n,&m);
	for(int i=1;i<=(n<<1);i++){
		fa[i]=i;
	}
	for(int i=1;i<=m;i++){
		int x,y; scanf("%d%d",&x,&y);
		if(find(x)!=find(y)){
			printf("1 ");
			fa[find(x)]=find(y+n);
			fa[find(x+n)]=find(y);
			if(vis[x]&&!vis[y]){
				vis[y]=3-vis[x];
				sum[vis[y]]++;
			}else if(vis[y]&&!vis[x]){
				vis[x]=3-vis[y];
				sum[vis[x]]++;
			}else if(vis[y]&&vis[x]){
				printf("%d\n",n-ans);
				continue;
			}else{
				vis[x]=1; vis[y]=2;
				sum[vis[x]]++; sum[vis[y]]++;
			}
			ans=min(sum[vis[x]],sum[vis[y]]);
			printf("%d\n",n-ans);
		}else printf("0 %d\n",n-ans);
	}
	return 0;
}

/*  5 5
	1 2
	1 3
	2 3
	4 5
	4 1
*/
