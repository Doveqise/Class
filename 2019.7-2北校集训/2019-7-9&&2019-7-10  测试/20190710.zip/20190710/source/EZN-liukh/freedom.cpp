#include<bits/stdc++.h>
#define re register int
#define maxn 5000+5
using namespace std;
int n;
int ans;
struct edge{
	int nex,to;
}ed[maxn*2];
int cnt;
bool flag[maxn];
struct tree{
	int size,fa,id;
	bool operator <(const tree&a)const
{
	return size<a.size;
}
}tr[maxn];
priority_queue<tree>q;
priority_queue<tree>q2;
int head[maxn];
void add(int x,int y)
{
	ed[++cnt].to=y;
	ed[cnt].nex=head[x];
	head[x]=cnt;
}
void dfs(int u,int fa)
{
	tr[u].fa=fa;
	tr[u].id=u;
   flag[u]=false;
	for(re i=head[u];i;i=ed[i].nex)
	{
		int v=ed[i].to;
		if(v==fa) continue;
		flag[u]=true;
		tr[v].size=tr[u].size+1;
		dfs(v,u);
	}
}
int  lca(int x,int y)
{
	int temp=1;
     for(re i=tr[x].fa;i;i=tr[i].fa)
     for(re j=tr[y].fa;j;j=tr[j].fa)
    if(i==j) temp=i;
	return temp;
}
void solve()
{
	for(re i=1;i<=n;i++)
	if(!flag[i]) q.push(tr[i]);
	while(!q.empty())
	{
		tree tmp=q.top();
		ans+=tmp.size;
		cout<<ans<<endl;
		q.pop();
		int si=q.size();
		while(si--)
		{
			tree t=q.top();
			q.pop();
			int lc=lca(tmp.id,t.id);
			t.size-=tr[lc].size;
			q2.push(t);
		}
		while(si--)
		{
			q.push(q2.top());
			q2.pop();
		}
	}
}
int main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	for(re i=1;i<=n-1;i++)
	{
		int x,y;
		cin>>x>>y;
		add(x,y);
		add(y,x);
	}
	dfs(1,0);
	solve();
	return 0;
}
