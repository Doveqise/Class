#include<bits/stdc++.h>
#define re register int
#define maxn 500000+5
using namespace std;
int cnt;
int n,m;
int t,s;
int fa[maxn];
int color[maxn];
int siz[maxn];
int head[maxn];
struct edge{
	int nex,to;
}ed[maxn];
int find(int x)
{
	if(fa[x]==x) return x;
    return fa[x]=find(fa[x]);
}
void add(int x,int y)
{
	ed[++cnt].to=y;
	ed[cnt].nex=head[x];
	head[x]=cnt;
}
void db(int x,int y)
{
	ed[head[x]].to=0;
	int tmp=ed[head[x]].nex;
	ed[head[x]].nex=0;
	head[x]=tmp;
}
void he(int x,int y)
{
	for(re i=head[x];i;i=ed[i].nex){
	int v=ed[i].to;
	}
}
bool col(int x,int co)
{
	color[x]=co;
	for(re i=head[x];i;i=ed[i].nex)
	{
		int v=ed[i].to;
		if(color[x]==color[v]) return false;
		if(!color[v]&&(!col(v,-co))) return false;
	}
	return true;
}
int main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m;
	for(re i=1;i<=n;i++)
	fa[i]=i;
	cin>>t>>s;
	int las=n-1;
	cout<<1<<n-1<<endl;
	for(re i=1;i<m;i++)
	{
		int u,v;
		cin>>u>>v;
		if(find(u)==find(v)) cout<<0<<" "<<las<<endl;
		else{
			add(u,v);
			if(!col(u,1)&&(!col(u,-1))) 
			{
				db(u,v);
				cout<<0<<" "<<las<<endl;
				continue;
			}
			if(col(u,1)) {
				add(v,u);
			if(col(v,-1))
			{
				he(u,v);
				las-=1;
				cout<<1<<" "<<las<<endl;
				continue;
			}
			if(!col(v,-1))
			{
				
			}
			}
		}
	}
}
