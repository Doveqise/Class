#include<bits/stdc++.h>
#define  re register int
#define db double 
#define maxn 50+5
using namespace std;
int l,n,m;
db ch;
db ans;
int passenger[maxn],door[maxn];
db temp[maxn];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch))
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	l=read();
	m=read();
	for(re i=1;i<=m;i++)
	passenger[i]=read();
	n=read();
	for(re i=1;i<=n-1;i++)
	door[i]=read();
	for(db i=0;i<=l;i+=0.5)
    {
    	db tmp=0;
    	memset(temp,0,sizeof(temp));
        for(re j=0;j<=n-1;j++)
        temp[j]+=i;
        for(re j=1;j<=m;j++)
        { bool flag=false;
		for(re k=0;k<n-1;k++)
        	{  if(temp[k]<=passenger[j]&&temp[k+1]>=passenger[j]){
        		tmp+=min(passenger[j]-temp[k],temp[k+1]-passenger[j]),flag=true;
                break;}
        	}
        	if(!flag)   tmp+=(passenger[j]-temp[n-1]);
    }
    if(tmp>ans) ans=tmp,ch=i;
}
  printf("%.1lf %.1lf",ch,ans);
  return 0;
}
    

