#include<iostream>
#include<cstdio>
#include<vector>

using namespace std;
const int N=500010;
int fat1[N],fat2[N];
int siz1,siz2,cnt,n,m,x,y,head1,head2;
vector<int> a,b;
void merge(int x,int pos){
	if(pos==1) {	//��x����1���� 
		fat1[x]=head1;
		fat2[x]=0;
		siz1++;
		for(int i=0;i<a.size();i++){
			if(x==a[i]) fat2[b[i]]=head2,siz2++;
			else if(x==b[i]) fat2[a[i]]=head2,siz2++; 
		}
	}
	else if(pos==2){ //��x����2���� 
		fat2[x]=head2;
		fat1[x]=0;
		siz2++;
		for(int i=0;i<a.size();i++){
			if(x==a[i]) fat1[b[i]]=head1,siz1++;
			else if(x==b[i]) fat1[a[i]]=head1,siz1++;
		}
	}
}

int judge(int a,int b){ 
	int fa1=fat1[a],fa2=fat2[a],fb1=fat1[b],fb2=fat2[b];
	if((fa1==fa2)&&(fb1==fb2)) return 1; 	//���ߵ��������ڼ����� 
	if((fa1==head1)||(fa2==head2)&&(fb1==fb2)) return 2;//��ߵ����ڼ�����
 	if(fa1==fa2&&fb1!=fb2) return 3;//�ұߵ����ڼ�����
	if(fa1==fb1||fa2==fb2) return 4; //���ߵ������ڼ����� 
	
}

void work(){
	scanf("%d%d",&x,&y);
	siz1++,siz2++;
	int px=x,py=y;
	int ans=n-1;
	printf("1 %d\n",ans);
	head1=px,head2=py;
	fat1[px]=px,fat2[px]=0,fat1[py]=0,fat2[py]=py;
	for(int i=2;i<=m;i++){
		scanf("%d%d",&x,&y);
		int tmp=judge(x,y);
		if(tmp==1) {
			a.push_back(x),b.push_back(y);
			ans=n-min(siz1,siz2)-1;
			printf("1 %d\n",ans);
		}
		else if(tmp==2){
			if(fat1[x]==head1) merge(y,2);
			else if(fat2[x]==head2) merge(y,1);
			ans=n-min(siz1,siz2);
			printf("1 %d\n",ans);
		}
		else if(tmp==3){
			if(fat1[y]==head1) merge(x,2);
			else if(fat2[y]==head2) merge(y,1);
			ans=n-min(siz1,siz2);
			printf("1 %d\n",ans);
		}
		else if(tmp==4){
			if(fat1[x]==fat1[y]||fat2[x]==fat2[y]) {
				ans=n-min(siz1,siz2);
				printf("0 %d\n",ans);
			}
			else 
			{
			ans=n-min(siz1,siz2);
			printf("1 %d\n",ans);
		}
	}
}
}

int main(){
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) fat1[i]=i,fat2[i]=i;
	work();
}
