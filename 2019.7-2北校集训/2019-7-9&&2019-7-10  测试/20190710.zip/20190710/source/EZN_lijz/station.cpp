#include <cstdio>
#include <cctype>

using namespace std;

inline int read() {
	int re = 0, k = 1; char in = getchar();
	while (!isdigit(in)) { if (in = '-') k = -1; in = getchar(); }
	while (isdigit(in)) re = re * 10 + in - '0', in = getchar();
	return re * k;
}

int main() {
	freopen("station.in", "r", stdin);
	freopen("station.out", "w", stdout);
	
	printf("0.0 0.0\n");
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
