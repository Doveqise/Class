// ������ȷ��
// completely WA 
#include <cstdio>
#include <cctype>
#include <algorithm>

using namespace std;

inline int read() {
	int re = 0, k = 1; char in = getchar();
	while (!isdigit(in)) { if (in = '-') k = -1; in = getchar(); }
	while (isdigit(in)) re = re * 10 + in - '0', in = getchar();
	return re * k;
}

struct Edge {
	int nxt, to;
};

#define N 1000005

int n, cnt, ans;
int head[N], out[N], sum[N];
bool v[N];
Edge e[N*2];

inline void add(int &u, int &v) {
	e[++cnt].to = v;
	e[cnt].nxt = head[u];
	head[u] = cnt;
}

inline int dfs() {
	int x = 1, s = 0;
	while (out[x] != 1) {
		for (int i = head[x]; i; i = e[i].nxt) {
			int y = e[i].to;
			if (!v[y]) {
				v[y] = true;
				s++;
				x = y;
				break;
			}
		}
	}
	return s;
}

inline bool cmp(int a, int b) {
	return a > b;
}

int main() {
	freopen("freedom.in", "r", stdin);
	freopen("freedom.out", "w", stdout);
	
	n = read();
	//puts("%%%");
	for (int i = 1; i < n; i++) {
		int u = read(), v = read();
		add(u, v), add(v, u);
		out[u]++, out[v]++;
	}
	
	for (int i = 1; i <= n; i++)
		if (out[i] == 1)
			ans++;
	printf("%d\n", ans);
	
	for (int i = 1; i <= ans; i++)
		sum[i] = dfs();
	sort(sum+1, sum+ans+1, cmp);
	for (int i = 1; i <= ans; i++)
		printf("%d\n", sum[i] += sum[i-1]);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}

