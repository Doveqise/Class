#include<bits/stdc++.h>
using namespace std;
int n,m,c[5010][5010],t1,t2,v[5010],n2,a1,a2,vis[5010];
int ans,ans2;
void dfs(int x,int now){
	if(now==1){
		for(int a=1;a<=n;a++){
		if(c[x][a]==1&&vis[a]==0){
			vis[a]=1;
		a2++;
		dfs(a,0);	
		}
	}
	}
	else{
		for(int a=1;a<=n;a++){
			if(c[x][a]==1&&vis[a]==0){
				vis[a]=1;
				a1++;
				dfs(a,1);
			}
		}
	}
}
int main(){
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	scanf("%d%d",&n,&m);
	ans=n;
	for(int a=1;a<=m;a++){
		scanf("%d%d",&t1,&t2);
		if(c[t1][t2]!=-1){
			memset(vis,0,sizeof(vis));
			if(v[t1]==0){
				v[t1]=1;ans--;
			}
			if(v[t2]==0){
				v[t2]=1;ans--;
			}
			ans2=ans;
			c[t1][t2]=c[t2][t1]=1;
			for(int b=1;b<=n;b++){
				if(c[t1][b]==1&&b!=t2){
					c[b][t2]=c[t2][b]=-1;
				}
				if(c[t2][b]==1&&b!=t1){
					c[b][t1]=c[t1][b]=-1;
				}
			}
			for(int b=1;b<=n;b++){
				
				if(v[b]!=0&&vis[b]==0){
					a1=0;a2=0;
					dfs(b,1);
					//printf("# %d %d\n",a1,a2);
				ans2+=max(a1,a2);
				}
			}
			printf("1 %d\n",ans2);
		}
		else{
		printf("0 %d\n",ans2);
		}
		
	}
	return 0;
}
