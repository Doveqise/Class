// Etavioxy
#include<cstdio>
#include<cctype>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<queue>
#define re register
#define il inline
#define ll long long
#define rep(i,s,t) for(re int i=(s);i<=(t);i++)
#define each(i,u) for(int i=head[u];i;i=bow[i].nxt)
#define pt(ch) putchar(ch)
#define pti(x) printf("%d",x)
#define ptll(x) printf("%lld",x)
#define file(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout)
using namespace std;
il int ci(){
	re char ch;
	while(isspace(ch=getchar()));
	re int x=(ch^'0');
	while(isdigit(ch=getchar()))x=(x*10)+(ch^'0');
	return x;
}
il ll cll(){
	re char ch;
	while(isspace(ch=getchar()));
	re ll x=(ch^'0');
	while(isdigit(ch=getchar()))x=(x*10)+(ch^'0');
	return x;
}
enum{N=303};
int n,m;
ll d[N],p[N];
ll dd[N];
int cur[N];
il ll calc(ll S){
	ll ans = 0;
	rep(i,1,m){
		ans += abs(S+d[cur[i]]-p[i]);
	}
	return ans;
}
struct sth{
	ll dis;
	int p;
	sth(){}
	sth(ll a,int b):dis(a),p(b){}
	il bool operator <(const sth&e)const{
		return dis>e.dis ;
	}
};
int stk[N];
int main(){
	file("station");
	ll L= cll()*2;
	{
		m= ci();
		rep(i,1,m) p[i]= cll()*2;
		n= ci();
		rep(i,2,n) dd[i]= (d[i-1]+(d[i]=cll()*2))/2;
//		rep(i,1,m) printf("%lld ",p[i]);pt('\n');
//		rep(i,1,n) printf("%lld ",d[i]);pt('\n');
//		rep(i,1,n) printf("%lld ",dd[i]);pt('\n');
	}
	ll ans = 0;
	{
		re int j=m, i=n;
		while( j && i>1 ){
			while( dd[i]>=p[j] && i>1 ) i--;
			cur[j--]= i;
		}
//		rep(i,1,m) printf("%d ",cur[i]);pt('\n');
	}
	ll mxS = 0, lim = L-d[n];
	ans= calc(0);
//	printf("%d\n",lim);
//	ptll(ans);pt('\n');
//	printf("end calc\n");
	{
		priority_queue <sth> pq;
		rep(i,1,m) if( dd[cur[i+1]]-p[i] >= 0 ) pq.push(sth(dd[cur[i+1]]-p[i],i));
		ll S,now;
		int pos,top=0;
//		printf("end add\n");
		while( !pq.empty() && pq.top().dis<=lim ){
			S= pq.top().dis;
			pos= pq.top().p;
//			printf("pop : %lld %d\n",S,pos);
			pq.pop();
			if( !pq.empty() && S==pq.top().dis ){
				stk[++top]= pos;
				continue;
			}
			now= calc(S);
//			rep(i,1,m) printf("%d ",cur[i]);pt('\n');
//			printf("%lld %lld\n",S,now);
			if( ans<now ){
				mxS= S;
				ans= now;
			}
			while( top ){
				pos= stk[top--];
				cur[pos]++;
				if( dd[cur[pos]+1]-p[pos] > 0 ) pq.push(sth(dd[cur[pos]+1]-p[pos],pos));
			}
		}
//		printf("end while\n");
	}
	printf("%.1lf %.1lf",(mxS*0.5),(ans*0.5));
	return 0;
}
