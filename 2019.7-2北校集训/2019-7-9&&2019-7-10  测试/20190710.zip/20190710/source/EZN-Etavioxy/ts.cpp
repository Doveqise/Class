// Etavioxy
#include<cstdio>
#include<cctype>
#include<cstring>
#include<algorithm>
#include<cmath>
#define re register
#define il inline
#define ll long long
#define rep(i,s,t) for(re int i=(s);i<=(t);i++)
#define each(i,u) for(int i=head[u];i;i=bow[i].nxt)
#define pt(ch) putchar(ch)
#define pti(x) printf("%d",x)
#define ptll(x) printf("%lld",x)
#define file(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout)
using namespace std;
il int ci(){
	re char ch;
	while(isspace(ch=getchar()));
	re int x=(ch^'0');
	while(isdigit(ch=getchar()))x=(x*10)+(ch^'0');
	return x;
}
enum{N=500023};
bool dis[N];
int fa[N],size[N],t[N];
void fd(int x){
	if( fa[x]==x )return ;
	fd(fa[x]);
	dis[x]= dis[x]^dis[fa[x]];
	fa[x]= fa[fa[x]];
}
int main(){
	file("ts");
	int n= ci(), m= ci();
	rep(i,1,n) fa[i]= i, t[i]= size[i]= 1;
	int x,y;
	bool ans1;
	int ans2 = n ;
	bool d;
	while( m-- ){
		x= ci(), y= ci();
		fd(x), fd(y);
		if( fa[x]==fa[y] ){
			ans1= dis[x]^dis[y];
		}
		else {
			ans1= 1;
			if( size[x]>size[y] ) swap(x,y);
			ans2-= max(t[x],size[x]-t[x])+max(t[y],size[y]-t[y]);
			d= dis[x]^dis[y]^1;
			fa[fa[x]] = fa[y];
			dis[x]= d;
			size[y]+= size[x];
			t[y]+= d ? size[x]-t[x] : t[x] ;
			ans2+= max(t[y],size[y]-t[y]);
		}
		printf("%d %d\n",ans1,ans2);
	}
	return 0;
}
