#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#define regin register int

using namespace std;
int n,m,ans;
int fa[1001000];
inline int get(int s)
{
	return s==fa[s]? s:fa[s]=get(fa[s]);
}
int tot,head[1001000],nex[2001000],ver[2001000];
inline void add(int a,int b)
{
	ver[++tot]=b;nex[tot]=head[a];head[a]=tot;
}
int bel[1001000],siz[2];
void dfs(int s,int f)
{
	bel[s]=bel[f]^1;
	siz[bel[s]]++;
	for(regin i=head[s];i;i=nex[i])
	{
		if(ver[i]==f) continue;
		dfs(ver[i],s);
	}
}
int read()
{
	int nn=0;
	char c;
	c=getchar();
	while(c>='0'&&c<='9') 
	{
		nn=(nn*10+c-'0');
		c=getchar();
	}
	return nn;
}
int main ()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	//scanf("%d%d",&n,&m);
	n=read();m=read();
	for(regin i=1;i<=2*n;i++)	 fa[i]=i;
	for(regin i=1;i<=m;i++)
	{
		int u,v;
		//scanf("%d%d",&u,&v);
		u=read();v=read();
		int x_f=u,x_e=u+n,y_f=v,y_e=v+n;
		if(get(x_f)==get(y_f)) 
		{
			printf("0 %d\n",ans);
			continue;
		}
		else printf("1 ");
		ans=0;
		fa[get(x_f)]=get(y_e);
		fa[get(x_e)]=get(y_f);
		add(u,v);
		add(v,u);
		memset(bel,-1,sizeof(bel));
		bel[0]=0;
		for(regin i=1;i<=n;i++)
		{
			if(bel[i]==-1)
			{
				memset(siz,0,sizeof(siz));
				dfs(i,0);
				ans+=max(siz[0],siz[1]);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
