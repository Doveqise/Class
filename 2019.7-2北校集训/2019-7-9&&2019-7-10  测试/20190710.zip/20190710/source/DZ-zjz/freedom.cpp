#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#define regin register int

using namespace std;
int n,ans,answer;
int tot,head[2001000],nex[3002000],ver[3002000];
inline void add(int a,int b)
{
	ver[++tot]=b;nex[tot]=head[a];head[a]=tot;
}
int du[2001000];
int size[2001000],father[2001000],son[2001000],d[2001000];
void dfs1(int s,int f)
{
	father[s]=f;
	size[s]=1;
	for(regin i=head[s];i;i=nex[i])
	{
		if(ver[i]==f )continue;
		dfs1(ver[i],s);
		size[s]+=size[ver[i]];
		if(size[ver[i]]>size[son[s]]) son[s]=ver[i];
	}
}
int an[2001000],num;
int top[2001000],cnt;
void dfs2(int s,int f)
{
	d[s]=1;
	if(s==1) d[s]=0;
	if(son[s])
	{
		top[son[s]]=top[s];
		dfs2(son[s],s);
		d[s]+=d[son[s]];
	}
	if(top[father[s]]!=top[s]) an[++num]=d[s];
	for(regin i=head[s];i;i=nex[i])
	{
		if(top[ver[i]]) continue;
		top[ver[i]]=++cnt;
		dfs2(ver[i],s);
	}
}
bool comp(int a,int b)
{
	return a>b;
}
int main ()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	scanf("%d",&n);
	for(regin i=1;i<n;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
		du[u]++;du[v]++;
	}
	for(regin i=2;i<=n;i++) 
	{
		if(du[i]==1) ans++;
	}
	printf("%d\n",ans);
	dfs1(1,0);
	top[1]=++cnt;
	dfs2(1,0);
	sort(an+1,an+1+num,comp);
	for(regin i=1;i<=num;i++)
	{
		answer+=an[i];
		printf("%d\n",answer);
	}
	return 0;
}
