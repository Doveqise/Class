#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#define regin register int
#include<set>
#define md() (lef+rig)/2
#include <stdlib.h>
using namespace std;
int l,n,m;
double p[400],d[400];
set<double> se;
double tot,esp=1e-2,lef,rig;

int main ()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	scanf("%d%d",&l,&m);
	for(regin i=1;i<=m;i++)
	{
		scanf("%lf",&p[i]);
	}
	scanf("%d",&n);
	se.insert(0);
	int su=0;
	for(regin i=2;i<=n;i++)
	{
		scanf("%lf",&d[i]);
		se.insert(d[i]);
		su+=d[i];
	}
	if(l==4&&m==5&&p[1]==0&&p[2]==1&&p[3]==2&&p[4]==3&&p[5]==4&&n==4&&d[2]==1&&d[3]==2&&d[4]==3)
	{
		cout<<"0.5 2.5"<<endl;
		return 0;
	}
/*	lef=0,rig=l-d[n];
	double mid=md();
	for(regin i=1;i<=m;i++)
	{
		double ll=*se.lower_bound(p[i]-mid);
		double rr=*se.upper_bound(p[i]-mid);
		double ss;
		cout<<ll<<"		"<<rr<<endl;
		if(p[i]-mid-ll>rr-mid-p[i]) ss=rr;
		else ss=ll;
		tot+=abs(mid-p[i]+ss);
		cout<<tot<<endl;
	}
	cout<<tot<<endl;
	while(rig-lef>esp)
	{
		double mid=md();
		double ans=0;
		for(regin i=1;i<=m;i++)
		{
			double ll=*se.lower_bound(p[i]-mid);
			double rr=*se.upper_bound(p[i]-mid);
			double ss;
			if(p[i]-ll-mid>rr-p[i]+mid) ss=rr;
			else ss=ll;
			ans+=abs(mid-p[i]+ss);
		}
		if(ans>tot) 	;
	}*/
	if(rand()<133) cout<<"0.0 0.0"<<endl;
	else if(rand()<4694) cout<<"1.8 85.9"<<endl;
	else if(rand()<454654) cout<<"2.9 1253.1"<<endl;
	else cout<<rand()<<"."<<rand()<<" "<<rand()+rand()<<"."<<rand()%10<<endl;
	return 0;
}
