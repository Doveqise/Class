#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int l,n,m; 
int p[310],d[310];
double mid[310];
int main(){
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	scanf("%d",&l);
	scanf("%d",&m);
	for(int i=1;i<=m;i++){
		scanf("%d",&p[i]);
	}
	scanf("%d",&n);
	d[1]=0;
	for(int i=2;i<=n;i++){
		scanf("%d",&d[i]);
	}
	if(l<500){
		double ans=0,maxn=0;
		for(double i=0.0;1.0*i+1.0*d[n]<=1.0*l+0.01;i+=0.5){
			double now=0;
			for(int j=1;j<=m;j++){
				double cnt=1.0*1e9;
				for(int k=1;k<=n;k++){
					cnt=min(cnt,fabs(1.0*d[k]+i-1.0*p[j]));
				}
				now+=cnt;
			}
			if(now>maxn){
				maxn=now;
				ans=i;
			}
		}
		printf("%.1lf %.1lf\n",ans,maxn);
	}
	else{
		for(int i=1;i<m;i++){
			mid[i]=1.0*(p[i]+p[i+1])/2.0;
		}
		double maxn=0.0,ans=0.0;
		for(int i=1;i<=n+1;i++){
			double s,now=0;
			if(i==n+1){
				s=l-d[n];
			}
			else{
				for(int j=1;j<m;j++){
					if(mid[j]>d[i]){
						s=mid[j]-1.0*d[i];
						break;
					}
				}
			}
			if(s+d[n]>1.0*l+0.01)continue;
			for(int j=1;j<=m;j++){
				double cnt=1.0*1e9;
				for(int k=1;k<=n;k++){
					cnt=min(cnt,fabs(1.0*d[k]+s-1.0*p[j]));
				}
				now+=cnt;
			}
			if(now>maxn){
				maxn=now;
				ans=i;
			}
		}
		printf("%.1lf %.1lf",ans,maxn);
	}
	return 0;
}
/*
4
5
0 1 2 3 4
4
1 2 3
*/
/*
10
7
0 1 1 3 4 6 9
6
1 3 4 6 7
*/
