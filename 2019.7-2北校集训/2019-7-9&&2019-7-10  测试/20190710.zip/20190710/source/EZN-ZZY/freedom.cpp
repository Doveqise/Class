#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n;
int num=1;
struct node{
	int to;
	int next;
}road[2000010];
int head[1000010];
int tot=0,deep[1000010],ans[1000010];
void built(int from,int to){
	road[++num].next=head[from];
	road[num].to=to;
	head[from]=num;
}
void dfs(int x,int fa){
	bool flag=0;
	for(int i=head[x];i;i=road[i].next){
		int y=road[i].to;
		if(y==fa)continue;
		flag=1;
		deep[y]=deep[x]+1;
		dfs(y,x);
	}
	if(!flag){
		ans[++tot]=deep[x];
	}
}
bool com(int a,int b){
	return a>b;
}
int main(){
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	memset(head,0,sizeof(head));
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		built(x,y);
		built(y,x);
	}
	dfs(1,1);
	printf("%d\n",tot);
	sort(ans+1,ans+tot+1,com);
	int sum=0;
	for(int i=1;i<=tot;i++){
		sum+=ans[i];
		printf("%d\n",sum);
	}
	return 0;
}//������ 
