#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m;
int tot=0,sum=0;
int road[5010][5010];
int color[5010];
bool dfs(int x){
	sum++;
	if(color[x]==1)tot++;
	for(int i=1;i<=n;i++){
		if(road[x][i]){
			if(!color[i]){
				color[i]=3-color[x];
				if(!dfs(i))return 0;
			}
			else if(color[i]==color[x])return 0;
		}
	}
	return 1;
}
int main(){
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	memset(road,0,sizeof(road));
	scanf("%d%d",&n,&m);
	int lastans=n;
	for(int i=1;i<=m;i++){
		int u,v;
		memset(color,0,sizeof(color));
		scanf("%d%d",&u,&v);
		road[u][v]=1;
		road[v][u]=1;
		bool flag=1;
		int ans=0;
		for(int i=1;i<=n;i++){
			if(!color[i]){
				tot=0;
				sum=0;
				color[i]=1;
				if(dfs(i)){
					ans+=max(sum-tot,tot);
				}
				else{
					flag=0;
					break;
				}
			}
		}
		if(!flag){
			road[u][v]=0;
			road[v][u]=0;
			printf("0 %d\n",lastans);
			continue;
		}
		lastans=ans;
		printf("1 %d\n",ans);
	}
	return 0;
}
