#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	double n = 2.5;
	double m = 0.5;
	cout << m << " " << n;
	return 0;
}
