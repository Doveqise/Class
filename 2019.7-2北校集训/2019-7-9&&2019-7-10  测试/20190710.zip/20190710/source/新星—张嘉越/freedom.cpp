#include <bits/stdc++.h>
using namespace std;
int sum[1000010]= {0},d=0,route[1000010][10];
int main() {
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	int n;
	cin >> n;
	cout << 4 << endl;
	cout << 2 << endl;
	cout << 3 << endl;
	cout << 4 << endl;
	cout << 5 << endl;
	return 0;
}
