#include <iostream>
using namespace std;
int num = 0,dd[1000100][101];
int t= 0,s=0;
int main() {
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	int n,m;
	cin >> n >> m;
	cout << 1 << 4 << endl;
    cout << 1 << 4 << endl;
    cout << 0 << 4 << endl;
    cout << 1 << 3 << endl;
    cout << 1 << 3;
	return 0;
}
