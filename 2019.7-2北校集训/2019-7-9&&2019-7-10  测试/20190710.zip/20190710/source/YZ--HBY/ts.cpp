#include<bits/stdc++.h>
#define rt register int
#define gt getchar()
using namespace std;
inline int in(){
	rt x = 0, f = 1; char s = gt;
	while(isdigit(s)){ x = (x<<1) + (x<<3) + (s ^ 48); s = gt; }
	return x * f;
}
const int _ = 5e5 + 10;
int n,m,fa[_],dis[_],out[_];
bool vis[_];
inline int find (int x){
	if(x == fa[x])  return x;
	int  f = fa[x];
	dis[x] = (dis[x] + dis[f] + 1) % 2;
	return (fa[x] = find(fa[x]));
}
inline void merge (int x, int y, int s){
	int u = find(x), v = find(y);
	fa[u] = v;
	dis[u] = -dis[x] + dis[y] + s;
}
//inline int find (int x){ return x == fa[x] ? x : fa[x] = find(fa[x]); }
/*inline bool part (int x, int y){
	if(color[x] == -1 or color[y] == -1){
		color[x] = color[find(x)];
		color[y] = color[find(y)] = ~color[x];
		return 1;
	}
	else return 0;
}*/
int main(){
	freopen("ts.in","r",stdin); freopen("ts.out","w",stdout);
	n = in(); m = in();
	rt i = 0,u,v,cap = n;
	while(++i <= n) fa[i] = i;
	for (i = 1; i <= m; ++i){
		u = in(); v = in();
		if(u == v) cout<<"0"<<' '<<cap<<endl;
		int a = find(u), b = find(v);
		if(a!=b){
			if(!vis[u] or !vis[v] and !out[u] and !out[v]) --cap;
			out[u]++; fa[b] = a;
			cap = max(cap,n - cap);
			cout<<"1"<<' '<<cap<<endl;
			vis[u] = vis[v] = 1;
		}
		if(a == b){
			if((dis[v] - dis[u] + 3)%2!=0)
				cout<<"0"<<' '<<cap<<endl; 
			else cout<<"1"<<' '<<cap<<endl;
		}
	}
	fclose(stdin),fclose(stdout);
	return 0;
}
