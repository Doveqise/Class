#include <bits/stdc++.h>
using namespace std;
int l, m, n;
double s = 0, t = 0;
double rd = 0;
double eps = 0.01;
double maxrd = -1, maxs;
int p[310], d[310];
double f(double s){
    rd = 0;
    int mi = 1, ni = 1;
    while (mi <= m)
    {
        while (fabs(d[ni] + s - p[mi]) > fabs(d[ni + 1] + s - p[mi]))
            ni++;
        rd += fabs(d[ni] + s - p[mi]);
        mi++;
    }
    return rd;
}
int main(){
    freopen("station.in", "r", stdin);
    freopen("station.out", "w", stdout);
    cin >> l >> m;
    for (int i = 1; i <= m; i++)
        scanf("%d", &p[i]);
    cin >> n;
    for (int i = 2; i <= n; i++)
        scanf("%d", &d[i]);
    double L = 0, R = l - d[n];
    while (fabs(L - R) >= eps){
        double mid = (L + R) / 2;
        if (f(mid + eps) > f(mid - eps))
            L = mid;
        else
            R = mid;
    }
    printf("%.1lf %.1lf", L, f(L));
}