#include<bits/stdc++.h>
using namespace std;
int n, ans, son;
int u, v, tot;
int ss[1000010];
int num[1000010], du[1000010];
bool vis[1000010];
int ver[2000010], head[1000010], nx[2000010];
void add(int x,int y){
    ver[++tot] = y;
    nx[tot] = head[x];
    head[x] = tot;
}
int dfs(int x,int fa){
    if(du[x]==1&&x!=1){
        num[x]++;
        son = x;
        return 1;
    }
    int maxi = 0, maxx=x, dn;
    for (int i = head[x]; i;i=nx[i]){
        if(ver[i]==fa)
            continue;
        dn = dfs(ver[i], x);
        if (dn > maxi)
            maxi = dn, maxx = son;
    }
    if(x!=1)
        num[maxx]++;
    son = maxx;
    return maxi + 1;
}
bool cmp(int a,int b){
    return a > b;
}
int main(){
    freopen("freedom.in", "r", stdin);
    freopen("freedom.out", "w", stdout);
    cin >> n;
    for (int i = 1; i < n;i++){
        scanf("%d%d", &u, &v);
        add(v, u);
        add(u, v);
        du[u]++, du[v]++;
    }
    dfs(1,0);
    sort(num + 2, num + n + 1,cmp);
    for (int i = 1; i <= n;i++){
        if(du[i]==1)
            ans++;
    }
    cout << ans << endl;
    // for (int i = 1; i <= n;i++){
    //     cout << num[i] << endl;
    // }
    for (int i = 2; i <= ans + 1; i++){
        ss[i] = ss[i - 1] + num[i];
        cout << ss[i] << endl;
    }
}