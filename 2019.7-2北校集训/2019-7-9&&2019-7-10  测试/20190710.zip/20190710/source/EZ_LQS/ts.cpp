#include<bits/stdc++.h>
using namespace std;
int n, m, x, y, xx, yy;
int fa[500010], ene[500010];
int siz[500010];
int maxs, mins = 1;
int tt;
int find(int x){
    if(fa[x]==x)
        return x;
    else
        return fa[x] = find(fa[x]);
}
void merge(int x,int y){
    x = find(x), y = find(y);
    fa[x] = y, siz[y] += siz[x];
    siz[x] = 0;
    if(siz[y]>maxs)
        maxs = siz[y];
    if (siz[y] < siz[mins])
        mins = y;
}
int main(){
    freopen("ts.in", "r", stdin);
    freopen("ts.out", "w", stdout);
    cin >> n >> m;
    for (int i = 1; i <= n;i++)
        fa[i] = i, siz[i] = 1;
    for (int i = 1; i <= m; i++){
        bool flag = 0;
        scanf("%d%d", &x, &y);
        xx = find(x), yy = find(y);
        if(xx==yy){
            if(siz[mins]==0)
                printf("0 %d\n", maxs);
            else
                printf("0 %d\n", max(maxs, n - max(siz[mins],tt)));
            continue;
        }
        if(!ene[x])
            ene[x] = y;
        else
            merge(ene[x], y), flag = 1;
        if (!ene[y])
            ene[y] = x;
        else
            merge(ene[y], x), flag = 1;
        if(!flag)
            tt++;
        if (siz[mins] == 0)
            printf("1 %d\n", maxs);
        else
            printf("1 %d\n", max(maxs, n - max(siz[mins],tt)));
    }
}