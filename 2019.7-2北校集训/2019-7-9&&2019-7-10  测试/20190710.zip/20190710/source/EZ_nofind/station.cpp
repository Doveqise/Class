#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=310;
const int maxl=1000000010;
ll n,m,Len;
double P[maxn],D[maxn];
double s,ans;
inline ll read()
{
	char c=getchar();int res=0,f=1;
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9') res=res*10+c-'0',c=getchar();
	return res*f;
}
int find(double x)
{
	int l=1,r=n;
	while(l<r)
	{
		int mid=(l+r+1)>>1;
		if(D[mid]<=x) l=mid;
		else r=mid-1;
	}
	return l;
}
inline double calc(double S)
{
	double sum=0;//printf("case::%.1lf\n",S);
	for(int i=1;i<=n;i++) D[i]+=S;
	for(int i=1;i<=m;i++)
	{
		if(P[i]<=D[1]) sum+=D[1]-P[i];
		else if(P[i]>=D[n]) sum+=P[i]-D[n]; 
		else 
		{
			int x=find(P[i]);
			//printf("case3; %d %.1lf %.1lf\n",x,D[x],P[i]);
			sum+=min(fabs(P[i]-D[x]),fabs(P[i]-D[x+1]));
		}
	}
	for(int i=1;i<=n;i++)D[i]-=S;
	return sum;
}
int main()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	Len=read();m=read();
	for(int i=1;i<=m;i++) scanf("%lf",&P[i]);
	n=read();
	for(int i=2;i<=n;i++) scanf("%lf",&D[i]);
	for(double i=0;i<=Len-D[n];i+=0.001)
	{
		double tmp=calc(i);
		if(tmp>ans) ans=tmp,s=i;
	}
	printf("%.1lf %.1lf\n",s,ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
