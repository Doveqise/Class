#include<bits/stdc++.h>
using namespace std;//1->t,2->s
const int maxn=500010;
struct edge
{
	int to,nxt;
}e[maxn<<1];
int n,m,cnt,lastans;
int head[maxn],col[maxn],size[3];
inline int read()
{
	char c=getchar();int res=0,f=1;
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9') res=res*10+c-'0',c=getchar();
	return res*f;	
}
inline void add(int u,int v)
{
	e[++cnt].nxt=head[u];
	head[u]=cnt;
	e[cnt].to=v;
}
inline void rec()
{
	int x=e[cnt].to,y=e[cnt-1].to;
	head[x]=e[cnt-1].nxt,head[y]=e[cnt].nxt;
	cnt-=2;
}
bool dfs(int x,int color)
{
	col[x]=color;size[color]++;
	for(int i=head[x];i;i=e[i].nxt)
	{
		int y=e[i].to;
		if(col[x]==col[y])return 0;
		if(!col[y]){if(!dfs(y,3-color)) return 0;}	
	}
	return 1;
}
int main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;i++)
	{
		int x=read(),y=read();bool flag=0;
		add(x,y);add(y,x);
		memset(col,0,sizeof(col));size[1]=0;size[2]=0;
		for(int j=1;j<=n;j++)
		{
			if(!col[j])
			{	
				if(!dfs(j,1)){rec();printf("%d %d\n",0,lastans);flag=1;break;}
				else if(size[1]<size[2]) swap(size[1],size[2]);
			}
		}
		if(flag) continue;
		if(size[1]<size[2]) swap(size[1],size[2]);
		printf("%d %d\n",1,size[1]);lastans=size[1];
		/*
		for(int j=1;j<=n;j++) printf("%d %d ",j,col[j]);
		puts("");*/
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
