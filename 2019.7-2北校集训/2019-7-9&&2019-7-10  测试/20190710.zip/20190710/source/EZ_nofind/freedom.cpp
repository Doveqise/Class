#include<bits/stdc++.h>
using namespace std;
const int maxn=1000010;
struct edge
{
	int to,nxt;
}e[maxn<<1];
int n,cnt,tot,ans;
int head[maxn],size[maxn],a[maxn];
inline int read()
{
	char c=getchar();int res=0,f=1;
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9') res=res*10+c-'0',c=getchar();
	return res*f;
}
bool cmp(int x,int y){return x>y;}
inline void add(int u,int v)
{
	e[++cnt].nxt=head[u];
	head[u]=cnt;
	e[cnt].to=v;
}
void dfs(int x,int fa)
{
	size[x]=1;
	for(int i=head[x];i;i=e[i].nxt)
	{
		int y=e[i].to;
		if(y==fa) continue;
		dfs(y,x);size[x]+=size[y];
	}
}
int main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	n=read();
	for(int i=1;i<n;i++)
	{
		int u=read(),v=read();
		add(u,v);add(v,u);
	}
	dfs(1,0);
	for(int i=head[1];i;i=e[i].nxt)
	{
		int y=e[i].to;
		a[++tot]=size[y];
	}
	sort(a+1,a+tot+1,cmp);printf("%d\n",tot);
	for(int i=1;i<=tot;i++)ans+=a[i],printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
