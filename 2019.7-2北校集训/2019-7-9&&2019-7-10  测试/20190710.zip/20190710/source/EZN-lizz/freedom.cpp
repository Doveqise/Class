#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e6 + 5;
int ans, cnt, num;
int hd[maxn],out[maxn];
struct edge
{
    int frm, to, nxt, used;
} ed[maxn<<1];
void add(int x, int y)
{
    ed[++cnt].to = y;
    ed[cnt].frm = x;
    ed[cnt].nxt = hd[x];
    hd[x] = cnt;
}
struct node
{
    int vis, dat;
    vector<node > son;
} nd[maxn];
void build(int u)
{
    nd[++num].vis = 0;
    nd[num].dat = 0;
    for (int i = hd[u]; i; i = ed[i].nxt)
    {
        if (!ed[i].used)
        {
            nd[u].son.push_back(nd[++num]);
            ed[i].used=1;
            build(ed[i].to);
        }
    }
    return;
}
void pushup(node u)
{
    u.dat = 0;
    for (int i = 0; i < u.son.size(); i++)
    {
        pushup(u.son[i]);
        u.dat = max(u.dat, u.son[i].dat);
    }
    u.dat += (u.vis);
    return;
}
void dfs(node u)
{
    int maxx = 0, maxn = 0;
    if (!u.son.size())
    {
        u.dat = 0;
        return;
    }
    for (int i = 0; i < u.son.size(); i++)
    {
        if (u.son[i].dat > maxx)
        {
            maxn = i;
            maxx = u.son[i].dat;
        }
    }
    if (maxx)
    {
        dfs(u.son[maxn]);
        ans++;
    }
    pushup(u);
}
signed main()
{
    freopen("freedom.in","r",stdin);
    freopen("freedom.out","w",stdout);
    int n;
    scanf("%d",&n);
    for(int i=1,u,v;i<n;i++)
    {
        scanf("%d%d",&u,&v);
        add(u,v);
        add(v,u);
    }
    build(1);
    int ansn = 0;
    while(nd[1].dat)
    {
        dfs(nd[1]);
        out[++ansn]=ans;
    }
    printf("%d\n",ansn);
    for(int i=1;i<=ansn;i++)
        printf("%d\n",out[i]);
    return 0;
}