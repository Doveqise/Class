#include <bits/stdc++.h>
using namespace std;
const int maxn = 5e5+5;
int par1, par2, n, m, par1f=5e5+2, par2f=5e5+3;
int fa[maxn],vis[maxn];
int findfa(int x)
{
    return fa[x] == x ? x : fa[x] = findfa(fa[x]);
}
void judge(int x, int y)
{
    if (!vis[x])
    {
        vis[x]=1;
        if (!vis[y])
        {
            vis[y]=1;
            fa[x] = par1 < par2 ? par1f : par2f;
            fa[y] = (fa[x] == par1f ? par2f : par1f);
            par1++, par2++;
            printf("%d %d\n", 1, n - min(par1, par2));
        }
        else
        {
            fa[x] = (findfa(y) == par1f ? par2f : par1f);
            findfa(y) == par1f ? par2f++ : par1f++;
            printf("%d %d\n", 1, n - min(par1, par2));
        }
    }
    else if (!vis[y])
    {
        vis[y]=1;
        fa[y] = (findfa(x) == par1f ? par2f : par1f);
        findfa(x) == par1f ? par2f++ : par1f++;
        printf("%d %d\n", 1, n - min(par1, par2));
    }
    else if (fa[x] == fa[y])
        printf("%d %d\n", 0, n - min(par1, par2));
    else
        printf("%d %d\n",1,n-min(par1,par2));
    
}
signed main()
{
    freopen("ts.in","r",stdin);
    freopen("ts.out","w",stdout);
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i++)
        fa[i] = i;
    for (int i = 1, u, v; i <= m; i++)
    {
        scanf("%d%d", &u, &v);
        judge(u, v);
    }
    return 0;
}