#include <bits/stdc++.h>
using namespace std;
const int maxn = 3e2 + 5;
int l, n, m;
double s, ti;
double pas[maxn], dor[maxn], dorn[maxn];
int fd(int l, int r, double num)
{
    int res = 1;
    if (l == r)
        return l;
    if (l + 1 == r)
        return (abs(n - dorn[l]) > abs(dorn[r] - n)) ? r : l;
    int mid = l + r >> 1;
    if (dorn[mid] == num)
        return mid;
    if (dorn[mid] > num)
    {
        int t = fd(l, mid - 1, num);
        res = (abs(n - dorn[res]) > abs(dorn[t] - n)) ? t : res;
    }
    if (dorn[mid] < num)
    {
        int t = fd(mid + 1, r, num);
        res = (abs(n - dorn[res]) > abs(dorn[t] - n)) ? t : res;
    }
    return res;
}
signed main()
{
    freopen("station.in","r",stdin);
    freopen("station.out","w",stout);
    scanf("%d%d", &l, &m);
    for (int i = 1; i <= m; i++)
        scanf("%lf", &pas[i]);
    scanf("%d", &n);
    for (int i = 2; i <= n; i++)
        scanf("%lf", &dor[i]);
    double lim = min(dor[n], n - dor[n]);
    for (double det = 0; det <= lim; det += 0.1)
    {
        double dis = 0;
        for (int i = 1; i <= n; i++)
        {
            dorn[i] = dor[i] + det;
            //printf("dorn[%d]=%.1f ",i,dorn[i]);
        }
        for (int i = 1; i <= m; i++)
            dis += abs(pas[i] - dorn[fd(1, n, pas[i])]);
        //printf("Case :det=%.1f,dis=%.1f\n", det, dis);
        if (dis > ti)
        {
            s = det;
            ti = dis;
        }
    }
    printf("%.1f %.1f\n", s, ti);
    return 0;
}