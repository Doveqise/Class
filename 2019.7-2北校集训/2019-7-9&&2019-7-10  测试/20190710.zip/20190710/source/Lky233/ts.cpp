#include <bits/stdc++.h>
using namespace std;
namespace fdata
{
inline char nextchar()
{
    static const int BS = 1 << 21;
    static char buf[BS], *st, *ed;
    if (st == ed)
        ed = buf + fread(st = buf, 1, BS, stdin);
    return st == ed ? -1 : *st++;
}
inline int poread()
{
    int ret = 0;
    char ch;
    while (!isdigit(ch = nextchar()))
        ;

    do
        ret = ret * 10 + ch - '0';
    while (isdigit(ch = nextchar()));
    return ret;
}
} // namespace fdata
namespace lky
{
const int MAXN = 5e5 + 5;
int n, m;
int fa[MAXN];
int find(int x)
{
    if (fa[x] == x)
        return x;
    return fa[x] = find(fa[x]);
}
int _main()
{
    n = fdata::poread();
    m = fdata::poread();
    int ans_1 = n - 1, ans_2 = 0;
    for (register int i = 1; i <= n; i++)
        fa[i] = i;
    for (register int i = 1; i <= n; i++)
    {
        int x = fdata::poread(), y = fdata::poread();
        x = find(x);
        y = find(y);
        if (fa[x] == y)
            ans_2 = 0, ans_1--;
        else
            ans_2 = 1;
        fa[x] = y;
        printf("%d %d\n", ans_2, ans_1);
    }
}
} // namespace lky
int main()
{
#ifdef lky233
    freopen("ts\\ts.in", "r", stdin);
    freopen("ts\\ts.out", "w", stdout);
#else
    freopen("ts.in", "r", stdin);
    freopen("ts.out", "w", stdout);
#endif
    lky::_main();
    fclose(stdin);
    fclose(stdout);
    return 0;
}