#include <bits/stdc++.h>
using namespace std;
namespace fdata
{
inline char nextchar()
{
    static const int BS = 1 << 21;
    static char buf[BS], *st, *ed;
    if (st == ed)
        ed = buf + fread(st = buf, 1, BS, stdin);
    return st == ed ? -1 : *st++;
}
inline int poread()
{
    int ret = 0;
    char ch;
    while (!isdigit(ch = nextchar()))
        ;

    do
        ret = ret * 10 + ch - '0';
    while (isdigit(ch = nextchar()));
    return ret;
}
} // namespace fdata
namespace lky
{
const int MAXN = 1e6 + 9;
int n;
int head[MAXN], nxt[MAXN << 1], ver[MAXN << 1], tot;
priority_queue<pair<int, int> > un[MAXN];
inline void add(int x, int y)
{
    ver[++tot] = y;
    nxt[tot] = head[x];
    head[x] = tot;
}
bool v[MAXN];
queue<int> que;
int Q[MAXN], Cnt;
void dfs_1(int x, int now)
{
    que.push(x);
    v[x] = true;
    bool bo = 0;
    for (register int i = head[x]; i; i = nxt[i])
    {
        if (!v[ver[i]])
        { /*cerr<<x<<ver[i]<<endl, */
            // v[x] = 0;
            bo = 1;
            dfs_1(ver[i], now + 1);
            que.push(x);
        }
    }
    if (!bo)
    {
        int U = que.front();
        que.pop();
        int V;
        int n = que.size();
        for (register int i = 1; i <= n; i++)
        {
            V = que.front();
            un[U].push(make_pair(now, V));
            U = que.front();
            que.pop();
        }
        un[U].push(make_pair(now, 0));
    }
    return;
}
int ans[MAXN + 5], cnt;
void dfs_2(int x)
{
    v[x] = 1;
    que.push(x);
    int y = 0;
    while (un[x].size())
    {
        y = un[x].top().second;
        if (y)
        {
            if (!v[y])
                ++ans[MAXN + 1];
            // cerr << y << " " << ans[MAXN + 1] << endl;
            dfs_2(y);
            que.push(x);
        }
        else
        {
            ans[++cnt] = ans[MAXN + 1];
            int n = que.size();
            for (register int i = 1; i <= n; ++i)
            {
                int U = que.front();
                un[U].pop();
                que.pop();
            }
        }
    }
    return;
}
int _main()
{
    n = fdata::poread();
    for (register int i = 1; i < n; ++i)
    {
        register int x = fdata::poread(), y = fdata::poread();
        add(x, y);
        add(y, x);
    }
    dfs_1(1, 0);
    memset(v, 0, sizeof(v));
    // for (register int i = 1; i <= n; ++i)
    // {
    //     while (un[i].size())
    //         cerr << i << un[i].top().first << un[i].top().second << endl, un[i].pop();
    // }
    while (que.size())
        que.pop();
    dfs_2(1);
    cout << cnt << endl;
    for (register int i = 1; i <= cnt; i++)
    {
        printf("%d\n", ans[i]);
    }
    return 0;
}
} // namespace lky

int main()
{
#ifdef lky233
    freopen("freedom\\freedom.in", "r", stdin);
    freopen("freedom\\freedom.out", "w", stdout);
#else
    freopen("freedom.in", "r", stdin);
    freopen("freedom.out", "w", stdout);
#endif
    lky::_main();
    fclose(stdin);
    fclose(stdout);
    return 0;
}
