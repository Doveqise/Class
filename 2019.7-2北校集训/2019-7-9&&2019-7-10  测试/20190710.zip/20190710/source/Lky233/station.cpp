#include <bits/stdc++.h>
using namespace std;
namespace fdata
{
inline char nextchar()
{
    static const int BS = 1 << 21;
    static char buf[BS], *st, *ed;
    if (st == ed)
        ed = buf + fread(st = buf, 1, BS, stdin);
    return st == ed ? -1 : *st++;
}
inline int poread()
{
    int ret = 0;
    char ch;
    while (!isdigit(ch = nextchar()))
        ;

    do
        ret = ret * 10 + ch - '0';
    while (isdigit(ch = nextchar()));
    return ret;
}
} // namespace fdata
namespace lky
{
const int MAXN = 305;
int N, M, L;
int P[MAXN], D[MAXN];
double ans_1, ans_2;
int _main()
{
    L = fdata::poread();
    M = fdata::poread();
    for (register int i = 1; i <= M; ++i)
        P[i] = fdata::poread();
    N = fdata::poread();
    for (register int i = 1; i < N; ++i)
        D[i] = fdata::poread();
    for (register double I = 0.1; I <= (double)(L - D[N-1]); I += 0.1)
    {
        cerr << I << endl;
        double tmp1 = 0, tmp2 = 0;
        for (register int i = 1; i <= M; i++)
        {
            tmp1 = 1e5 * 1.0;
            for (register int j = 1; j <= N; j++)
            {
                tmp1 = min(abs(D[j] + I - P[i]), tmp1);
            }
            tmp2 += tmp1;
        }
        if (tmp2 > ans_2)
        {
            ans_1 = I;
            ans_2 = tmp2;
        }
    }
    printf("%.1lf %.1lf\n", ans_1, ans_2);
    return 0;
}
} // namespace lky
int main()
{
#ifdef lky233
    freopen("station\\station.in", "r", stdin);
    freopen("station\\station.out", "w", stdout);
#else
    freopen("station.in", "r", stdin);
    freopen("station.out", "w", stdout);
#endif
    lky::_main();
    fclose(stdin);
    fclose(stdout);
    return 0;
}