#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	for(ch=getchar();(ch<'0'||ch>'9')&&ch!='-';ch=getchar());
	if(ch=='-') f=0,ch=getchar();
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-'0';ch=getchar();}
	return f?x:-x;
}
int n,m,w[1010];
double l;
double p[1010],d[1010];
double res,pos;
signed main()
{
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	scanf("%lf",&l);
	m=read();
	for(int i=1;i<=m;++i)
	{
		scanf("%lf",&p[i]);
	}
	n=read();
	for(int i=1;i<=m;++i) w[i]=n;
	for(int i=2;i<=n;++i)
	{
		scanf("%lf",&d[i]);
	}
	for(double i=0;i<=l-d[n];i+=0.1)
	{
		double sum=0;
		for(int j=1;j<=m;++j)
		{
			double now=1e9+7;
			for(int k=w[j];k>=1;--k)
			{
				if(abs(d[k]+i-p[j])<=now)
				{
					now=abs(d[k]+i-p[j]);
					w[j]=k;
				}
				else break;
			}
			sum+=now;
		}
		if(sum>res)
		{
			res=sum;
			pos=i;
		}
	}
	printf("%.1lf %.1lf",pos,res);
	fclose(stdin);fclose(stdout);
return 0;
}
