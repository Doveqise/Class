#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	for(ch=getchar();(ch<'0'||ch>'9')&&ch!='-';ch=getchar());
	if(ch=='-') f=0,ch=getchar();
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-'0';ch=getchar();}
	return f?x:-x;
}
int n,tot,res;
int st[1000010],top;
int sum[1000010];
int cd[1000010];
int dep[1000010];
int f[1000010][25];
int lg[1000010];
int head[1000010],cnt;
struct point 
{
	int nxt,to;
}a[2000010];
inline void add(int x,int y)
{
	a[++cnt].nxt=head[x];
	a[cnt].to=y;
	head[x]=cnt;
}
inline void dfs(int now,int fa,int deep)
{
	dep[now]=deep;
	f[now][0]=fa;
	for(int i=1;(1<<i)<=deep;++i)
	{
		f[now][i]=f[f[now][i-1]][i-1];
	}
	bool flag=0;
	for(int i=head[now];i;i=a[i].nxt)
	{
		int t=a[i].to;
		if(t==fa) continue;
		flag=1;
		dfs(t,now,deep+1);
	}
	if(!flag) sum[++tot]=now;
}
inline int query(int x,int y)
{
	if(dep[x]<dep[y]) swap(x,y);
	while(dep[x]>dep[y])
	{
		x=f[x][lg[dep[x]-dep[y]]-1];
	}
	if(x==y) return x;
	for(int i=lg[dep[x]];i>=0;--i)
	{
		if(f[x][i]^f[y][i])
		{
			x=f[x][i];
			y=f[y][i];
		}
	}
	return f[x][0];
}
signed main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	n=read();
	for(int x,y,i=1;i<n;++i)
	{
		x=read(),y=read();
		add(x,y);
		add(y,x);
	}
	for(int i=1;i<=1000000;++i) lg[i]=lg[i>>1]+1;
	dfs(1,0,0);
	while(res<n-1)
	{
		int now=0,pos=0;
		for(int i=1;i<=tot;++i)
		{
			if(dep[sum[i]]>now)
			{
				now=dep[sum[i]];
				pos=sum[i];
			}
		}
		res+=now;
		st[++top]=now;
		for(int i=1;i<=tot;++i)
		{
			if(!dep[sum[i]]||sum[i]==pos) continue;
			int lca=query(pos,sum[i]);
			dep[sum[i]]-=dep[lca];
		}
		dep[pos]=0;
	}
	printf("%d\n",top);
	res=0;
	for(int i=1;i<=top;++i)
	{
		res+=st[i];
		printf("%d\n",res);
	}
	fclose(stdin);fclose(stdout);
return 0;
}
