#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch;
	for(ch=getchar();(ch<'0'||ch>'9')&&ch!='-';ch=getchar());
	if(ch=='-') f=0,ch=getchar();
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-'0';ch=getchar();}
	return f?x:-x;
}
int n,m,sum;
int f[1000010];
bool vis[1000010];
int head[1000010],cnt;
int hed[1000010],cntt;
struct point 
{
	int nxt,to;
}a[8000010],e[8000010];
inline void add(int x,int y)
{
	a[++cnt].nxt=head[x];
	a[cnt].to=y;
	head[x]=cnt;
}
inline void ad(int x,int y)
{
	e[++cntt].nxt=hed[x];
	e[cntt].to=y;
	hed[x]=cntt;
}
inline int find(int k)
{
	if(f[k]==k) return k;
	return f[k]=find(f[k]);
}
signed main()
{
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=2*n;++i) f[i]=i;
	for(int x,y,i=1;i<=m;++i)
	{
		x=read(),y=read();
		if(find(x)==find(y))
		{
			putchar('0');
			putchar(' ');
		}
		else
		{
			if(find(x)==find(y+n))
			{
				putchar('1');
				putchar(' ');
			}
			else
			{
				f[find(x)]=find(y+n);
				f[find(x+n)]=find(y);
				putchar('1');
				putchar(' ');
				for(int k=head[x];k;k=a[k].nxt)
				{
					int t=a[k].to;
					ad(y,t);
					ad(t,y);
				}
				for(int k=head[y];k;k=a[k].nxt)
				{
					int t=a[k].to;
					ad(x,t);
					ad(t,x);
				}
				add(x,y);
				add(y,x);
			}
		}
		sum=0;
		memset(vis,0,sizeof(vis));
		for(int now=1;now<=n;++now)
		{
			if(vis[now]) continue;
			vis[now]=1;
			int sum1=0,sum2=1;
			for(int k=head[now];k;k=a[k].nxt)
			{
				int t=a[k].to;
				if(vis[t]) continue;
				vis[t]=1;
				sum1++;
			}
			for(int k=hed[now];k;k=e[k].nxt)
			{
				int t=e[k].to;
				if(vis[t]) continue;
				vis[t]=1;
				sum2++;
			}
			sum+=min(sum1,sum2);
		}
		printf("%d\n",n-sum);
	}
	fclose(stdin);fclose(stdout);
return 0;
}
