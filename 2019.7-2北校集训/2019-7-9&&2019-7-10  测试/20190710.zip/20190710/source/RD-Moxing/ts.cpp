#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
#include<iomanip>
using namespace std;
const int N=5005;
bool map[N][N],vis[N];
int col[N],n,m,tim;
bool flag,pd[N],flagx,flagy;
int size[N],d[3],res;
bool dfs(int x,int r) {
	col[x]=r;
	d[col[x]]++;
	for(int i=1; i<=n; i++) {
		if(!map[x][i]) continue ;

		if(col[i]==col[x]) {
			flag=0;
			return 0;//0;
		}
		if(!col[i]) {
			if(!dfs(i,3-col[x])) {
				flag=0;
				return 0;
			}//0;
		}
	}
	return 1;
}
void search() {
	for(int i=1; i<=n&&flag; i++) {
		if(!pd[i]){
			res++;continue ;
		}
		if(!col[i]) {
			dfs(i,1);
		}
	}
}
void clear() {
	fill(col+1,col+1+n,0);
	fill(d,d+n+1,0);
	flagx=flagy=0;res=0;
}
int main() {
	freopen("ts.in","r",stdin);
	freopen("ts.out","w",stdout);
	scanf("%d%d",&n,&m);
	int x,y,ans;
	for(int i=1; i<=m; i++) {
		clear();
		scanf("%d%d",&x,&y);
		map[x][y]=1,map[y][x]=1,flag=1;
		if(!pd[x]) pd[x]=1,flagx=1;
		if(!pd[y]) pd[y]=1,flagy=1;
		search();
		if(flag==0) {
			printf("0 ");printf("%d\n",ans);
			map[x][y]=0,map[y][x]=0;
			if(flagx) pd[x]=0;
			if(flagy) pd[y]=0;
			continue ;
		}
		else{
			ans=res+max(d[1],d[2]);	
			printf("1 ");printf("%d\n",ans);
		}
	}
}
