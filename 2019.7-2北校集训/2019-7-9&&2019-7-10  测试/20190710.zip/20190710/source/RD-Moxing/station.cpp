#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
#include<iomanip>
using namespace std;
const int  N=305;
const double inf=1e16;
const double eps=0.01;
int l,m,n;double p[N],d[N];
double ans,all,s,res,dis,sta;
int main(){
	freopen("station.in","r",stdin);
	freopen("station.out","w",stdout);
	scanf("%d%d",&l,&m);
	for(register int i=1;i<=m;i++){
		scanf("%lf",&p[i]);
	}
	scanf("%d",&n);
	for(register int i=1;i<=n-1;i++){
		scanf("%lf",&d[i]);
		d[i]-=d[1];
	}
	all=l-d[n-1];//sta=-d[1];
	for(register double i=sta;i<=all;i+=eps){
		//double i=0.5;
		res=0;
		for(register int j=1;j<=m;j++){
			dis=inf;
			for(register int k=1;k<=n-1;k++){
				dis=min(dis,fabs(d[k]+i-p[j]));
			}
			res+=dis;
		}
		if(res>ans){
			ans=res;
			s=i;
		}
	}
	printf("%.1lf %.1lf",s,ans);
}
//4
//5
//0 1 2 3 4
//4
//1 2 3
