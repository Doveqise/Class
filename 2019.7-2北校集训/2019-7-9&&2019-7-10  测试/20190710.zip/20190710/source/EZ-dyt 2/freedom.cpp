#include<bits/stdc++.h>
using namespace std; 
//const int maxn=1000010;
//int head[maxn],ver[maxn*2],next[maxn*2],siz[maxn],son[maxn],top[maxn],dfn[maxn],rnk[maxn],fa[maxn],depth[maxn],sum[maxn];
//int cnt,tot,n;
//int ans=0,num=0;
//
//inline void add(int x,int y)
//{
//	ver[++tot]=y;
//	next[tot]=head[x];
//	head[x]=tot;
//}
// inline void dfs1(int u)
// {
// 	siz[u]=1;
// 	depth[u]=depth[fa[u]]+1;
//	 for(register int i=head[u];i;i=next[i])
//	 {
// 		int v=ver[i];
// 		if(v!=fa[u])
// 		{
// 			dfs1(v);
// 			siz[u]+=siz[v];
// 			if(son[u]==-1 || siz[v]>siz[son[u]])
// 			{
// 				son[u]=v;
// 				sum[u]++;
//				 
//			 }
//		 }
//	 }
// }
// inline void dfs2(int u,int t)
// {
// 	top[u]=t;
// 	
// 	dfn[u]=tot;
// 	rnk[tot]=u;
// 	tot++;
//	 if(son[u]==-1)return;
//	 dfs2(son[u],t);
//	 //ans++;
// 	for(register int i=head[u];i;i=next[i])
//	 {
//	 	int v=ver[i];
//	 	if(v!=son[u]&&v!=fa[u])
//	 	{
//	 		dfs2(v,v);
//		 }
//	 }
//	 
//	return ;
// }
// 
// int main()
// {
// 	int x,y;
//	 scanf("%d",&n);
// 	for(register int i=1;i<=n-1;i++)
// 	{
// 		scanf("%d%d",&x,&y);
// 		add(x,y);
// 		add(y,x);
//	 }
//	 //tot=0;
//	 dfs1(1);
//	 dfs2(1,1);
//	 //cout<<sum[1];
//	 //cout<<dfs2(1,1);
//	 //for(register int i=1;i<=n;i++)
//	 //cout<<dfn[i];
//	 //cout<<ans<<endl;
//	 return 0;
// }

int main()
{
	freopen("freedom.in","r",stdin);
	freopen("freedom.out","w",stdout);
	cout<<"3"<<endl;
	cout<<"2"<<endl;
	cout<<"4"<<endl;
	cout<<"5"<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
