#include<bits/stdc++.h>
using namespace std;
#define R register int
const int N=500005;
int head[N],color[N],colour[N];int nxt[N*2],ver[N*2],edge[N*2];int n,m,tot,cnt,cnt1,cnt2,cnt3;
inline void add(int x,int y){
	ver[++tot]=y;nxt[tot]=head[x];head[x]=tot;
}
inline int g(){
	int x=0;char p=getchar();
	while(p<'0'||p>'9')p=getchar();
	while(p>='0'&&p<='9')x=x*10+p-'0',p=getchar();
	return x; 
}
inline bool check(){
	cnt1=0;cnt2=0;cnt3=0;
	queue<int>q;
	for(R i=1;i<=N;i++)colour[i]=0;
	for(R i=1;i<=n;i++){
		if(!colour[i]){
			colour[i]=1;
			if(head[i]==0)cnt3++;
			else cnt1++;q.push(i);
			while(!q.empty()){
				int x=q.front();q.pop();
				for(R i=head[x];i;i=nxt[i]){
					int y=ver[i];
					if(!colour[y]){
						q.push(y);
						if(colour[x]==1)colour[y]=2,cnt2++;
						else colour[y]=1,cnt1++;
					}
					else if(colour[y]==colour[x])return false;
				}
			}
		}
	}
	return true;
}
inline void backk(int x,int y){
	head[y]=nxt[tot];ver[tot]=0;nxt[tot]=0;tot--;
	head[x]=nxt[tot];ver[tot]=0;nxt[tot]=0;tot--;
	return;
}
signed main(){
	n=g();m=g();
	for(R i=1;i<=m;i++){
		int x,y;x=g();y=g();
		int t=0;
		add(x,y);add(y,x);
		if(check()==true){
		//	cout<<cnt1<<" "<<cnt2<<" "<<cnt3<<endl;
		//	for(int i=1;i<=n;i++)cout<<colour[i]<<" ";
		//	cout<<endl;
			int tt=min(cnt1,cnt2);printf("1 %d\n",n-tt);	
		}
		else{
			backk(x,y);
			int tt=min(cnt1,cnt2);
			printf("0 %d\n",n-tt);
		}
	}
	return 0;
} 
