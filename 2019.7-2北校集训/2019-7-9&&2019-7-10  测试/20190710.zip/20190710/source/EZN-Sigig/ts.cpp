#include<cstdio>
#define N 500005
using namespace std;
namespace OI{
	int n,m,fa[N],tag[N],a,b,ans;
	int ts[5],tot[N][5];
	int find(int x){
		if(fa[x]==x)return x;
		int y=fa[x];
		fa[x]=find(y);
//		tag[x]=tag[y]^1;
		return fa[x];
	}
	inline void swp(int &u,int &v){int tmp=u;u=v;v=tmp;}
	inline int mmax(int u,int v){return u>v?u:v;}
	inline int mmin(int u,int v){return u<v?u:v;}
	inline void print(){
		for(int i=1;i<=n;i++){
			printf("**%d %d %d\n",i,tag[i],fa[i]);
		}
	}
	int main(){
		freopen("ts.in","r",stdin);freopen("ts.out","w",stdout);
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++)fa[i]=i;
		while(m--){
			scanf("%d%d",&a,&b);
			int x1=find(a),x2=find(b);
			if(x1==x2&&tag[a]==tag[b]){
				printf("0 %d\n",n-ans);
	//			print();////////////////////////////////////
				continue;
			}
			else printf("1 ");
			if(!tag[x1]&&!tag[x2]){
				tag[x1]=2,tag[x2]=3;
				ts[2]++;ts[3]++;
				fa[x2]=x1;
				tot[x1][2]++;tot[x1][3]++;
				ans=mmin(ts[2],ts[3]);
			}
			else if(tag[x1]&&tag[x2]){
				if(tag[a]^tag[b]){
					fa[x1]=x2;
					tag[x1]=tag[x2]^1;
					tot[x2][3]+=tot[x1][3];
					tot[x2][2]+=tot[x1][2];
				}
				else {
					fa[x1]=x2;
					tag[x1]=tag[x2]^1;
					swp(tot[x1][2],tot[x1][3]);
					tot[x2][3]+=tot[x1][3];
					tot[x2][2]+=tot[x1][2];
					ts[2]-=tot[x1][2];
					ts[2]+=tot[x1][3];
					ts[3]-=tot[x1][3];
					ts[3]+=tot[x1][2];
					ans=mmin(ts[2],ts[3]);
				}
			}
			else if(tag[x1]){
				tag[x2]=tag[a]^1;
				fa[x2]=x1;
				ts[tag[x2]]++;
				tot[x1][tag[x2]]++;
				ans=mmin(ts[3],ts[2]);
			}
			else if(tag[x2]){
				tag[x1]=tag[b]^1;
				fa[x1]=x2;
				ts[tag[x1]]++;
				tot[x2][tag[x1]]++;
				ans=mmin(ts[3],ts[2]);
			}
			printf("%d\n",n-ans);
	//		print();/////////////////////////////////////
		}
		return 0;
	}
};
int main(){
	OI::main();
	return 0;
}
/*
5 5
1 2
1 3
2 3
4 5
4 1
*/
/*
10 9
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 9
9 10
*/
/*
10 10
1 2
1 3 
1 4 
1 5
1 6
1 7
1 8
1 9
1 10
2 3
*/
