#include<cstdio>
#include<algorithm>
#include<cstring>
#define N 1000005
using namespace std;
namespace OI{
	int n,cnt=1,h[N],nxt[N<<1],to[N<<1],dep[N],fa[N],son[N],top[N],mxd[N],len[N];
	int fz[N],idx,ans=-1,a,b,c;
	inline void add(int u,int v){
		cnt++;
		nxt[cnt]=h[u];h[u]=cnt;to[cnt]=v;
		cnt++;
		nxt[cnt]=h[v];h[v]=cnt;to[cnt]=u;
	}
	int dfs1(int u){
		for(int i=h[u];i;i=nxt[i]){
			int v=to[i];
			if(v!=fa[u]){
				fa[v]=u;
				dep[v]=dep[u]+1;
				dfs1(v);
				if(mxd[v]>mxd[son[u]]){
					son[u]=v;
				}
			}
		}
		return mxd[u]=mxd[son[u]]+1;
	}
	void dfs2(int u){
		if(!top[u])top[u]=u;
		if(son[u]){
			top[son[u]]=top[u];
			dfs2(son[u]);
		}
		else {
			fz[++idx]=dep[u]-dep[top[u]]+1;
			return ;
		}
		for(int i=h[u];i;i=nxt[i]){
			int v=to[i];
			if(v!=fa[u]&&v!=son[u]){
				dfs2(v);
			}
		}
	}
	bool cmp(int a,int b){
		return a>b;
	}
	void print(){
		for(int i=1;i<=n;i++){
			printf("%d : dep %d son %d mxd %d fa %d top %d\n",i,dep[i],son[i],mxd[i],fa[i],top[i]);
		}
	}
	int Main(){
		freopen("freedom.in","r",stdin);freopen("freedom.out","w",stdout);
		scanf("%d",&n);
		memset(h,0,sizeof(h));
		for(int i=1;i<n;i++){
			scanf("%d%d",&a,&b);
			add(a,b);
		}
		dfs1(1);
		dfs2(1);
		sort(fz+1,fz+idx+1,cmp);
		printf("%d\n",idx);
		for(int i=1;i<=idx;i++){
			ans+=fz[i];
			printf("%d\n",ans);
		}
		return 0;
	}
}
int main(){
	OI::Main();
	return 0;
}
/*
6
1 2 
1 3
1 4
1 5
5 6
*/
/*
10
1 2
2 3
3 4
4 5
4 6
2 7
7 8
7 9
9 10
*/
