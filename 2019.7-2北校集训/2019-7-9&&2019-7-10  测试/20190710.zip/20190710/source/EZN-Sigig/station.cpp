#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<set>
#define ll long long
#define db double
using namespace std;
namespace OI{
	inline ll randbig(){return (rand()^(rand()<<5)^(rand()<<10)*(rand()^19260817))%5000000000+2000000000;}
	inline ll randsma(){return (rand()^(rand()<<5)^(rand()<<10)*(rand()^19260817))%5000+100;}
	inline ll my_abs( ll a){return a>0?a:-a;}
	const db delt=0.91;
	const db eps=1e-6;
	db ans=-1.0,mins=1e10,step,snow,sl,sr,ansl,ansr,ansnow;
	db L=0,R,r,plat[305],cust[305],wal;
	int n,m;
	set<double>s;
	set<double>::iterator it;
	inline db cal(db base){
		db ret=0.0;
		for(int i=1;i<=m;i++){
			it=s.lower_bound(cust[i]-base);
			db x=abs(*it-cust[i]+base);
			it--;
			x=min(x,abs(*it-cust[i]+base));
			ret+=x;
		}
		return ret;
	}
	int main(){
		freopen("station.in","r",stdin);freopen("station.out","w",stdout);
		srand(20031202);
		scanf("%lf%d",&R,&m);
		s.insert(0.0);
		for(int i=1;i<=m;i++)scanf("%lf",&cust[i]);
		scanf("%d",&n);
		for(int i=2;i<=n;i++)scanf("%lf",&plat[i]),s.insert(plat[i]);
		wal=R-plat[n];
		for(int i=1;i<=10;i++){
			step=wal/7;
			snow=my_abs(randbig())/my_abs(randsma())+(db)my_abs(randsma())/1000.0;
//			printf("%d %lf\n",i,snow);///////////
			while(snow>wal){
				snow-=floor(snow/wal)*wal;
			}
			ansnow=cal(snow);
			if(ansnow>ans+0.00005){
				ans=ansnow;
				mins=snow;
			}
			if(abs(ansnow-ans)<0.00005){
				mins=snow;
			}
			while(step>eps){
				sl=max(snow-step,0.0);
				sr=min(snow+step,wal);
				ansl=cal(sl);
				ansr=cal(sr);
				if(ansl>ansr){
					snow=sl;
					ansnow=ansl;
				}
				else {
					snow=sr;
					ansnow=ansr;
				}
				if(ansnow>ans+0.00005){
					ans=ansnow;
					mins=snow;
				}
				if(abs(ansnow-ans)<0.00005){
					mins=snow;
				}
				step*=delt;
			}
//			system("pause");
		}
		printf("%.1lf %.1lf",mins,ans);
		return 0;
	}
};
int main(){
	OI::main();
	return 0;
}
/*
4
5
0 1 2 3 4
4
1 2 3
*/
