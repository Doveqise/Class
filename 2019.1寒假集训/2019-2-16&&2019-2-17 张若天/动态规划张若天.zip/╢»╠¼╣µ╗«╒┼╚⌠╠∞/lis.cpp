#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;


int n;
int a[100000];

int lowbit(int x){
	return x&-x;	
}
void modify(int pos,int k){ // k>=a[pos] 
	while(pos<=n){
		a[pos]=max(a[pos],k);
		pos+=lowbit(pos);
	}
}
int ask(int pos){
	int ret = 0;
	while(pos>0){
		ret=max(ret, a[pos]);
		pos-=lowbit(pos);
	}
	return ret;
}
int b[100000];
int f[100000];
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&b[i]);
	// ��ɢ��b[]
	 
	for(int i=1;i<=n;i++){
		f[i]=1;
		for(int j=1;j<i;j++){
			if(b[j]<b[i])
			 f[i]=max(f[i],f[j]+1);
		}
	}
	int ans = 0;
	for(int i=1;i<=n;i++) ans=max(ans,f[i]);
	printf("%d\n",ans);
	
	
	return 0;
}


